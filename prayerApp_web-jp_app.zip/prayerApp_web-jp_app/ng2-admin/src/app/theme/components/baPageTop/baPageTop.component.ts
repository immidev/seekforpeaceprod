import {Component, HostListener} from '@angular/core';

import {GlobalState} from '../../../global.state';
import { Router } from '@angular/router';

@Component({
  selector: 'ba-page-top',
  templateUrl: './baPageTop.html',
  styleUrls: ['./baPageTop.scss']
})
export class BaPageTop {
topic;
  public isScrolled:boolean = false;
  public isMenuCollapsed:boolean = false;
  public activePageTitle:string = '';
  constructor(private _state:GlobalState,private router: Router) {

this.btnActivate(1);

this.topic = localStorage.getItem('topic');
    this._state.subscribe('menu.isCollapsed', (isCollapsed) => {
      this.isMenuCollapsed = isCollapsed;
    });
    this._state.subscribe('menu.activeLink', (activeLink) => {
      if (activeLink) {
        this.activePageTitle = activeLink.title;
      }
    });  
  }
  topicLocalStorage(){
    console.log("inside click function")
    this.topic = localStorage.getItem('topic');
  }
  logout(){
    localStorage.removeItem('currentUser');
    localStorage.clear; 
    localStorage.removeItem;
    localStorage.setItem('reload','Y');

      window.location.href="#login";
  }

  @HostListener('window:scroll', ['$event'])
  onWindowScroll(e) {
    //
    if (window.pageYOffset > 80) {
      let element = document.getElementById('navbar');
      element.classList.add('sticky');
    } else {
     let element = document.getElementById('navbar');
       element.classList.remove('sticky'); 
    }
  }


  public toggleMenu() {
    this.isMenuCollapsed = !this.isMenuCollapsed;
    this._state.notifyDataChanged('menu.isCollapsed', this.isMenuCollapsed);
    return false;
  }

  public scrolledChanged(isScrolled) {
    this.isScrolled = isScrolled;
  }

  viewLocation;
  public isActive() {
    //var active = (this.viewLocation === $location.path());
    return this.active;
    //this.function();
};
active
public function(id){
   this.active =id;
 // return active;
}


selectedId:number; 
btnActivate(Id : number){
   this.selectedId= Id; 
}
getTextColor(Id:number){
  // if(Id == 5 && this.selectedId == 5){
  //   if(document.getElementById("registration")!=null && document.getElementById("registration")!= undefined){
  //     document.getElementById("registration").style.color = "#ED3237";
  //   }
  // }
  // if(Id != 5 && this.selectedId != 5){
  //   if(document.getElementById("registration")!=null && document.getElementById("registration")!= undefined){
  //     document.getElementById("registration").style.color = "black";  
  //   }
  // }
  return (this.selectedId == Id? "active" : "") ;   
}

goBackToTopics(){
  this.router.navigate(['pages/masters/discover/']);
}

goBackToBelief(){
  
  this.router.navigate(['pages/masters/beliefDiscover/'+localStorage.getItem("prevID")]);
}

updateProfile(){
  this.router.navigateByUrl('/pages/masters/updateProfile');
}
reducePadding(){
  
  
  // (<HTMLInputElement> document.getElementById('header_two')).className="stage_top_other";
  //(<HTMLInputElement> document.getElementById('header_two')).style.padding = "0px !important";
  //(<HTMLInputElement> document.getElementById('header_two')).style.background = "red !important";
  (<HTMLInputElement> document.getElementById('header_two')).classList.add("stage_top_other");

  
}

padd(){
  (<HTMLInputElement> document.getElementById('header_two')).classList.remove("stage_top_other");

  // (<HTMLInputElement> document.getElementById('header_two')).className="stage_top";
  // (<HTMLInputElement> document.getElementById('header_two')).classList.remove("stage_top_other");
  // element.classList.remove("mystyle")
}
}

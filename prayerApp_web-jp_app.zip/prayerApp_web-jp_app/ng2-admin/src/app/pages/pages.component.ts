import { Component } from '@angular/core';
import { Routes } from '@angular/router';

import { BaMenuService } from '../theme';
import { PAGES_MENU } from './pages.menu';
import { PagesService } from 'app/pages/pages.services';
import { HttpModule } from '@angular/http';
@Component({
  selector: 'pages',
  // template: `
  //   <ba-sidebar></ba-sidebar>
  //   <ba-page-top></ba-page-top>
  //   <div class="al-main">
  //     <div class="al-content">
  //       <ba-content-top></ba-content-top>
  //       <router-outlet></router-outlet>
  //     </div>
  //   </div>
    
  //   `,


    template: `

    <ba-page-top></ba-page-top>
    <div class="al-main" style="width:100%;">
      <div class="">
        <ba-content-top></ba-content-top>
        <router-outlet></router-outlet>
      </div>
    </div>
    `,


})
export class Pages {

  
  PAGE_MENU_VALUES: any[] = [

  ];

  PAGE_MENU_VALUES_INDIVIDUAL: any[] = [
    
  ];

 PAGE_MENU_VALUES_INDIVIDUAL_CHILDREN: any[] = [
    
  ];


 constructor(private _menuService: BaMenuService, private pageservice: PagesService) {

  this.pageservice.getPosts();
  
  //  this.pageservice.getPosts().subscribe(posts => {
  //   const MENU = {
  //     path: 'pages',
  //     children: [],
  //   };
  //      //this.PAGES_MENU1= "{path:'pages',children:[";
  //      for (let i = 0; i < posts.menus.length; i++) {
  //             const  PARENT = {
  //              path: 'setup',
  //             data: {
  //               menu: {
  //                   title: 'title',
  //                   icon: 'ion-android-home',
  //                   selected: false,
  //                   expanded: false, 
  //                   order: 0,
  //               },
                
  //             },
  //             children: [
  //                 ],
  //           };
         
  //        //console.log(posts.menus[i].desc);  
  //        if (posts.menus[i].desc == 'Setup') {
  //           PARENT.path = 'setup';
  //           PARENT.data.menu.icon = 'ion-gear-a';
  //        }
  //        if (posts.menus[i].desc == 'Registration') {
  //           PARENT.path = 'masters';
  //           PARENT.data.menu.icon = 'ion-compose';
  //        } 
  //        if (posts.menus[i].desc == 'Masters') {
  //          //console.log('*********master');
  //           PARENT.path = 'masters';
  //           PARENT.data.menu.icon = 'ion-stats-bars';
  //        }
  //        if (posts.menus[i].desc == 'Transaction') {
  //           PARENT.path = 'masters';
  //           PARENT.data.menu.icon = 'ion-android-laptop';
  //        }


         
  //        PARENT.data.menu.title = posts.menus[i].desc;
         
  //        PARENT.data.menu.order = i;

  //           if (posts.menus[i].menus.length > 0) {             
                  
  //             for (let ii = 0; ii < posts.menus[i].menus.length; ii++) {
  //              // console.log('tsting');

  //                const CHILDREN = {
  //                 path: 'ckeditor',
  //                       data: {
  //                         menu: {
  //                           title: 'title',
  //                         },
  //                       },
  //               };

  //              CHILDREN.path = posts.menus[i].menus[ii].desc;
  //                CHILDREN.data.menu.title = posts.menus[i].menus[ii].desc;
  //                 PARENT.children[ii] = CHILDREN;
  //                    if (posts.menus[i].menus[ii].desc == 'Device Management') {
  //                           CHILDREN.path = 'devicemanagement';
  //                     } 
  //                     if (posts.menus[i].menus[ii].desc == 'Farmer') {
  //                           CHILDREN.path = 'farmer';
  //                     }
  //                     if (posts.menus[i].menus[ii].desc == 'Service') {
  //                           CHILDREN.path = 'service';
  //                     }
  //                     if (posts.menus[i].menus[ii].desc == 'Location') {
  //                           CHILDREN.path = 'location';
  //                     }
  //                     if (posts.menus[i].menus[ii].desc == 'Change Password') {
  //                           CHILDREN.path = 'changePassword';
  //                     }
  //                      if (posts.menus[i].menus[ii].desc == 'Location') {
  //                           CHILDREN.path = 'location';
  //                     }
  //                      if (posts.menus[i].menus[ii].desc == 'User Management') {
  //                           CHILDREN.path = 'userManagement';
  //                     }
                    
					 
  //                     // Masters
  //                     if (posts.menus[i].menus[ii].desc == 'Expense Details') {
  //                       CHILDREN.path = 'expenseDetails';
  //                     } 

  //                     if (posts.menus[i].menus[ii].desc == 'Belief Statements') {
  //                       CHILDREN.path = 'beliefStatements';
  //                     } 


					 
  //                }
                   
  //               }
              

  //             this.PAGE_MENU_VALUES_INDIVIDUAL[i] = PARENT;
               

  //           }
  //          //

  //          //MENU.children = this.PAGE_MENU_VALUES_INDIVIDUAL;
  //          MENU.children = MENU.children.concat(
  //           {
  //             path: 'dashboard',
  //             data: {
  //               menu: {
  //                 title: 'Dashboard',
  //                 icon: 'ion-android-home',
  //                 selected: false,
  //                 expanded: false,
  //                 order: 0,
  //               },
  //             },
  //           },
  //         );
  //          MENU.children = MENU.children.concat(this.PAGE_MENU_VALUES_INDIVIDUAL);
  //          //console.log(this.PAGE_MENU_VALUES_INDIVIDUAL);
  //          this.PAGE_MENU_VALUES[0] = MENU;
  //           //console.log(this.PAGE_MENU_VALUES);
  //          // console.log(PAGES_MENU);

  //       this._menuService.updateMenuByRoutes(<Routes>this.PAGE_MENU_VALUES);
  //   });
 }

  ngOnInit() {
  
    setTimeout(() => {
          // this._menuService.updateMenuByRoutes(<Routes>PAGES_MENU);
   
              //console.log('testing value');
 }, 5000);
  
  }
}



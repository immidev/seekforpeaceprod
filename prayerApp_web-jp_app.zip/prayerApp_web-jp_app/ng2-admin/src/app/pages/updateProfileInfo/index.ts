export * from './updateProfileInfo.component';

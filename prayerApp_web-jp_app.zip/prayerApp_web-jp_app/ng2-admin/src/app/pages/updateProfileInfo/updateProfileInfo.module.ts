import { NgModule }      from '@angular/core';
import { CommonModule }  from '@angular/common';
import { AppTranslationModule } from '../../app.translation.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgaModule } from '../../theme/nga.module';
import { HttpModule } from '@angular/http';


import { UpdateProfileInfo } from './updateProfileInfo.component';
import { routing } from './updateProfileInfo.routing';
import { UserUpdateProfileInfoService } from 'app/pages/updateProfileInfo/updateProfileInfo.service';


@NgModule({
  imports: [
    CommonModule,
    AppTranslationModule,
    ReactiveFormsModule,
    FormsModule,
    NgaModule,
    routing,
    HttpModule,
  ],
  declarations: [
    UpdateProfileInfo,
  ], providers: [
       UserUpdateProfileInfoService,
  ],
})
export class UpdateProfileInfoModule {}

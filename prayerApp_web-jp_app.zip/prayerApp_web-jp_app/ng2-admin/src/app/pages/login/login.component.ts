import { Component } from '@angular/core';
import { FormGroup, AbstractControl, FormBuilder, Validators } from '@angular/forms';

import { UserLoginService } from 'app/pages/login/login.service';
import { Router } from '@angular/router';
import { ViewChild,ElementRef } from '@angular/core'; 


declare var swal: any;  //For Sweet Alert
declare var google: any;  //For Sweet Alert


@Component({
  selector: ' login ',
  templateUrl: './login.html',
  styleUrls: ['./login.scss'],
})
export class Login {

  @ViewChild('inputEmail3') inputEmail3: ElementRef;
  @ViewChild('inputPassword3') inputPassword3: ElementRef;

  public form: FormGroup;
  public email: AbstractControl;
  public password: AbstractControl;
  public submitted: boolean = false;

  constructor(fb: FormBuilder, private postsService: UserLoginService, private router: Router) {

   // new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
    this.form = fb.group({
      'email': ['', Validators.compose([Validators.required, Validators.minLength(1)])],
      'password': ['', Validators.compose([Validators.required, Validators.minLength(1)])],
    });

    this.email = this.form.controls['email'];
    this.password = this.form.controls['password'];
    /*this.postsService.getPosts().subscribe(posts => {
      console.log('testing data');
      console.log(posts);
      

    });*/

  }

  public onSubmit(values: Object): void {

    // localStorage.setItem('currentUser', '1'); //comment after login servie has retuen success
    // this.router.navigate(['homeScreen']);

    setTimeout(function(){
      //console.log("hsjhsdhjfsdjh");
      (<HTMLInputElement> document.getElementById("preloader")).hidden = false;
    },100);
      // localStorage.removeItem('currentUser');
      this.submitted = true;
      if (this.form.valid) {
        if (values['email'] != null && values['password'] != null) {
          this.postsService.getPosts(values['email'], values['password']).subscribe(posts => {
            if (posts.status == '1') {
              localStorage.setItem('currentUser', 'login');
              localStorage.setItem('userId', posts.id);
              localStorage.setItem('lastname', posts.lastname);
              localStorage.setItem('firstname', posts.firstname);
              
              // if (posts.userTO.groupName == 'ADMINISTRATOR') {
              //   localStorage.setItem('passwordfield_dynamic', 'ADMINISTRATOR');
              // } else {
              //   localStorage.setItem('passwordfield_dynamic', '');
              // }
              //console.log(JSON.parse(localStorage.getItem('currentUser')).groupId);

              setTimeout(function(){
                //console.log("hsjhsdhjfsdjh");
                (<HTMLInputElement> document.getElementById("preloader")).hidden = true;
              },100);

              localStorage.setItem('reload','Y');

              this.router.navigate(['home']);
            }
            else {
  setTimeout(function(){
          //console.log("hsjhsdhjfsdjh");
          (<HTMLInputElement> document.getElementById("preloader")).hidden = true;
        },100);
                swal({ title: "Failed!", text:posts.msg, type: 'warning',})
                // (<HTMLInputElement> document.getElementById('expenseDetailsFnMode')).value = 'a';     
  
                this.inputEmail3.nativeElement.value = '';
                this.inputPassword3.nativeElement.value = '';
              // (<HTMLInputElement> document.getElementById('inputEmail3')).value = "";
              //  (<HTMLInputElement> document.getElementById('inputPassword3')).value = '';
            }
          }, (err:any) => {
            console.log(err);
           });
  
        }
      }


  
  }
}

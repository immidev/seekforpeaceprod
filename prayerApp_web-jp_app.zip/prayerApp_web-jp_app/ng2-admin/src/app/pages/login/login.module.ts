import { NgModule }      from '@angular/core';
import { CommonModule }  from '@angular/common';
import { AppTranslationModule } from '../../app.translation.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgaModule } from '../../theme/nga.module';
import { HttpModule } from '@angular/http';


import { Login } from './login.component';
import { routing } from './login.routing';
import { UserLoginService } from 'app/pages/login/login.service';


@NgModule({
  imports: [
    CommonModule,
    AppTranslationModule,
    ReactiveFormsModule,
    FormsModule,
    NgaModule,
    routing,
    HttpModule,
  ],
  declarations: [
    Login,
  ], providers: [
       UserLoginService,
  ],
})
export class LoginModule {}

import { Component } from '@angular/core';

@Component({
  selector: 'transaction',
  template: `<router-outlet></router-outlet>`,
})
export class Transaction {
  constructor() {
  }
}

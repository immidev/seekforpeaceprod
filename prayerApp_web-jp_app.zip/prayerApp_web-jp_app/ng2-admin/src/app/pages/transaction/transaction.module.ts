import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CKEditorModule } from 'ng2-ckeditor';
import { NgaModule } from '../../theme/nga.module';

import { routing } from './transaction.routing';
import { Ckeditor } from './components/ckeditor/ckeditor.component';
import { Transaction } from 'app/pages/transaction/transaction.component';
 
import { FormGroup, AbstractControl, FormBuilder, Validators } from '@angular/forms';

import { Ng2SmartTableModule } from 'ng2-smart-table';


//import { DevicemanagementService } from 'app/pages/devicemanagement/devicemanagement.service';
import { DataTableModule } from 'angular2-datatable';
import { HttpModule } from '@angular/http';

import { NgbDropdownModule, NgbModalModule } from '@ng-bootstrap/ng-bootstrap';
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    NgaModule,
    CKEditorModule,
    routing,
    Ng2SmartTableModule,
    NgbDropdownModule,
    NgbModalModule,
    DataTableModule,
  ],
  declarations: [
    Transaction,
    Ckeditor, 
  ],
  entryComponents: [
  ], providers: [
  ],
})
export class TransactionModule {
}

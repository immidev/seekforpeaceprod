import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';
import { HttpModule } from '@angular/http'; 
import * as MasterConstants from './masterconstants';
import { Headers, Response, URLSearchParams } from '@angular/http';

@Injectable()
export class PagesService {

  constructor(private http: Http, ) {
     //console.log('initialized');
  }

 getPosts() {
    console.log(localStorage.getItem('currentUser'));
    if(localStorage.getItem('currentUser')==null){
       window.location.href="login";
    }else{


      // return this.http.get(MasterConstants.WEB_URL+'getListOfMenu?usrId='+JSON.parse(localStorage.getItem('currentUser')).usrId+'&&orgId='+JSON.parse(localStorage.getItem('currentUser')).orgId+'&&locationId='+JSON.parse(localStorage.getItem('currentUser')).locationId+'&&groupId='+JSON.parse(localStorage.getItem('currentUser')).groupId).map(
      //   res => res.json()
      // );
    } 
 }


}
/*
  var headers = new Headers();
      headers.append('Content-Type', 'application/x-www-form-urlencoded');
      let urlSearchParams = new URLSearchParams();
       urlSearchParams.append('usrId',JSON.parse(localStorage.getItem('currentUser')).usrId);
      urlSearchParams.append('orgId',JSON.parse(localStorage.getItem('currentUser')).orgId); 
      urlSearchParams.append('locationId',JSON.parse(localStorage.getItem('currentUser')).locationId);
      urlSearchParams.append('groupId',JSON.parse(localStorage.getItem('currentUser')).groupId);
      let body = urlSearchParams.toString(); 
      return this.http.post(MasterConstants.WEB_URL + '/getListOfMenu', body, {
          headers: headers
      }).map(res => res.json());  

      */
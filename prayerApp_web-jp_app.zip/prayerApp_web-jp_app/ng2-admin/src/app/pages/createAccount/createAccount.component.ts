import { Component } from '@angular/core';
import { FormGroup, AbstractControl, FormBuilder, Validators } from '@angular/forms';
import { EmailValidator, EqualPasswordsValidator } from '../../theme/validators';

import { UserCreateAccountService } from 'app/pages/createAccount/createAccount.service';
import { Router } from '@angular/router';
import { ViewChild,ElementRef } from '@angular/core'; 


declare var swal: any;  //For Sweet Alert
declare var google: any;  //For Sweet Alert


@Component({
  selector: ' createAccount ',
  templateUrl: './createAccount.html',
  styleUrls: ['./createAccount.scss'],
})
export class CreateAccount {

  @ViewChild('inputEmail3') inputEmail3: ElementRef;
  @ViewChild('inputPassword3') inputPassword3: ElementRef;

  public form: FormGroup;
  public username;
  public username1;
  public email;
  public passwords;
  public confirmpasswords;

  constructor(fb: FormBuilder, private postsService: UserCreateAccountService, private router: Router) {

   // new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
    this.form = fb.group({
      'username': ['', Validators.compose([Validators.required])],
      'username1': ['', Validators.compose([Validators.required])],
      'email': ['', Validators.compose([Validators.required, EmailValidator.validate])],
      'passwords': ['', Validators.compose([Validators.required])],
      'confirmpasswords': ['', Validators.compose([Validators.required])],
    });

    // this.email = this.form.controls['email'];
    // this.passwords = this.form.controls['passwords'];
    // this.confirmpasswords = this.form.controls['confirmpasswords'];
    /*this.postsService.getPosts().subscribe(posts => {
      console.log('testing data');
      console.log(posts);
      

    });*/

  }
  onSubmit(values) {

    if (this.passwords == this.confirmpasswords) {
      this.postsService.registeruser(values).subscribe(posts => {
        console.log(posts);
        console.log(posts.status);
        if (posts.status == '1') {
          localStorage.setItem('currentUser', 'val');
    localStorage.setItem('currentUser', 'login');
    localStorage.setItem('userId', posts.id);
          //  if(posts.userTO.groupName == 'ADMINISTRATOR'){
          //     localStorage.setItem('passwordfield_dynamic', 'ADMINISTRATOR');  
          //  }else{
          //   localStorage.setItem('passwordfield_ dynamic', '');  
          //  }
          this.router.navigate(['membership']);
        }
        else {
          swal({ title: "Failed!", text:posts.msg, type: 'warning',});

          // (<HTMLInputElement>document.getElementById("errorMsg")).style.display = 'block';
          // (<HTMLInputElement>document.getElementById("errorMsg")).innerHTML = posts.msg;
        }
      });
    } else {
      swal({ title: "Invalid Password and Confirm Password!", type: 'warning',})

      this.passwords = '';
      this.confirmpasswords = '';
    }
    //this.router.navigate(['membership']);
  }
}

import { NgModule }      from '@angular/core';
import { CommonModule }  from '@angular/common';
import { AppTranslationModule } from '../../app.translation.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgaModule } from '../../theme/nga.module';
import { HttpModule } from '@angular/http';


import { CreateAccount } from './createAccount.component';
import { routing } from './createAccount.routing';
import { UserCreateAccountService } from 'app/pages/createAccount/createAccount.service';


@NgModule({
  imports: [
    CommonModule,
    AppTranslationModule,
    ReactiveFormsModule,
    FormsModule,
    NgaModule,
    routing,
    HttpModule,
  ],
  declarations: [
    CreateAccount,
  ], providers: [
       UserCreateAccountService,
  ],
})
export class CreateAccountModule {}

import { NgModule }      from '@angular/core';
import { CommonModule }  from '@angular/common';

import { routing }       from './pages.routing';
import { NgaModule } from '../theme/nga.module';
import { AppTranslationModule } from '../app.translation.module';

import { Pages } from './pages.component';
import { PagesService } from 'app/pages/pages.services';
import { HttpModule } from '@angular/http';

@NgModule({
  imports: [CommonModule, AppTranslationModule, NgaModule, routing, HttpModule],
  declarations: [Pages],
  providers: [PagesService],
})
export class PagesModule {
}

import { Component } from '@angular/core';
import { FormGroup, AbstractControl, FormBuilder, Validators } from '@angular/forms';

import { UserMembershipService } from 'app/pages/membership/membership.service';
import { Router } from '@angular/router';
import { ViewChild,ElementRef } from '@angular/core'; 


declare var swal: any;  //For Sweet Alert
declare var google: any;  //For Sweet Alert


@Component({
  selector: ' membership ',
  templateUrl: './membership.html',
  styleUrls: ['./membership.scss'],
})
export class Membership {

  @ViewChild('inputEmail3') inputEmail3: ElementRef;
  @ViewChild('inputPassword3') inputPassword3: ElementRef;

  public form: FormGroup;
  public email: AbstractControl;
  public password: AbstractControl;
  public submitted: boolean = false;

  constructor(fb: FormBuilder, private postsService: UserMembershipService, private router: Router) {

   

  }

  public onSubmit(){

    // alert(this.subValue);
    // alert(this.duration);
    this.postsService.updatePayment(this.subValue, this.duration).subscribe(posts => {
      if (posts.status == '1') {
       // alert("success");
        this.router.navigate(['/pages/masters/updateProfile']);
      }
    });
  
  }

  subValue ='MonthSub';
  duration = '365';
  selectPayment(selectedValue){
    //alert("hello");
    if(selectedValue == 'free'){

      this.subValue = 'free';
      this.duration = '45'

      //setting color for free
      $('#free').css("background-color","#FF9800")
      $('#free1').css("background-color","#fbc72b85")
      $('#free1').css("border","1px solid #696d69")
      $('#freecheck').css("color","#696d69")
      
      //changing color for other two
      $('#MonthSub').css("background-color","#258231d1")
      $('#MonthSub1').css("background-color","#f3f3f3")
      $('#MonthSub1').css("border","1px solid #696d694a")
      $('#MonthSubcheck').css("color","#696d6973")

      //changing color for frndssub
      $('#frndsSub').css("background-color","#258231d1")
      $('#frndsSub1').css("background-color","#f3f3f3")
      $('#frndsSub1').css("border","1px solid #696d694a")
      $('#frndsSubcheck').css("color","#696d6973")


    }
    else if(selectedValue == 'MonthSub'){

      this.subValue = 'MonthSub';
      this.duration = '365'
      //setting color for free
      $('#free').css("background-color","#258231d1")
      $('#free1').css("background-color","#f3f3f3")
      $('#free1').css("border","1px solid #696d694a")
      $('#freecheck').css("color","#696d6973")
      
      //changing color for other two
      $('#MonthSub').css("background-color","#FF9800")
      $('#MonthSub1').css("background-color","#fbc72b85")
      $('#MonthSub1').css("border","1px solid #696d69")
      $('#MonthSubcheck').css("color","#696d69")

      //changing color for frndssub
      $('#frndsSub').css("background-color","#258231d1")
      $('#frndsSub1').css("background-color","#f3f3f3")
      $('#frndsSub1').css("border","1px solid #696d694a")
      $('#frndsSubcheck').css("color","#696d6973")
    }
    else if(selectedValue == 'frndsSub'){
      this.subValue = 'frndsSub';
      this.duration = '90'
      //setting color for free
      $('#free').css("background-color","#258231d1")
      $('#free1').css("background-color","#f3f3f3")
      $('#free1').css("border","1px solid #696d694a")
      $('#freecheck').css("color","#696d6973")
      
      //changing color for other two
      $('#MonthSub').css("background-color","#258231d1")
      $('#MonthSub1').css("background-color","#f3f3f3")
      $('#MonthSub1').css("border","1px solid #696d694a")
      $('#MonthSubcheck').css("color","#696d6973")

      //changing color for frndssub
      $('#frndsSub').css("background-color","#FF9800")
      $('#frndsSub1').css("background-color","#fbc72b85")
      $('#frndsSub1').css("border","1px solid #696d69")
      $('#frndsSubcheck').css("color","#696d69")
    }
  }
}

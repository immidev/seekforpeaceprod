import { NgModule }      from '@angular/core';
import { CommonModule }  from '@angular/common';
import { AppTranslationModule } from '../../app.translation.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgaModule } from '../../theme/nga.module';
import { HttpModule } from '@angular/http';


import { Membership } from './membership.component';
import { routing } from './membership.routing';
import { UserMembershipService } from 'app/pages/membership/membership.service';


@NgModule({
  imports: [
    CommonModule,
    AppTranslationModule,
    ReactiveFormsModule,
    FormsModule,
    NgaModule,
    routing,
    HttpModule,
  ],
  declarations: [
    Membership,
  ], providers: [
       UserMembershipService,
  ],
})
export class MembershipModule {}

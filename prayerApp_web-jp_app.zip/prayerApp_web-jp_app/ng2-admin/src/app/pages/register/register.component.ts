import { Component } from '@angular/core';
import { FormGroup, AbstractControl, FormBuilder, Validators } from '@angular/forms';
import { EmailValidator, EqualPasswordsValidator } from '../../theme/validators';
import { Router } from '@angular/router';
import { UserLoginService } from 'app/pages/login/login.service';
declare var swal: any;  //For Sweet Alert


@Component({
  selector: 'register',
  templateUrl: './register.html',
  styleUrls: ['./register.scss']
})
export class Register {

  public form: FormGroup;
  public username;
  public email;
  public passwords;
  public confirmpasswords;
  // public repeatPassword:AbstractControl;
  // public passwords:FormGroup;
  // 
  public submitted: boolean = false;

  constructor(fb: FormBuilder, private postsService: UserLoginService, private router: Router) {

    this.form = fb.group({
      'username': ['', Validators.compose([Validators.required])],
      'email': ['', Validators.compose([Validators.required, EmailValidator.validate])],
      'passwords': ['', Validators.compose([Validators.required])],
      'confirmpasswords': ['', Validators.compose([Validators.required])],
    });

  }

  onSubmit(values) {

    if (this.passwords == this.confirmpasswords) {
      this.postsService.registeruser(values).subscribe(posts => {
        console.log(posts);
        console.log(posts.status);
        if (posts.status == '1') {
          localStorage.setItem('currentUser', 'val');
          //  if(posts.userTO.groupName == 'ADMINISTRATOR'){
          //     localStorage.setItem('passwordfield_dynamic', 'ADMINISTRATOR');  
          //  }else{
          //   localStorage.setItem('passwordfield_ dynamic', '');  
          //  }
          this.router.navigate(['dashboard']);
        }
        else {
          swal({ title: "Failed!", text:posts.msg, type: 'warning',});

          // (<HTMLInputElement>document.getElementById("errorMsg")).style.display = 'block';
          // (<HTMLInputElement>document.getElementById("errorMsg")).innerHTML = posts.msg;
        }
      });
    } else {
      swal({ title: "Invalid Password and Confirm Password!", type: 'warning',})

      this.passwords = '';
      this.confirmpasswords = '';
    }

  }
}

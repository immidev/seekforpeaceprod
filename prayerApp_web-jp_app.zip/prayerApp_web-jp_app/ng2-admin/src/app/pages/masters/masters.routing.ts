import { Routes, RouterModule }  from '@angular/router';

import { Masters } from 'app/pages/masters/masters.component';
import { ExpenseDetails } from './components/expenseDetails/expenseDetails.component';
import { BeliefStatements } from './components/beliefStatements/beliefStatements';
import { SearchBelief } from './components/searchBelief/searchBelief';
import { HomeScreen } from './components/homeScreen/homeScreen';
import { Topics } from './components/topics/topics';
import { Notes } from './components/note/notes';
import { Bookmarks } from './components/bookmarks/bookmarks';
import { Books } from './components/books/books';
import { Discover } from './components/discover/discover';
import { BeliefDiscover } from './components/beliefDiscover/beliefDiscover';

import { Discover2 } from './components/discover2/discover2';
import { UpdateProfile } from './components/updateProfile/updateProfile';
import { FreeCopies } from './components/freeCopies/freeCopies';
import { Home } from './components/home/home';
//import { Home } from './components/home/home';

// noinspection TypeScriptValidateTypes
const routes: Routes = [
  {
    path: '',
    component: Masters,
    children: [
      // { path: '', redirectTo: 'homeScreen', pathMatch: 'full' },
      { path: 'expenseDetails', component: ExpenseDetails},
      // { path: 'beliefStatements', component: BeliefStatements},
      { path: 'searchBelief', component: SearchBelief},
      { path: 'homeScreen', component: HomeScreen},

      { path: 'beliefStatements/:id', component: BeliefStatements },
      { path: 'topics/:id', component: Topics },
      { path: 'notes', component: Notes },
      { path: 'bookmarks', component: Bookmarks },
      { path: 'books', component: Books },
      { path: 'discover', component: Discover },
      { path: 'beliefDiscover/:id', component: BeliefDiscover },
      { path: 'discover2/:id/:index', component: Discover2 },
      { path: 'updateProfile', component: UpdateProfile },
      { path: 'freeCopies', component: FreeCopies },
      { path: 'home', component: Home },

    
      
      
      


    ],
  },
];

export const routing = RouterModule.forChild(routes);

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { CKEditorModule } from 'ng2-ckeditor';
import { NgaModule } from '../../theme/nga.module';
import { HttpModule } from '@angular/http';
import { routing } from './masters.routing';

import { Masters } from 'app/pages/masters/masters.component';
import { Ng2SmartTableModule } from 'ng2-smart-table';
import { NgbDropdownModule, NgbModalModule, NgbTabsetModule, NgbModule, NgbAccordionModule } from '@ng-bootstrap/ng-bootstrap';
import {  NgbTypeaheadModule, NgbDatepickerModule } from '@ng-bootstrap/ng-bootstrap';
import { NgbDateStruct, NgbCalendar, NgbCalendarIslamicCivil, NgbDatepickerI18n, NgbPaginationModule, NgbTabset } from '@ng-bootstrap/ng-bootstrap';
import { DataTableModule } from 'angular2-datatable';
import { Typeahead } from 'ng2-typeahead-master';
import { FormGroup, AbstractControl, FormBuilder, Validators } from '@angular/forms';

import {  HotTableModule } from 'ng2-handsontable';
import { ExpenseDetails } from './components/expenseDetails/expenseDetails.component';
import { ExpenseDetailsListV } from './components/expenseDetails/expenseDetailslistv.componenet';
import { ExpenseDetailsService } from './components/expenseDetails/expenseDetails.service';
import { ExpenseDetailsInfoVW } from './components/expenseDetails/expenseDetailsInfoVW';
import { UserManagementService } from 'app/pages/setup/components/userManagement/userManagement.service';

//magzentine
import { BeliefStatements } from './components/beliefStatements/beliefStatements';
import { SearchBelief } from './components/searchBelief/searchBelief';
import { HomeScreen } from './components/homeScreen/homeScreen';
import { MastersService } from './masters.service';
import { BeliefStatementInfoVW } from './components/beliefStatements/beliefStatementInfoVW';
import { Topics } from './components/topics/topics';
import { Notes } from './components/note/notes';
import { Bookmarks } from './components/bookmarks/bookmarks';
import { Books } from './components/books/books';
import { GetInfo } from './components/books/getInfo';
import { Discover } from './components/discover/discover';
import { BeliefDiscover } from './components/beliefDiscover/beliefDiscover';
import { Discover2InfoVW } from './components/discover2/discover2InfoVW';
import { Discover2 } from './components/discover2/discover2';
import { UpdateProfile } from './components/updateProfile/updateProfile';
import { AppTranslationModule } from 'app/app.translation.module';
import { UserUpdateProfileService } from './components/updateProfile/updateProfile.service';
import { FreeCopies } from './components/freeCopies/freeCopies';
import { UserFreeCopiesService } from './components/freeCopies/freeCopies.service';
import { Home } from './components/home/home';
// import { UpdateProfileModule } from './components/updateProfile/updateProfile.module';



@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AppTranslationModule,
    NgaModule,
    NgbModule,
    CKEditorModule,
    routing,
    Ng2SmartTableModule,
     NgbDropdownModule,
    NgbModalModule,
    DataTableModule,
    NgbTabsetModule,
    NgbTypeaheadModule,
    NgbDatepickerModule,
    NgbAccordionModule,
    NgbPaginationModule,
    HotTableModule,
    
      
  ],
  declarations: [
    Masters,
    Typeahead,
    ExpenseDetails,
    ExpenseDetailsListV,
    ExpenseDetailsInfoVW,

    //magzentine
    BeliefStatements,
    BeliefStatementInfoVW,
    SearchBelief,
    HomeScreen,
    Topics,
    Notes,
    Bookmarks,
    Books,
    GetInfo,
    Discover,
    BeliefDiscover,
    Discover2,
    Discover2InfoVW,
    UpdateProfile,
    FreeCopies,
    Home



  ],

  entryComponents: [
   ExpenseDetailsInfoVW,
   BeliefStatementInfoVW,
   GetInfo,
   Discover2InfoVW

  ], 
  
  providers: [
    NgbTabset,
    UserManagementService,
    ExpenseDetailsService,
    MastersService,
    UserUpdateProfileService,
    UserFreeCopiesService
    // UpdateProfileModule
  ],
  bootstrap: [

  ],
   exports: [
        Typeahead,
      ],
})
export class MastersModule {
}

import { Component, OnInit, Inject, ElementRef, AfterViewInit, group } from '@angular/core';
import { NgbModal, NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { LocalDataSource } from 'ng2-smart-table';
import { HttpModule } from '@angular/http';
import { Typeahead } from 'ng2-typeahead-master';


import { Observable } from 'rxjs/Observable';
import { ViewChild } from '@angular/core'; 
import { BaSidebar } from 'app/theme/components/baSidebar/baSidebar.component';
import { Router } from '@angular/router';

@Component({
  selector: 'searchBelief',
  styleUrls: ['./searchBelief.scss'],
  templateUrl: './searchBelief.html',   
})
export class SearchBelief {

  padd;
  @ViewChild(BaSidebar) basidebar: BaSidebar;
  
  constructor(private router: Router) {
  

  }

  public toggleMenu() {
    this.basidebar.sidemenutoggle();
    this.resetMethod();
  }
  


  resetMethod(){
    if (this.padd == "sidemenu") {
      this.padd = "";
    (<HTMLInputElement> document.getElementById('toggleMenu')).style.display = 'contents';

    } else {
      this.padd = "sidemenu";
    (<HTMLInputElement> document.getElementById('toggleMenu')).style.display = 'none';

    }

  }



 
  beliefStatement(){
    this.router.navigate([localStorage.getItem('prevpage')]);
  }
  
}


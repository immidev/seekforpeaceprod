import { Component, OnInit, Inject, ElementRef, AfterViewInit, group } from '@angular/core';
import { NgbModal, NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { LocalDataSource } from 'ng2-smart-table';
import { HttpModule } from '@angular/http';
import { Typeahead } from 'ng2-typeahead-master';
import { ExpenseDetailsService } from 'app/pages/masters/components/expenseDetails/expenseDetails.service';

import { ExpenseDetailsListV } from 'app/pages/masters/components/expenseDetails/expenseDetailslistv.componenet';

import { Observable } from 'rxjs/Observable';
import { ViewChild } from '@angular/core'; 
import { ExpenseDetailsInfoVW } from 'app/pages/masters/components/expenseDetails/expenseDetailsInfoVW';

const statesWithFlags = [ ]; 

@Component({
  selector: 'expenseDetails',
  styleUrls: ['./expenseDetails.scss'],
  templateUrl: './expenseDetails.component.html',   
})
export class ExpenseDetails {
  @ViewChild(ExpenseDetailsListV) a: ExpenseDetailsListV;
  @ViewChild('searchState') searchState: ElementRef;
  @ViewChild('searchDistrict') searchDistrict: ElementRef;
  @ViewChild('searchFromDate') searchFromDate: ElementRef;
  @ViewChild('searchToDate') searchToDate: ElementRef;
  @ViewChild('searchBranch') searchBranch: ElementRef;
  @ViewChild('searchStatus') searchStatus: ElementRef;
  @ViewChild('searchUserName') searchUserName: ElementRef;
  @ViewChild('searchDealerName') searchDealerName: ElementRef;
  @ViewChild('searchShowValue') searchShowValue: ElementRef;
  @ViewChild('searchExpenseNo') searchExpenseNo: ElementRef;



  dealerListCombo: any[] =[];
  groupNameCredentials;
  employeeCodeList;
  expenseNoCombo: any[] =[];
  // selectedState: StateCombo;
  // stateList = [  
  //   new StateCombo(1, 'Odisha' ),
  //   new StateCombo(2, 'TamilNadu' ), 
  // ];

  fruitName: string;
  fruits: any[] = [];
  datePicker = {
    EndDt: null,
    StartDt: null
  };

  selectedFruit: any = this.fruits[0];
  
  constructor(private modalService: NgbModal, private service: ExpenseDetailsService) {
    this.groupNameCredentials=JSON.parse(localStorage.getItem('currentUser')).groupName;

    this.service.userGroupAccess("Expense Details").subscribe(posts =>{ 
      //(<HTMLInputElement> document.getElementById("expenseDetailsAdd")).disabled = posts.list[0].add;
      (<HTMLInputElement> document.getElementById("expenseDetailsEdit")).disabled = posts.list[0].edit;
      (<HTMLInputElement> document.getElementById("expenseDetailsView")).disabled = posts.list[0].view;
      //(<HTMLInputElement> document.getElementById("guestRegistrationDelete")).disabled = posts.list[0].delete;
      
    });

    this.service.getPosts_expenseDetails().subscribe(posts => {
      this.expenseNoCombo = posts.listOfExpenseDetails;
});

 

    
this.service.getBranchDetails().subscribe(posts => {
  //console.log('+++++++++++++++++++++++++++++++++++');
 // console.log(posts);
       this.fruits = posts.listSalesDealerMasterTO;
        console.log(this.fruits);
   });


   
   if(this.groupNameCredentials=='ADMINISTRATOR' || this.groupNameCredentials=='WTD'){
    this.service.getSalespersonregistrationNameCombo().subscribe(posts => {
      this.employeeCodeList =     posts.salespersonregistrationList;
      console.log(this.employeeCodeList);
     
  });   
  }else{
    this.service.getSalesAdminAccessEmpID().subscribe(posts => {
      this.employeeCodeList =     posts.salespersonregistrationList;
      console.log(this.employeeCodeList);
    
  }); 
  }

  }

  stateSearchCombo;
  districtSearchCombo;
  districtReadOnly:any =true;


 

lgModalShow() {
     //console.log('testingggg');
     const activeModal = this.modalService.open(ExpenseDetailsInfoVW, { size: 'lg',backdrop :'static' });
     setTimeout(() => {
     (<HTMLInputElement> document.getElementById('expenseDetailsFnMode')).value = 'a';     
     (<HTMLInputElement> document.getElementById('expenseCreationDtlId')).value ='';
     (<HTMLInputElement> document.getElementById('expenseDetailsLocationId')).value = '';
     (<HTMLInputElement> document.getElementById('expenseDetailsLocationName')).value = '';
     (<HTMLInputElement> document.getElementById('createdDt')).value = '';
     (<HTMLInputElement> document.getElementById('createdBy')).value ='';
     let today = new Date();
            let dd = today.getDate();
            let mm = today.getMonth()+1; //January is 0!
            let yyyy = today.getFullYear();
            ( < HTMLInputElement > document.getElementById('expenseDetailsDate')).value = (yyyy+'-'+(mm<10?('0'+mm):mm)+'-'+(dd<10?('0'+dd):dd));
    activeModal.componentInstance.modalHeader = 'Large Modal';
  }, 100);
  }
  testing() {
    //console.log('tsting');
  }

source: LocalDataSource = new LocalDataSource();
  editModalShow() {   
    var groupId= JSON.parse(localStorage.getItem('currentUser')).groupId;
    var groupName= JSON.parse(localStorage.getItem('currentUser')).groupName;
   if(this.a.selectedExpenseCreationDtlId!=null && this.a.selectedExpenseCreationDtlId!=""){

     console.log("==========================");
     console.log("<><><><><><>");
     console.log(this.a.selectedExpenseCreationDtlId['expenseCreationDtlId']);
     console.log(this.a.selectedExpenseCreationDtlId['updatedBy']);
     console.log(this.a.selectedExpenseCreationDtlId);
     this.service.getExpenseDtlLastUpdateCheck(this.a.selectedExpenseCreationDtlId['expenseCreationDtlId'],this.a.selectedExpenseCreationDtlId['updatedBy'],this.a.selectedExpenseCreationDtlId['empNo']).subscribe(posts => {
              console.log(posts);
              console.log(posts.userId);
              console.log(JSON.parse(localStorage.getItem('currentUser')).userId);

              if(posts.userId==JSON.parse(localStorage.getItem('currentUser')).userId){
                console.log(groupId);
                console.log((this.a.rowItem['conApprovedAmtByBm']));
                
                console.log((this.a.rowItem['conApprovedAmtByBm']));
                console.log((this.a.rowItem['allowanceApprovedAmtByBm']));
                console.log(( (this.a.rowItem['conApprovedAmtByBm'] == ""  && 
                this.a.rowItem['conApprovedAmtByBm'] =="" && 
                this.a.rowItem['allowanceApprovedAmtByBm'] =="")));
                console.log((groupId == "34" && (this.a.rowItem['conApprovedAmtByBm'] == ""  && 
                this.a.rowItem['conApprovedAmtByBm'] =="" && 
                this.a.rowItem['allowanceApprovedAmtByBm'] =="")));
                console.log("=========================="); 
            
                
                const activeModal = this.modalService.open(ExpenseDetailsInfoVW, { size: 'lg' ,backdrop :'static'});
                setTimeout(() => {
                (<HTMLInputElement> document.getElementById('expenseCreationDtlId')).value = this.a.rowItem['expenseCreationDtlId'];
            
                (<HTMLInputElement> document.getElementById('expenseCreationNo')).value = this.a.rowItem['expenseCreationNo'];
                (<HTMLInputElement> document.getElementById('date')).value = this.a.rowItem['date'];
                (<HTMLInputElement> document.getElementById('expName')).value = this.a.rowItem['expName'];
                  (<HTMLInputElement> document.getElementById('empNo')).value = this.a.rowItem['empNo'];
                (<HTMLInputElement> document.getElementById('employeeName')).value = this.a.rowItem['employeeName'];
                (<HTMLInputElement> document.getElementById('visitPlanNo')).value = this.a.rowItem['visitPlanNo'];
                (<HTMLInputElement> document.getElementById('visitPlanDate')).value = this.a.rowItem['visitPlanDate'];
                (<HTMLInputElement> document.getElementById('dealerDistributor')).value = this.a.rowItem['dealerDistributor'];
                (<HTMLInputElement> document.getElementById('state')).value = this.a.rowItem['state'];
                (<HTMLInputElement> document.getElementById('city')).value = this.a.rowItem['city'];
                (<HTMLInputElement> document.getElementById('transport')).value = this.a.rowItem['transport'];
                (<HTMLInputElement> document.getElementById('conSlabAmt')).value = this.a.rowItem['conSlabAmt'];
                (<HTMLInputElement> document.getElementById('conClaimActual')).value = this.a.rowItem['conClaimActual'];
                (<HTMLInputElement> document.getElementById('conSpecialApproval')).value = this.a.rowItem['conSpecialApproval'];
                (<HTMLInputElement> document.getElementById('conveyanceRemark')).value = this.a.rowItem['conveyanceRemark'];
               // (<HTMLInputElement> document.getElementById('conProofOfDocument')).value = this.a.rowItem['conProofOfDocument'];
                (<HTMLInputElement> document.getElementById('conApprovedAmtByBm')).value = this.a.rowItem['conApprovedAmtByBm'];
                (<HTMLInputElement> document.getElementById('conApprovedAmtByRsm')).value = this.a.rowItem['conApprovedAmtByRsm'];
                (<HTMLInputElement> document.getElementById('conApprovedAmtByDgmGm')).value = this.a.rowItem['conApprovedAmtByDgmGm'];
                (<HTMLInputElement> document.getElementById('conApprovedAmtByGm')).value = this.a.rowItem['conApprovedAmtByGm'];
                (<HTMLInputElement> document.getElementById('conApprovedAmtByDirectors')).value = this.a.rowItem['conApprovedAmtByDirectors'];
                (<HTMLInputElement> document.getElementById('conApprovedAmtByFinance')).value = this.a.rowItem['conApprovedAmtByFinance'];
            
                   (<HTMLInputElement> document.getElementById('boardingSlabAmt')).value = this.a.rowItem['boardingSlabAmt'];
                    (<HTMLInputElement> document.getElementById('boardingClaimActual')).value = this.a.rowItem['boardingClaimActual'];
                (<HTMLInputElement> document.getElementById('boardingSpecialApproval')).value = this.a.rowItem['boardingSpecialApproval'];
                (<HTMLInputElement> document.getElementById('boardingRemark')).value = this.a.rowItem['boardingRemark'];
               // (<HTMLInputElement> document.getElementById('boardingProofOfDocument')).value = this.a.rowItem['boardingProofOfDocument'];
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByBm')).value = this.a.rowItem['boardingApprovedAmtByBm'];
                    (<HTMLInputElement> document.getElementById('boardingApprovedAmtByRsm')).value = this.a.rowItem['boardingApprovedAmtByRsm'];
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByDgmGm')).value = this.a.rowItem['boardingApprovedAmtByDgmGm'];
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByGm')).value = this.a.rowItem['boardingApprovedAmtByGm'];
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByDirectors')).value = this.a.rowItem['boardingApprovedAmtByDirectors'];
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByFinance')).value = this.a.rowItem['boardingApprovedAmtByFinance'];
            
                       (<HTMLInputElement> document.getElementById('allowanceSlabAmt')).value = this.a.rowItem['allowanceSlabAmt'];
                    (<HTMLInputElement> document.getElementById('allowanceClaimActual')).value = this.a.rowItem['allowanceClaimActual'];
                    console.log( (<HTMLInputElement> document.getElementById('allowanceClaimActual')).value);
                (<HTMLInputElement> document.getElementById('allowanceSpecialApproval')).value = this.a.rowItem['allowanceSpecialApproval'];
                (<HTMLInputElement> document.getElementById('allowanceRemark')).value = this.a.rowItem['allowanceRemark'];
              //  (<HTMLInputElement> document.getElementById('allowanceProofOfDocument')).value = this.a.rowItem['allowanceProofOfDocument'];
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByBm')).value = this.a.rowItem['allowanceApprovedAmtByBm'];
                    (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByRsm')).value = this.a.rowItem['allowanceApprovedAmtByRsm'];
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByDgmGm')).value = this.a.rowItem['allowanceApprovedAmtByDgmGm'];
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByGm')).value = this.a.rowItem['allowanceApprovedAmtByGm'];
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByDirectors')).value = this.a.rowItem['allowanceApprovedAmtByDirectors'];
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByFinance')).value = this.a.rowItem['allowanceApprovedAmtByFinance'];
                (<HTMLInputElement> document.getElementById('conveyanceFlagId')).value = this.a.rowItem['conveyanceAll'];
                (<HTMLInputElement> document.getElementById('boardingFlagId')).value = this.a.rowItem['boardingAll'];
                (<HTMLInputElement> document.getElementById('allowanceFlageId')).value = this.a.rowItem['allowanceAll'];
                (<HTMLInputElement> document.getElementById('totalCheckExpenseTypes')).value = this.a.rowItem['totalCheckExpenseTypes'];
                
                // (<HTMLInputElement> document.getElementById('totalSlabAmt')).value = this.a.rowItem['totalSlabAmt'];
                // (<HTMLInputElement> document.getElementById('totalClaimAmt')).value = this.a.rowItem['totalClaimAmt'];
                // (<HTMLInputElement> document.getElementById('finalApprovedAmt')).value = this.a.rowItem['finalApprovedAmt'];
                // (<HTMLInputElement> document.getElementById('status')).value = this.a.rowItem['status'];
              
              //ADMIN / FINANCE START
              let claim_amount= 0;
              let slab_amount=0;
              let approved_amount=0;
              if(this.a.rowItem['conClaimActual']!=null && this.a.rowItem['conClaimActual']!='' && this.a.rowItem['conClaimActual']!='null'){
                  claim_amount += parseInt(this.a.rowItem['conClaimActual']);
              }
              if(this.a.rowItem['boardingClaimActual']!=null && this.a.rowItem['boardingClaimActual']!='' && this.a.rowItem['boardingClaimActual']!='null'){
                  claim_amount += parseInt(this.a.rowItem['boardingClaimActual']);
              }
              if(this.a.rowItem['allowanceClaimActual']!=null && this.a.rowItem['allowanceClaimActual']!='' && this.a.rowItem['allowanceClaimActual']!='null'){
                  claim_amount += parseInt(this.a.rowItem['allowanceClaimActual']);
              }    


              if(this.a.rowItem['conSlabAmt']!=null && this.a.rowItem['conSlabAmt']!=''&& this.a.rowItem['conSlabAmt']!='null'){
                  slab_amount += parseInt(this.a.rowItem['conSlabAmt']);
              }
              if(this.a.rowItem['boardingSlabAmt']!=null && this.a.rowItem['boardingSlabAmt']!='' && this.a.rowItem['boardingSlabAmt']!='null'){
                  slab_amount += parseInt(this.a.rowItem['boardingSlabAmt']);
              }
              if(this.a.rowItem['allowanceSlabAmt']!=null && this.a.rowItem['allowanceSlabAmt']!='' && this.a.rowItem['allowanceSlabAmt']!='null'){
                slab_amount += parseInt(this.a.rowItem['allowanceSlabAmt']);
              }

              if(this.a.rowItem['allowanceApprovedAmtByFinance']!=null && this.a.rowItem['allowanceApprovedAmtByFinance']!=''&& this.a.rowItem['allowanceApprovedAmtByFinance']!='null'){
                approved_amount += parseInt(this.a.rowItem['allowanceApprovedAmtByFinance']);
              }
              if(this.a.rowItem['boardingApprovedAmtByFinance']!=null && this.a.rowItem['boardingApprovedAmtByFinance']!='' && this.a.rowItem['boardingApprovedAmtByFinance']!='null'){
                approved_amount += parseInt(this.a.rowItem['boardingApprovedAmtByFinance']);
              }
              if(this.a.rowItem['conApprovedAmtByFinance']!=null && this.a.rowItem['conApprovedAmtByFinance']!='' && this.a.rowItem['conApprovedAmtByFinance']!='null'){
                approved_amount += parseInt(this.a.rowItem['conApprovedAmtByFinance']);
              }


              console.log("++++++++++++++");
              console.log("slab amount"+String(slab_amount));
              console.log("claim amount"+String(claim_amount));
              console.log("Approved amount"+String(approved_amount));
              console.log("c path"+this.a.rowItem['c_FilePath']);
             console.log("c bL_Filepath"+this.a.rowItem['bL_Filepath']);
              console.log("c a_Filepath"+this.a.rowItem['a_Filepath']);
              console.log("-------------------");
            (<HTMLInputElement> document.getElementById('totalSlabAmt')).value = String(slab_amount);
            (<HTMLInputElement> document.getElementById('totalClaimAmt')).value =String(claim_amount);
            (<HTMLInputElement> document.getElementById('finalAppprovedAmt')).value =String(approved_amount);
            (<HTMLInputElement> document.getElementById('status')).value =this.a.rowItem['status'];
            (<HTMLInputElement> document.getElementById('cPath')).value =this.a.rowItem['c_FilePath'];
            (<HTMLInputElement> document.getElementById('blPath')).value =this.a.rowItem['bL_Filepath'];
            (<HTMLInputElement> document.getElementById('aPath')).value =this.a.rowItem['a_Filepath'];


         
              //BM start
            
                if(groupName=="BRANCH MANAGER" || groupName=="BM"){
                  console.log("entering inside 23");
            
                  (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByBmLabelDiv')).style.display="block";
                  (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByBmFormDiv')).style.display="block";
            
                  (<HTMLInputElement> document.getElementById('boardingApprovedAmtByBmLabelDiv')).style.display="block";
                  (<HTMLInputElement> document.getElementById('boardingApprovedAmtByBmFormDiv')).style.display="block";
            
                  (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByBmLabelDiv')).style.display="block";
                  (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByBmFormDiv')).style.display="block";
            
                }
              //BM end
            
                //Rsm start
            
                if(groupName=="RSM"){
                  console.log("entering inside 34");
                  (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByRsmLabelDiv')).style.display="block";
                  (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByRsmFormDiv')).style.display="block";
            
                  (<HTMLInputElement> document.getElementById('boardingApprovedAmtByRsmLabelDiv')).style.display="block";
                  (<HTMLInputElement> document.getElementById('boardingApprovedAmtByRsmFormDiv')).style.display="block";
            
                  (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByRsmLabelDiv')).style.display="block";
                  (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByRsmFormDiv')).style.display="block";
                  
                  if(this.a.rowItem['conApprovedAmtByBm']!=''){
                    (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByBmLabelDiv')).style.display="block";
                    (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByBmFormDiv')).style.display="block";
                    (<HTMLInputElement> document.getElementById('conApprovedAmtByBm')).style.backgroundColor='#ffff75';
                    (<HTMLInputElement> document.getElementById('conApprovedAmtByBm')).readOnly = true;
                  }
                  if(this.a.rowItem['boardingApprovedAmtByBm']!=''){
                    (<HTMLInputElement> document.getElementById('boardingApprovedAmtByBmLabelDiv')).style.display="block";
                    (<HTMLInputElement> document.getElementById('boardingApprovedAmtByBmFormDiv')).style.display="block";
                    (<HTMLInputElement> document.getElementById('boardingApprovedAmtByBm')).style.backgroundColor='#ffff75';
                    (<HTMLInputElement> document.getElementById('boardingApprovedAmtByBm')).readOnly = true;
                  }
                  if(this.a.rowItem['allowanceApprovedAmtByBm']!=''){
                   (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByBmLabelDiv')).style.display="block";
                  (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByBmFormDiv')).style.display="block";
                  (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByBm')).style.backgroundColor='#ffff75';
                  (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByBm')).readOnly = true;
                  }
                }

                if(groupName=="DEPUTY GENERAL MANAGER"){
                  console.log("entering inside 34");
                  (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByDgmGmLabelDiv')).style.display="block";
                  (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByDgmGmFormDiv')).style.display="block";
            
                  (<HTMLInputElement> document.getElementById('boardingApprovedAmtByDgmGmLabelDiv')).style.display="block";
                  (<HTMLInputElement> document.getElementById('boardingApprovedAmtByDgmGmFormDiv')).style.display="block";
            
                  (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByDgmGmLabelDiv')).style.display="block";
                  (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByDgmGmFormDiv')).style.display="block";
                  
                  if(this.a.rowItem['conApprovedAmtByBm']!=''){
                    (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByBmLabelDiv')).style.display="block";
                    (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByBmFormDiv')).style.display="block";
                    (<HTMLInputElement> document.getElementById('conApprovedAmtByBm')).style.backgroundColor='#ffff75';
                    (<HTMLInputElement> document.getElementById('conApprovedAmtByBm')).readOnly = true;
                  }
                  if(this.a.rowItem['boardingApprovedAmtByBm']!=''){
                    (<HTMLInputElement> document.getElementById('boardingApprovedAmtByBmLabelDiv')).style.display="block";
                    (<HTMLInputElement> document.getElementById('boardingApprovedAmtByBmFormDiv')).style.display="block";
                    (<HTMLInputElement> document.getElementById('boardingApprovedAmtByBm')).style.backgroundColor='#ffff75';
                    (<HTMLInputElement> document.getElementById('boardingApprovedAmtByBm')).readOnly = true;
                  }
                  if(this.a.rowItem['allowanceApprovedAmtByBm']!=''){
                   (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByBmLabelDiv')).style.display="block";
                  (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByBmFormDiv')).style.display="block";
                  (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByBm')).style.backgroundColor='#ffff75';
                  (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByBm')).readOnly = true;
                  }
                }

              //Rsm end      
              
              if(groupName=="GM"){
                console.log("entering inside 21");            
                (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByGmLabelDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByGmFormDiv')).style.display="block";              
                
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByGmLabelDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByGmFormDiv')).style.display="block";                
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByGmLabelDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByGmFormDiv')).style.display="block";               
            
                if(this.a.rowItem['conApprovedAmtByDgmGm']!=''){
                (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByDgmGmLabelDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByDgmGmFormDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('conApprovedAmtByDgmGm')).style.backgroundColor='#ffff75';
                (<HTMLInputElement> document.getElementById('conApprovedAmtByDgmGm')).readOnly = true;
                }
                
                if(this.a.rowItem['boardingApprovedAmtByDgmGm']!=''){
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByDgmGmLabelDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByDgmGmFormDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByDgmGm')).style.backgroundColor='#ffff75';
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByDgmGm')).readOnly = true;
                }

                if(this.a.rowItem['allowanceApprovedAmtByDgmGm']!=''){
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByDgmGmLabelDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByDgmGmFormDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByDgmGm')).style.backgroundColor='#ffff75';
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByDgmGm')).readOnly = true;
                }
            
            
                if(this.a.rowItem['conApprovedAmtByRsm']!=''){
                (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByRsmLabelDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByRsmFormDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('conApprovedAmtByRsm')).style.backgroundColor='#ffff75';
                (<HTMLInputElement> document.getElementById('conApprovedAmtByRsm')).readOnly = true;
                }
                
                if(this.a.rowItem['boardingApprovedAmtByRsm']!=''){
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByRsmLabelDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByRsmFormDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByRsm')).style.backgroundColor='#ffff75';
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByRsm')).readOnly = true;
                }
                
                if(this.a.rowItem['allowanceApprovedAmtByRsm']!=''){
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByRsmLabelDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByRsmFormDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByRsm')).style.backgroundColor='#ffff75';
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByRsm')).readOnly = true;
                }
                
                if(this.a.rowItem['conApprovedAmtByBm']!=''){
                (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByBmLabelDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByBmFormDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('conApprovedAmtByBm')).style.backgroundColor='#ffff75';
                (<HTMLInputElement> document.getElementById('conApprovedAmtByBm')).readOnly = true;
                }
            
                if(this.a.rowItem['boardingApprovedAmtByBm']!=''){
                   (<HTMLInputElement> document.getElementById('boardingApprovedAmtByBmLabelDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByBmFormDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByBm')).style.backgroundColor='#ffff75';
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByBm')).readOnly = true;
                }
            
                if(this.a.rowItem['allowanceApprovedAmtByBm']!=''){
                 (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByBmLabelDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByBmFormDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByBm')).style.backgroundColor='#ffff75';
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByBm')).readOnly = true;
                }
              }
            
            
            
              if(groupName=="WTD"){
                console.log("entering inside 21");            
                (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByDirectorsLabelDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByDirectorsFormDiv')).style.display="block";              
                
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByDirectorsLabelDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByDirectorsFormDiv')).style.display="block";                
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByDirectorsLabelDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByDirectorsFormDiv')).style.display="block";               
            
                if(this.a.rowItem['conApprovedAmtByGm']!=''){
                  (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByGmLabelDiv')).style.display="block";
                  (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByGmFormDiv')).style.display="block";
                  (<HTMLInputElement> document.getElementById('conApprovedAmtByGm')).style.backgroundColor='#ffff75';
                  (<HTMLInputElement> document.getElementById('conApprovedAmtByGm')).readOnly = true;
                  }
                  
                  if(this.a.rowItem['boardingApprovedAmtByGm']!=''){
                  (<HTMLInputElement> document.getElementById('boardingApprovedAmtByGmLabelDiv')).style.display="block";
                  (<HTMLInputElement> document.getElementById('boardingApprovedAmtByGmFormDiv')).style.display="block";
                  (<HTMLInputElement> document.getElementById('boardingApprovedAmtByGm')).style.backgroundColor='#ffff75';
                  (<HTMLInputElement> document.getElementById('boardingApprovedAmtByGm')).readOnly = true;
                  }
  
                  if(this.a.rowItem['allowanceApprovedAmtByGm']!=''){
                  (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByGmLabelDiv')).style.display="block";
                  (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByGmFormDiv')).style.display="block";
                  (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByGm')).style.backgroundColor='#ffff75';
                  (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByGm')).readOnly = true;
                  }

                if(this.a.rowItem['conApprovedAmtByDgmGm']!=''){
                (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByDgmGmLabelDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByDgmGmFormDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('conApprovedAmtByDgmGm')).style.backgroundColor='#ffff75';
                (<HTMLInputElement> document.getElementById('conApprovedAmtByDgmGm')).readOnly = true;
                }
                
                if(this.a.rowItem['boardingApprovedAmtByDgmGm']!=''){
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByDgmGmLabelDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByDgmGmFormDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByDgmGm')).style.backgroundColor='#ffff75';
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByDgmGm')).readOnly = true;
                }

                if(this.a.rowItem['allowanceApprovedAmtByDgmGm']!=''){
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByDgmGmLabelDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByDgmGmFormDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByDgmGm')).style.backgroundColor='#ffff75';
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByDgmGm')).readOnly = true;
                }
            
            
                if(this.a.rowItem['conApprovedAmtByRsm']!=''){
                (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByRsmLabelDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByRsmFormDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('conApprovedAmtByRsm')).style.backgroundColor='#ffff75';
                (<HTMLInputElement> document.getElementById('conApprovedAmtByRsm')).readOnly = true;
                }
                
                if(this.a.rowItem['boardingApprovedAmtByRsm']!=''){
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByRsmLabelDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByRsmFormDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByRsm')).style.backgroundColor='#ffff75';
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByRsm')).readOnly = true;
                }
                
                if(this.a.rowItem['allowanceApprovedAmtByRsm']!=''){
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByRsmLabelDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByRsmFormDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByRsm')).style.backgroundColor='#ffff75';
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByRsm')).readOnly = true;
                }
                
                if(this.a.rowItem['conApprovedAmtByBm']!=''){
                (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByBmLabelDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByBmFormDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('conApprovedAmtByBm')).style.backgroundColor='#ffff75';
                (<HTMLInputElement> document.getElementById('conApprovedAmtByBm')).readOnly = true;
                }
            
                if(this.a.rowItem['boardingApprovedAmtByBm']!=''){
                   (<HTMLInputElement> document.getElementById('boardingApprovedAmtByBmLabelDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByBmFormDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByBm')).style.backgroundColor='#ffff75';
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByBm')).readOnly = true;
                }
            
                if(this.a.rowItem['allowanceApprovedAmtByBm']!=''){
                 (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByBmLabelDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByBmFormDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByBm')).style.backgroundColor='#ffff75';
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByBm')).readOnly = true;
                }
              }
            
              if(groupName=="FINANCE"){
                console.log("entering inside 36");
                (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByFinanceLabelDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByFinanceFormDiv')).style.display="block";
            
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByFinanceLabelDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByFinanceFormDiv')).style.display="block";
            
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByFinanceLabelDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByFinanceFormDiv')).style.display="block";
            
                if(this.a.rowItem['conApprovedAmtByDirectors']!=''){
                (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByDirectorsLabelDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByDirectorsFormDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('conApprovedAmtByDirectors')).style.backgroundColor='#ffff75';
                (<HTMLInputElement> document.getElementById('conApprovedAmtByDirectors')).readOnly = true;
                }
                
                if(this.a.rowItem['boardingApprovedAmtByDirectors']!=''){
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByDirectorsLabelDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByDirectorsFormDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByDirectors')).style.backgroundColor='#ffff75';
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByDirectors')).readOnly = true;
                }

                if(this.a.rowItem['allowanceApprovedAmtByDirectors']!=''){
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByDirectorsLabelDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByDirectorsFormDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByDirectors')).style.backgroundColor='#ffff75';
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByDirectors')).readOnly = true;
                }
            
                if(this.a.rowItem['conApprovedAmtByDgmGm']!=''){
                (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByDgmGmLabelDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByDgmGmFormDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('conApprovedAmtByDgmGm')).style.backgroundColor='#ffff75';
                (<HTMLInputElement> document.getElementById('conApprovedAmtByDgmGm')).readOnly = true;
                }

                if(this.a.rowItem['boardingApprovedAmtByDgmGm']!=''){
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByDgmGmLabelDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByDgmGmFormDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByDgmGm')).style.backgroundColor='#ffff75';
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByDgmGm')).readOnly = true;
                }

                if(this.a.rowItem['allowanceApprovedAmtByDgmGm']!=''){
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByDgmGmLabelDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByDgmGmFormDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByDgmGm')).style.backgroundColor='#ffff75';
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByDgmGm')).readOnly = true;
                }
            
            
                if(this.a.rowItem['conApprovedAmtByRsm']!=''){
                (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByRsmLabelDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByRsmFormDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('conApprovedAmtByRsm')).style.backgroundColor='#ffff75';
                (<HTMLInputElement> document.getElementById('conApprovedAmtByRsm')).readOnly = true;
                }

                if(this.a.rowItem['boardingApprovedAmtByRsm']!=''){
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByRsmLabelDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByRsmFormDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByRsm')).style.backgroundColor='#ffff75';
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByRsm')).readOnly = true;
                }

                if(this.a.rowItem['allowanceApprovedAmtByRsm']!=''){
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByRsmLabelDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByRsmFormDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByRsm')).style.backgroundColor='#ffff75';
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByRsm')).readOnly = true;
                }

                if(this.a.rowItem['conApprovedAmtByBm']!=''){
                (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByBmLabelDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByBmFormDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('conApprovedAmtByBm')).style.backgroundColor='#ffff75';
                (<HTMLInputElement> document.getElementById('conApprovedAmtByBm')).readOnly = true;
                }

                if(this.a.rowItem['boardingApprovedAmtByBm']!=''){
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByBmLabelDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByBmFormDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByBm')).style.backgroundColor='#ffff75';
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByBm')).readOnly = true;
                }

                if(this.a.rowItem['allowanceApprovedAmtByBm']!=''){
                 (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByBmLabelDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByBmFormDiv')).style.display="block";
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByBm')).style.backgroundColor='#ffff75';
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByBm')).readOnly = true;
                }

                (<HTMLInputElement> document.getElementById('expenseDetailsFnMode')).value = 'e';
                (<HTMLInputElement> document.getElementById("expenseDetailsBtnClear")).disabled = true;
            
              }
            
              
              }, 500);
               
               // (<HTMLInputElement> document.getElementById('createdDt')).value = this.a.rowItem['createdDtDisp'];
                //(<HTMLInputElement> document.getElementById('createdBy')).value = this.a.rowItem['createdBy'];
             
               
            
                //(<HTMLInputElement> document.getElementById('expenseDetailsName')).style.backgroundColor='#000000';
            
                activeModal.componentInstance.modalHeader = 'Vehicle Model';
              }
              else{
              
                if(this.a.rowItem['status']=='Approved by WTD'){
                  alert("All Approval Completed");
                }
                else{
                  alert("Waiting for approval from "+posts.designation);
                }
                
              }
       });
   
   }else{
     alert("Kindly select a record to edit");
   }
   
}

  viewModalShow(){
       
    var groupId= JSON.parse(localStorage.getItem('currentUser')).groupId;
   if(this.a.selectedExpenseCreationDtlId!=null && this.a.selectedExpenseCreationDtlId!=""){

     console.log("==========================");
     console.log("<><><><><><>");
     console.log(this.a.selectedExpenseCreationDtlId['expenseCreationDtlId']);
     console.log(this.a.selectedExpenseCreationDtlId['updatedBy']);
     console.log(this.a.selectedExpenseCreationDtlId);
     this.service.getExpenseDtlLastUpdateCheck(this.a.selectedExpenseCreationDtlId['expenseCreationDtlId'],this.a.selectedExpenseCreationDtlId['updatedBy'],this.a.selectedExpenseCreationDtlId['empNo']).subscribe(posts => {
              console.log(posts);
              console.log(posts.userId);
              console.log(JSON.parse(localStorage.getItem('currentUser')).userId);

              
                console.log(groupId);
                console.log((this.a.rowItem['conApprovedAmtByBm']));
                
                console.log((this.a.rowItem['conApprovedAmtByBm']));
                console.log((this.a.rowItem['allowanceApprovedAmtByBm']));
                console.log(( (this.a.rowItem['conApprovedAmtByBm'] == ""  && 
                this.a.rowItem['conApprovedAmtByBm'] =="" && 
                this.a.rowItem['allowanceApprovedAmtByBm'] =="")));
                console.log((groupId == "34" && (this.a.rowItem['conApprovedAmtByBm'] == ""  && 
                this.a.rowItem['conApprovedAmtByBm'] =="" && 
                this.a.rowItem['allowanceApprovedAmtByBm'] =="")));
                console.log("=========================="); 
            
                
                const activeModal = this.modalService.open(ExpenseDetailsInfoVW, { size: 'lg' ,backdrop :'static'});
                setTimeout(() => {
                (<HTMLInputElement> document.getElementById('expenseCreationDtlId')).value = this.a.rowItem['expenseCreationDtlId'];
            
                (<HTMLInputElement> document.getElementById('expenseCreationNo')).value = this.a.rowItem['expenseCreationNo'];
                (<HTMLInputElement> document.getElementById('date')).value = this.a.rowItem['date'];
                (<HTMLInputElement> document.getElementById('expName')).value = this.a.rowItem['expName'];
                  (<HTMLInputElement> document.getElementById('empNo')).value = this.a.rowItem['empNo'];
                (<HTMLInputElement> document.getElementById('employeeName')).value = this.a.rowItem['employeeName'];
                (<HTMLInputElement> document.getElementById('visitPlanNo')).value = this.a.rowItem['visitPlanNo'];
                (<HTMLInputElement> document.getElementById('visitPlanDate')).value = this.a.rowItem['visitPlanDate'];
                (<HTMLInputElement> document.getElementById('dealerDistributor')).value = this.a.rowItem['dealerDistributor'];
                (<HTMLInputElement> document.getElementById('state')).value = this.a.rowItem['state'];
                (<HTMLInputElement> document.getElementById('city')).value = this.a.rowItem['city'];
                (<HTMLInputElement> document.getElementById('transport')).value = this.a.rowItem['transport'];
                (<HTMLInputElement> document.getElementById('conSlabAmt')).value = this.a.rowItem['conSlabAmt'];
                (<HTMLInputElement> document.getElementById('conClaimActual')).value = this.a.rowItem['conClaimActual'];
                (<HTMLInputElement> document.getElementById('conSpecialApproval')).value = this.a.rowItem['conSpecialApproval'];
                (<HTMLInputElement> document.getElementById('conveyanceRemark')).value = this.a.rowItem['conveyanceRemark'];
               // (<HTMLInputElement> document.getElementById('conProofOfDocument')).value = this.a.rowItem['conProofOfDocument'];
                (<HTMLInputElement> document.getElementById('conApprovedAmtByBm')).value = this.a.rowItem['conApprovedAmtByBm'];
                (<HTMLInputElement> document.getElementById('conApprovedAmtByRsm')).value = this.a.rowItem['conApprovedAmtByRsm'];
                (<HTMLInputElement> document.getElementById('conApprovedAmtByDgmGm')).value = this.a.rowItem['conApprovedAmtByDgmGm'];
                (<HTMLInputElement> document.getElementById('conApprovedAmtByGm')).value = this.a.rowItem['conApprovedAmtByGm'];
                (<HTMLInputElement> document.getElementById('conApprovedAmtByDirectors')).value = this.a.rowItem['conApprovedAmtByDirectors'];
                (<HTMLInputElement> document.getElementById('conApprovedAmtByFinance')).value = this.a.rowItem['conApprovedAmtByFinance'];
            
                   (<HTMLInputElement> document.getElementById('boardingSlabAmt')).value = this.a.rowItem['boardingSlabAmt'];
                    (<HTMLInputElement> document.getElementById('boardingClaimActual')).value = this.a.rowItem['boardingClaimActual'];
                (<HTMLInputElement> document.getElementById('boardingSpecialApproval')).value = this.a.rowItem['boardingSpecialApproval'];
                (<HTMLInputElement> document.getElementById('boardingRemark')).value = this.a.rowItem['boardingRemark'];
               // (<HTMLInputElement> document.getElementById('boardingProofOfDocument')).value = this.a.rowItem['boardingProofOfDocument'];
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByBm')).value = this.a.rowItem['boardingApprovedAmtByBm'];
                    (<HTMLInputElement> document.getElementById('boardingApprovedAmtByRsm')).value = this.a.rowItem['boardingApprovedAmtByRsm'];
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByDgmGm')).value = this.a.rowItem['boardingApprovedAmtByDgmGm'];
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByGm')).value = this.a.rowItem['boardingApprovedAmtByGm'];
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByDirectors')).value = this.a.rowItem['boardingApprovedAmtByDirectors'];
                (<HTMLInputElement> document.getElementById('boardingApprovedAmtByFinance')).value = this.a.rowItem['boardingApprovedAmtByFinance'];
            
                       (<HTMLInputElement> document.getElementById('allowanceSlabAmt')).value = this.a.rowItem['allowanceSlabAmt'];
                    (<HTMLInputElement> document.getElementById('allowanceClaimActual')).value = this.a.rowItem['allowanceClaimActual'];
                    console.log( (<HTMLInputElement> document.getElementById('allowanceClaimActual')).value);
                (<HTMLInputElement> document.getElementById('allowanceSpecialApproval')).value = this.a.rowItem['allowanceSpecialApproval'];
                (<HTMLInputElement> document.getElementById('allowanceRemark')).value = this.a.rowItem['allowanceRemark'];
               // (<HTMLInputElement> document.getElementById('allowanceProofOfDocument')).value = this.a.rowItem['allowanceProofOfDocument'];
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByBm')).value = this.a.rowItem['allowanceApprovedAmtByBm'];
                    (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByRsm')).value = this.a.rowItem['allowanceApprovedAmtByRsm'];
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByDgmGm')).value = this.a.rowItem['allowanceApprovedAmtByDgmGm'];
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByGm')).value = this.a.rowItem['allowanceApprovedAmtByGm'];
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByDirectors')).value = this.a.rowItem['allowanceApprovedAmtByDirectors'];
                (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByFinance')).value = this.a.rowItem['allowanceApprovedAmtByFinance'];
                (<HTMLInputElement> document.getElementById('conveyanceFlagId')).value = this.a.rowItem['conveyanceAll'];
                (<HTMLInputElement> document.getElementById('boardingFlagId')).value = this.a.rowItem['boardingAll'];
                (<HTMLInputElement> document.getElementById('allowanceFlageId')).value = this.a.rowItem['allowanceAll'];
                // (<HTMLInputElement> document.getElementById('totalSlabAmt')).value = this.a.rowItem['totalSlabAmt'];
                // (<HTMLInputElement> document.getElementById('totalClaimAmt')).value = this.a.rowItem['totalClaimAmt'];
                // (<HTMLInputElement> document.getElementById('finalApprovedAmt')).value = this.a.rowItem['finalApprovedAmt'];
                // (<HTMLInputElement> document.getElementById('status')).value = this.a.rowItem['status'];
              
              //ADMIN / FINANCE START
              
              let claim_amount= 0;
              let slab_amount=0;
              let approved_amount=0;
              if(this.a.rowItem['conClaimActual']!=null && this.a.rowItem['conClaimActual']!='' && this.a.rowItem['conClaimActual']!='null'){
                  claim_amount += parseInt(this.a.rowItem['conClaimActual']);
              }
              if(this.a.rowItem['boardingClaimActual']!=null && this.a.rowItem['boardingClaimActual']!='' && this.a.rowItem['boardingClaimActual']!='null'){
                  claim_amount += parseInt(this.a.rowItem['boardingClaimActual']);
              }
              if(this.a.rowItem['allowanceClaimActual']!=null && this.a.rowItem['allowanceClaimActual']!='' && this.a.rowItem['allowanceClaimActual']!='null'){
                  claim_amount += parseInt(this.a.rowItem['allowanceClaimActual']);
              }    


              if(this.a.rowItem['conSlabAmt']!=null && this.a.rowItem['conSlabAmt']!=''&& this.a.rowItem['conSlabAmt']!='null'){
                  slab_amount += parseInt(this.a.rowItem['conSlabAmt']);
              }
              if(this.a.rowItem['boardingSlabAmt']!=null && this.a.rowItem['boardingSlabAmt']!='' && this.a.rowItem['boardingSlabAmt']!='null'){
                  slab_amount += parseInt(this.a.rowItem['boardingSlabAmt']);
              }
              if(this.a.rowItem['allowanceSlabAmt']!=null && this.a.rowItem['allowanceSlabAmt']!='' && this.a.rowItem['allowanceSlabAmt']!='null'){
                slab_amount += parseInt(this.a.rowItem['allowanceSlabAmt']);
              }

              if(this.a.rowItem['allowanceApprovedAmtByFinance']!=null && this.a.rowItem['allowanceApprovedAmtByFinance']!=''&& this.a.rowItem['allowanceApprovedAmtByFinance']!='null'){
                approved_amount += parseInt(this.a.rowItem['allowanceApprovedAmtByFinance']);
              }
              if(this.a.rowItem['boardingApprovedAmtByFinance']!=null && this.a.rowItem['boardingApprovedAmtByFinance']!='' && this.a.rowItem['boardingApprovedAmtByFinance']!='null'){
                approved_amount += parseInt(this.a.rowItem['boardingApprovedAmtByFinance']);
              }
              if(this.a.rowItem['conApprovedAmtByFinance']!=null && this.a.rowItem['conApprovedAmtByFinance']!='' && this.a.rowItem['conApprovedAmtByFinance']!='null'){
                approved_amount += parseInt(this.a.rowItem['conApprovedAmtByFinance']);
              }


              console.log("++++++++++++++");
              console.log("slab amount"+String(slab_amount));
              console.log("claim amount"+String(claim_amount));
              console.log("Approved amount"+String(approved_amount));
              console.log("c path"+this.a.rowItem['c_FilePath']);
             console.log("c bL_Filepath"+this.a.rowItem['bL_Filepath']);
              console.log("c a_Filepath"+this.a.rowItem['a_Filepath']);
              console.log("-------------------");
            (<HTMLInputElement> document.getElementById('totalSlabAmt')).value = String(slab_amount);
            (<HTMLInputElement> document.getElementById('totalClaimAmt')).value =String(claim_amount);
            (<HTMLInputElement> document.getElementById('finalAppprovedAmt')).value =String(approved_amount);
            (<HTMLInputElement> document.getElementById('status')).value =this.a.rowItem['status'];
            (<HTMLInputElement> document.getElementById('cPath')).value =this.a.rowItem['c_FilePath'];
            (<HTMLInputElement> document.getElementById('blPath')).value =this.a.rowItem['bL_Filepath'];
            (<HTMLInputElement> document.getElementById('aPath')).value =this.a.rowItem['a_Filepath'];
            


            console.log("entering inside 36");
           /*  (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByFinanceLabelDiv')).style.display="block";
            (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByFinanceFormDiv')).style.display="block";
            (<HTMLInputElement> document.getElementById('conApprovedAmtByFinance')).style.backgroundColor='#ffff75';
            (<HTMLInputElement> document.getElementById('conApprovedAmtByFinance')).readOnly = true;
        
            (<HTMLInputElement> document.getElementById('boardingApprovedAmtByFinanceLabelDiv')).style.display="block";
            (<HTMLInputElement> document.getElementById('boardingApprovedAmtByFinanceFormDiv')).style.display="block";
            (<HTMLInputElement> document.getElementById('boardingApprovedAmtByFinance')).style.backgroundColor='#ffff75';
            (<HTMLInputElement> document.getElementById('boardingApprovedAmtByFinance')).readOnly = true;
        
            (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByFinanceLabelDiv')).style.display="block";
            (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByFinanceFormDiv')).style.display="block";
            (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByFinance')).style.backgroundColor='#ffff75';
            (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByFinance')).readOnly = true; */
        
            (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByDirectorsLabelDiv')).style.display="block";
            (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByDirectorsFormDiv')).style.display="block";
            (<HTMLInputElement> document.getElementById('conApprovedAmtByDirectors')).style.backgroundColor='#ffff75';
            (<HTMLInputElement> document.getElementById('conApprovedAmtByDirectors')).readOnly = true;
            
            
            (<HTMLInputElement> document.getElementById('boardingApprovedAmtByDirectorsLabelDiv')).style.display="block";
            (<HTMLInputElement> document.getElementById('boardingApprovedAmtByDirectorsFormDiv')).style.display="block";
            (<HTMLInputElement> document.getElementById('boardingApprovedAmtByDirectors')).style.backgroundColor='#ffff75';
            (<HTMLInputElement> document.getElementById('boardingApprovedAmtByDirectors')).readOnly = true;
            
        
            (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByDirectorsLabelDiv')).style.display="block";
            (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByDirectorsFormDiv')).style.display="block";
            (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByDirectors')).style.backgroundColor='#ffff75';
            (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByDirectors')).readOnly = true;
            
            (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByGmLabelDiv')).style.display="block";
            (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByGmFormDiv')).style.display="block";
            (<HTMLInputElement> document.getElementById('conApprovedAmtByGm')).style.backgroundColor='#ffff75';
            (<HTMLInputElement> document.getElementById('conApprovedAmtByGm')).readOnly = true;
            
            
            (<HTMLInputElement> document.getElementById('boardingApprovedAmtByGmLabelDiv')).style.display="block";
            (<HTMLInputElement> document.getElementById('boardingApprovedAmtByGmFormDiv')).style.display="block";
            (<HTMLInputElement> document.getElementById('boardingApprovedAmtByGm')).style.backgroundColor='#ffff75';
            (<HTMLInputElement> document.getElementById('boardingApprovedAmtByGm')).readOnly = true;
            
            (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByGmLabelDiv')).style.display="block";
            (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByGmFormDiv')).style.display="block";
            (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByGm')).style.backgroundColor='#ffff75';
            (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByGm')).readOnly = true;
        
        
            (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByDgmGmLabelDiv')).style.display="block";
            (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByDgmGmFormDiv')).style.display="block";
            (<HTMLInputElement> document.getElementById('conApprovedAmtByDgmGm')).style.backgroundColor='#ffff75';
            (<HTMLInputElement> document.getElementById('conApprovedAmtByDgmGm')).readOnly = true;
            
            
            (<HTMLInputElement> document.getElementById('boardingApprovedAmtByDgmGmLabelDiv')).style.display="block";
            (<HTMLInputElement> document.getElementById('boardingApprovedAmtByDgmGmFormDiv')).style.display="block";
            (<HTMLInputElement> document.getElementById('boardingApprovedAmtByDgmGm')).style.backgroundColor='#ffff75';
            (<HTMLInputElement> document.getElementById('boardingApprovedAmtByDgmGm')).readOnly = true;
            
            (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByDgmGmLabelDiv')).style.display="block";
            (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByDgmGmFormDiv')).style.display="block";
            (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByDgmGm')).style.backgroundColor='#ffff75';
            (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByDgmGm')).readOnly = true;
        
        
        
        
            (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByRsmLabelDiv')).style.display="block";
            (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByRsmFormDiv')).style.display="block";
            (<HTMLInputElement> document.getElementById('conApprovedAmtByRsm')).style.backgroundColor='#ffff75';
            (<HTMLInputElement> document.getElementById('conApprovedAmtByRsm')).readOnly = true;
            
            
            (<HTMLInputElement> document.getElementById('boardingApprovedAmtByRsmLabelDiv')).style.display="block";
            (<HTMLInputElement> document.getElementById('boardingApprovedAmtByRsmFormDiv')).style.display="block";
            (<HTMLInputElement> document.getElementById('boardingApprovedAmtByRsm')).style.backgroundColor='#ffff75';
            (<HTMLInputElement> document.getElementById('boardingApprovedAmtByRsm')).readOnly = true;
            
            (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByRsmLabelDiv')).style.display="block";
            (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByRsmFormDiv')).style.display="block";
            (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByRsm')).style.backgroundColor='#ffff75';
            (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByRsm')).readOnly = true;
            
            (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByBmLabelDiv')).style.display="block";
            (<HTMLInputElement> document.getElementById('conveyanceApprovedAmtByBmFormDiv')).style.display="block";
            (<HTMLInputElement> document.getElementById('conApprovedAmtByBm')).style.backgroundColor='#ffff75';
            (<HTMLInputElement> document.getElementById('conApprovedAmtByBm')).readOnly = true;
        
               (<HTMLInputElement> document.getElementById('boardingApprovedAmtByBmLabelDiv')).style.display="block";
            (<HTMLInputElement> document.getElementById('boardingApprovedAmtByBmFormDiv')).style.display="block";
            (<HTMLInputElement> document.getElementById('boardingApprovedAmtByBm')).style.backgroundColor='#ffff75';
            (<HTMLInputElement> document.getElementById('boardingApprovedAmtByBm')).readOnly = true;
        
             (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByBmLabelDiv')).style.display="block";
            (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByBmFormDiv')).style.display="block";
            (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByBm')).style.backgroundColor='#ffff75';
            (<HTMLInputElement> document.getElementById('allowanceApprovedAmtByBm')).readOnly = true;
          
          (<HTMLInputElement> document.getElementById("expenseDetailsBtnSubmit")).disabled = true;
          (<HTMLInputElement> document.getElementById("expenseDetailsBtnClear")).disabled = true;

         
              (<HTMLInputElement> document.getElementById("expenseDetailsBtnSubmit")).disabled = true;
              (<HTMLInputElement> document.getElementById("expenseDetailsBtnClear")).disabled = true;
            
              
              }, 500);
               /*
                (<HTMLInputElement> document.getElementById('createdDt')).value = this.a.rowItem['createdDtDisp'];
                (<HTMLInputElement> document.getElementById('createdBy')).value = this.a.rowItem['createdBy'];
                (<HTMLInputElement> document.getElementById('expenseDetailsFnMode')).value = 'e';
                (<HTMLInputElement> document.getElementById("expenseDetailsBtnClear")).disabled = true;
            */
               
            
                //(<HTMLInputElement> document.getElementById('expenseDetailsName')).style.backgroundColor='#000000';
            
                activeModal.componentInstance.modalHeader = 'Vehicle Model';
            
             
       });
   
   }else{
     alert("Kindly select a record to edit");
   }
  }
  
// source: LocalDataSource = new LocalDataSource();
  
  checkboxValue: boolean ;
   searchMethod() {
      this.a.search(
                    this.searchFromDate.nativeElement.value,
                    this.searchToDate.nativeElement.value,
                    this.searchStatus.nativeElement.value,
                    this.searchUserName.nativeElement.value,
                    this.searchBranch.nativeElement.value,
                    this.searchShowValue.nativeElement.value);

  }

resetMethod() {
 this.a.reset();

    this.searchFromDate.nativeElement.value='';
                    this.searchToDate.nativeElement.value='';
                    this.searchStatus.nativeElement.value='';
                    this.searchUserName.nativeElement.value='';
                    this.searchBranch.nativeElement.value='';
                    this.searchShowValue.nativeElement.value='';
}

exportExcel(){

      this.service.exportExpenseDetailsXL(this.searchFromDate.nativeElement.value,
        this.searchToDate.nativeElement.value,
        this.searchStatus.nativeElement.value,
        this.searchUserName.nativeElement.value,
        this.searchBranch.nativeElement.value,
        this.searchShowValue.nativeElement.value
      ).subscribe(posts =>{
          console.log(posts);
          // alert("djasdna");
        let searchflag="";
        //|| (filterLoginType != null &&  filterLoginType != '')|| (fromDate != null && fromDate != '')||  (toDate != null &&  toDate!= '')
            if((this.searchUserName.nativeElement.value!=null && this.searchUserName.nativeElement.value !='')
            ||(this.searchStatus.nativeElement.value != null && this.searchStatus.nativeElement.value != '')
            ||(this.searchShowValue.nativeElement.value != null && this.searchShowValue.nativeElement.value != '')){
             // alert("ssss"); 
              searchflag ="Y";
              }
              else{
              //alert("sssskuhyg"); 
                
              }

      window.open(posts.url+"?fromDate="+this.searchFromDate.nativeElement.value
              +"&toDate="+this.searchToDate.nativeElement.value
              +"&status="+this.searchStatus.nativeElement.value
              +"&searchFlag="+searchflag
              +"&userBy="+this.searchUserName.nativeElement.value
              +"&branch="+this.searchBranch.nativeElement.value
              +"&showValue="+this.searchShowValue.nativeElement.value
              +"&groupName="+JSON.parse(localStorage.getItem('currentUser')).groupName
              +"&showRelatedValue="+JSON.parse(localStorage.getItem('currentUser')).userId
              +"&usrId="+JSON.parse(localStorage.getItem('currentUser')).usrId
              +"&userId="+JSON.parse(localStorage.getItem('currentUser')).userId
              +"&locationId="+JSON.parse(localStorage.getItem('currentUser')).locationId
              +"&locName="+JSON.parse(localStorage.getItem('currentUser')).locName
              +"&orgId="+JSON.parse(localStorage.getItem('currentUser')).orgId, '_blank', '');  
      });
    
}
exportExpenseDetailsXLUser(){

        if(this.searchExpenseNo.nativeElement.value ==undefined || this.searchExpenseNo.nativeElement.value ==null ||
           this.searchExpenseNo.nativeElement.value ==''){
          alert("Kindly select Expense No!");
            return;
          }

  this.service.exportExpenseDetailsXLUser(this.searchFromDate.nativeElement.value,
    this.searchToDate.nativeElement.value,
    this.searchStatus.nativeElement.value,
    this.searchUserName.nativeElement.value,
    this.searchBranch.nativeElement.value,
    this.searchShowValue.nativeElement.value,
    this.searchExpenseNo.nativeElement.value
  ).subscribe(posts =>{

    let searchflag="";
        if((this.searchUserName.nativeElement.value!=null && this.searchUserName.nativeElement.value !='')
        ||(this.searchStatus.nativeElement.value != null && this.searchStatus.nativeElement.value != '')
        ||(this.searchShowValue.nativeElement.value != null && this.searchShowValue.nativeElement.value != '')){
          searchflag ="Y";
          }
          else{
          }
    
  window.open(posts.url+"?fromDate="+this.searchFromDate.nativeElement.value
          +"&toDate="+this.searchToDate.nativeElement.value
          +"&status="+this.searchStatus.nativeElement.value
          +"&searchFlag="+searchflag
          +"&userBy="+this.searchUserName.nativeElement.value
          +"&branch="+this.searchBranch.nativeElement.value
          +"&showValue="+this.searchShowValue.nativeElement.value
          +"&searchExpenseNo="+this.searchExpenseNo.nativeElement.value
          +"&groupName="+JSON.parse(localStorage.getItem('currentUser')).groupName
          +"&showRelatedValue="+JSON.parse(localStorage.getItem('currentUser')).userId
          +"&usrId="+JSON.parse(localStorage.getItem('currentUser')).usrId
          +"&userId="+JSON.parse(localStorage.getItem('currentUser')).userId
          +"&locationId="+JSON.parse(localStorage.getItem('currentUser')).locationId
          +"&locName="+JSON.parse(localStorage.getItem('currentUser')).locName
          +"&orgId="+JSON.parse(localStorage.getItem('currentUser')).orgId, '_blank', '');  
  });

}

onSelectFromDate(date: NgbDateStruct){
  if (date != null) {
          let stringFromDate: string = ""; 
          let stringStartDate: string = ""; 
          
          if(date) {
            stringFromDate += this.isNumber(date.day) ? this.padNumber(date.day) + "-" : "";
            stringFromDate += this.isNumber(date.month) ? this.padNumber(date.month) + "-" : "";
            stringFromDate += date.year;

            stringStartDate += date.year + "-";
            stringStartDate += this.isNumber(date.month) ? this.padNumber(date.month) + "-" : "";
            stringStartDate += this.isNumber(date.day) ? this.padNumber(date.day) : "";
          }
          this.searchFromDate.nativeElement.value =stringFromDate; 

          
          
    }
}

onSelectToDate(date: NgbDateStruct){
  if (date != null) {
          let stringToDate: string = ""; 
          let stringEndDate: string = ""; 
          
          if(date) {
            stringToDate += this.isNumber(date.day) ? this.padNumber(date.day) + "-" : "";
            stringToDate += this.isNumber(date.month) ? this.padNumber(date.month) + "-" : "";
            stringToDate += date.year;

            stringEndDate += date.year + "-";
            stringEndDate += this.isNumber(date.month) ? this.padNumber(date.month) + "-" : "";
            stringEndDate += this.isNumber(date.day) ? this.padNumber(date.day) : "";
          }
          this.searchToDate.nativeElement.value =stringToDate;
          //this.searchFarmerEndDate.nativeElement.value =stringEndDate;
          
      }
}

padNumber(value: number) {
  if (this.isNumber(value)) {
      return `0${value}`.slice(-2);
  } else {
      return "";
  }
}

isNumber(value: any): boolean {
  return !isNaN(this.toInteger(value));
}

toInteger(value: any): number {
  return parseInt(`${value}`, 10);
}

exportPDF(){
  if(this.searchExpenseNo.nativeElement.value ==undefined || this.searchExpenseNo.nativeElement.value ==null ||
    this.searchExpenseNo.nativeElement.value ==''){
   alert("Kindly select Expense No!");
     return;
   }

this.service.exportPDF(this.searchFromDate.nativeElement.value,
this.searchToDate.nativeElement.value,
this.searchStatus.nativeElement.value,
this.searchUserName.nativeElement.value,
this.searchBranch.nativeElement.value,
this.searchShowValue.nativeElement.value,
this.searchExpenseNo.nativeElement.value
).subscribe(posts =>{

      let searchflag="";
      if((this.searchUserName.nativeElement.value!=null && this.searchUserName.nativeElement.value !='')
      ||(this.searchStatus.nativeElement.value != null && this.searchStatus.nativeElement.value != '')
      ||(this.searchShowValue.nativeElement.value != null && this.searchShowValue.nativeElement.value != '')){
        searchflag ="Y";
        }
        else{
        }

      window.open(posts.url+"?fromDate="+this.searchFromDate.nativeElement.value
        +"&toDate="+this.searchToDate.nativeElement.value
        +"&status="+this.searchStatus.nativeElement.value
        +"&searchFlag="+searchflag
        +"&userBy="+this.searchUserName.nativeElement.value
        +"&branch="+this.searchBranch.nativeElement.value
        +"&showValue="+this.searchShowValue.nativeElement.value
        +"&searchExpenseNo="+this.searchExpenseNo.nativeElement.value
        +"&groupName="+JSON.parse(localStorage.getItem('currentUser')).groupName
        +"&showRelatedValue="+JSON.parse(localStorage.getItem('currentUser')).userId
        +"&usrId="+JSON.parse(localStorage.getItem('currentUser')).usrId
        +"&userId="+JSON.parse(localStorage.getItem('currentUser')).userId
        +"&locationId="+JSON.parse(localStorage.getItem('currentUser')).locationId
        +"&locName="+JSON.parse(localStorage.getItem('currentUser')).locName
        +"&orgId="+JSON.parse(localStorage.getItem('currentUser')).orgId, '_blank', '');  
      });

}
}


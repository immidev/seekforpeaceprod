import { Component, OnInit, Inject, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { LocalDataSource } from 'ng2-smart-table';
import { HttpModule } from '@angular/http';
import { ExpenseDetailsService } from 'app/pages/masters/components/expenseDetails/expenseDetails.service';

@Component({
  selector: 'expenseDetailslistv',
  templateUrl: './expenseDetails.listv.html',
  styleUrls: ['./expenseDetails.scss'],
})
export class ExpenseDetailsListV {
  query: string = '';

  public rowItem: JSON;
 smartTableData:Array<any>;
 public selectedExpenseCreationDtlId : string;
 public selectedRow : string;
     
     setClickedRow = function(index, item) {
     this.selectedRow = index; 
     this.selectedExpenseCreationDtlId = item;
     this.rowItem = item;
     //console.log(item); 
   };

  constructor( protected service: ExpenseDetailsService) {
    
        this.service.getPosts_expenseDetails().subscribe(posts => {
                    //console.log("testing 123+++++");
                    //console.log(posts.listAllExpenseDetails);
                   

 this.smartTableData = posts.listOfExpenseDetails;
 console.log(this.smartTableData);

        });
  }

  onDeleteConfirm(event): void {
    if (window.confirm('Are you sure you want to delete?')) {
      event.confirm.resolve();
    } else {
      event.confirm.reject();
    }
  }


  search(fromDate,toDate,status,username,branch,searchFormValue) {
   // console.log('testingggg');

    this.service.searchExpenseDetails(fromDate,toDate,status,username,branch,searchFormValue).subscribe(posts => {
        //console.log('testingggg');
        this.smartTableData = null;
        this.smartTableData = posts.listOfExpenseDetails;
    });
}

  reset() {
    this.selectedExpenseCreationDtlId =null;
    this.selectedRow=null;
    this.service.getPosts_expenseDetails().subscribe(posts => {
        this.smartTableData = null;
        this.smartTableData = posts.listOfExpenseDetails;
    });
}

}

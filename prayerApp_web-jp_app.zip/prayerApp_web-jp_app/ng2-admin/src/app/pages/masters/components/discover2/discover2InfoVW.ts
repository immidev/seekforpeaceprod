import { Component, OnInit, Inject, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { LocalDataSource } from 'ng2-smart-table';

import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Observable } from 'rxjs/Observable';
import { Headers, Response, URLSearchParams } from '@angular/http';
import { MastersService } from '../../masters.service';


@Component({
  selector: 'discover2InfoVW',
  templateUrl: './discover2InfoVW.html',
  styleUrls: ['./discover2.scss'],
})
  
export class Discover2InfoVW  implements OnInit {
  
  @ViewChild('beliefStatementId') beliefStatementId: ElementRef;
  @ViewChild('name') name: ElementRef;
  @ViewChild('mail') mail: ElementRef;
  @ViewChild('districtOfficeNo') districtOfficeNo: ElementRef;
  @ViewChild('stateHeadNo') stateHeadNo: ElementRef;
  @ViewChild('headOfficeNo') headOfficeNo: ElementRef;
  @ViewChild('beliefStatementFnMode') beliefStatementFnMode: ElementRef;
  @ViewChild('createdDt') createdDt: ElementRef;
  @ViewChild('createdBy') createdBy: ElementRef;
  @ViewChild('locationId') locationId: ElementRef;
  @ViewChild('locationName') locationName: ElementRef;
    
   
 public model: any;
 currentJustify = 'start';
 source: LocalDataSource = new LocalDataSource();
 stateCombo;
 constructor(private activeModal: NgbActiveModal, private Service: MastersService,) { 
//   this.service.getStateMasterStateCombo().subscribe(posts => { 
//     this.stateCombo = posts.stateMasterList; 
// });  
 } 
  ngOnInit() {} 
  closeModal() {
    this.activeModal.close();    
      localStorage.removeItem('mode');
      localStorage.removeItem('GridValue');
  }
  
  Submit() { 
   this.Service.Submit(
              this.beliefStatementId.nativeElement.value,
              this.name.nativeElement.value,
              this.mail.nativeElement.value, 
  
              // this.createdDt.nativeElement.value,
              // this.createdBy.nativeElement.value, 
            ).subscribe(posts => {//Post Insert value
              this.closeModal()
     });     
  }
 
}


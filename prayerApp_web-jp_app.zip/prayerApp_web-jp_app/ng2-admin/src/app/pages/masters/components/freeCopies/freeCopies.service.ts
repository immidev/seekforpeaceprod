import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';
import { HttpModule } from '@angular/http';
import * as MasterConstants from '../../../masterconstants'; 
import { Headers, Response, URLSearchParams } from '@angular/http';

@Injectable()
export class UserFreeCopiesService {

    constructor(private http: Http) {
         // console.log('entering service');
    }

     getPosts(username, password) {
         //console.log(username, password);
         var headers = new Headers();
         headers.append('Content-Type', 'application/x-www-form-urlencoded');
         let urlSearchParams = new URLSearchParams();
          urlSearchParams.append('username',username);
         urlSearchParams.append('password',password);
         let body = urlSearchParams.toString(); 
         return this.http.post(MasterConstants.WEB_URL + '/loginUser', body, {
             headers: headers
         }).map(res => res.json());  

       //  return this.http.get(MasterConstants.WEB_URL+'agriMachApp/loginUser?username=' + username + '&&password=' + password).map(res => res.json());
     }


      getValidateSession() {      
        var headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let urlSearchParams = new URLSearchParams();
         let body = urlSearchParams.toString(); 
        return this.http.post(MasterConstants.WEB_URL + '/validateSession', body, {
            headers: headers
        }).map(res => res.json());    

       //return this.http.get(MasterConstants.WEB_URL+'validateSession').map(res => res.json());
    }

     getUserSessionDetails() {
        var headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let urlSearchParams = new URLSearchParams();
         let body = urlSearchParams.toString(); 
        return this.http.post(MasterConstants.WEB_URL + '/loadLoginUserInfo.action', body, {
            headers: headers
        }).map(res => res.json());  

         //  return this.http.get(MasterConstants.WEB_URL+'loadLoginUserInfo.action').map(res => res.json);
    }

    requestCopies(
      
        firstName,
        lastname,
        mobileNumber,
        landLine,
        nativeLanguage,
        dob,
        address,
        country,
        state,
        zip,
        emailid,
        message_text,
        books_array
    ) {
        //console.log(username, password);
        var headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let urlSearchParams = new URLSearchParams();
      urlSearchParams.append('firstName',firstName);
      urlSearchParams.append('lastname',lastname);
      urlSearchParams.append('mobileNumber',mobileNumber);
      urlSearchParams.append('landLine',landLine);
      urlSearchParams.append('nativeLanguage',nativeLanguage);
      urlSearchParams.append('address',address);
      urlSearchParams.append('country',country);
      urlSearchParams.append('state',state);
      urlSearchParams.append('zip',zip);
      urlSearchParams.append('emailid',emailid);
      urlSearchParams.append('message_text',message_text);
      urlSearchParams.append('books_array',books_array);
      urlSearchParams.append('userId',localStorage.getItem('userId'));

      //urlSearchParams.append('emailid',emailid);

        let body = urlSearchParams.toString(); 
        return this.http.post(MasterConstants.WEB_URL + 'freeCopies.php', body, {
            headers: headers
        }).map(res => res.json());  

      //  return this.http.get(MasterConstants.WEB_URL+'agriMachApp/createAccountUser?username=' + username + '&&password=' + password).map(res => res.json());
    }
}
 
import { Component, HostListener,OnInit, Inject, ElementRef, AfterViewInit, group } from '@angular/core';
import { NgbModal, NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { LocalDataSource } from 'ng2-smart-table';
import { HttpModule } from '@angular/http';
import { Typeahead } from 'ng2-typeahead-master';


import { Observable } from 'rxjs/Observable';
import { ViewChild } from '@angular/core';
import { BaSidebar } from 'app/theme/components/baSidebar/baSidebar.component';
import { ActivatedRoute, Router } from '@angular/router';
import { MastersService } from '../../masters.service';
import { Discover2InfoVW } from './discover2InfoVW';


@Component({
  selector: 'discover2',
  styleUrls: ['./discover2.scss'],
  templateUrl: './discover2.html',
  host: {
    "body":"body" 
  },
})
export class Discover2 {
dynamicClasses:[{
  classes: {
    'icon-arrow-down':true,
    'icon-arrow-up':false,
      }, classes1: {
        'icon-arrow-down':true,
        'icon-arrow-up':false,
          }, classes2: {
            'icon-arrow-down':true,
            'icon-arrow-up':false,
              },
}]

  public classes:any = {
    'icon-arrow-down':true,
    'icon-arrow-up':false,
      };
  sequenceNo(arg0: string, sequenceNo: any): any {
    throw new Error("Method not implemented.");
  }
  public isMenuCollapsed: boolean = true;
  @ViewChild('panel') public panel:ElementRef;

  padd;
  beliefStatementsId: any;
  limit=2;

  @ViewChild(BaSidebar) basidebar: BaSidebar;
  color: string;
  topic: any;
  sideTopic: any;
  active: any;
  value: any;
  headingtitle: any;
  beliefId: any;
  data: any;
  sequenceData: any;
  seq: any;
  selectedId:any;
  sequenceData1:any;
  disble = "true";
  activeIds = ['panel-0'];
  classArray;
  index;
  arrayLength;
  constructor(private router: Router, private route: ActivatedRoute, //private elRef: ElementRef,
    private Service: MastersService,private modalService: NgbModal) {
      // config.closeOthers = true;
      //alert("hekk")
     // elRef.nativeElement.ownerDocument.body.style.overflow = 'hidden';
     (<HTMLInputElement>document.getElementById('TopicHeader')).style.display = 'none';
    (<HTMLInputElement>document.getElementById('WholeHeader')).style.display = 'none';
    (<HTMLInputElement>document.getElementById('search')).style.display = 'none';
    (<HTMLInputElement>document.getElementById('seekPeace')).style.display = 'none';



     (<HTMLInputElement>document.getElementById('beliefStatementHeader')).style.display = 'none';
     (<HTMLInputElement>document.getElementById('beliefStatementHeader1')).style.display = 'none';
     (<HTMLInputElement>document.getElementById('entry')).style.display = '-webkit-inline-box';
     (<HTMLInputElement>document.getElementById('beliefState')).style.display = 'none';
     (<HTMLInputElement>document.getElementById('topicDes')).style.display = 'none';

      setTimeout(function(){
        //
        (<HTMLInputElement> document.getElementById("preloader")).hidden = false;
      },100);

      
      // config.type = 'info';
    localStorage.setItem('prevpage', this.router.url);

    //alert(params.index);
    this.route.params.subscribe(params => this.beliefStatementsId = params.id);
    this.route.params.subscribe(params => this.index = params.index);
    
    localStorage.setItem("prevID",this.beliefStatementsId);
    //alert(this.index)
    this.value = this.index;

    
   



    this.Service.getBeliefStatementDataDiscover(this.beliefStatementsId,this.index).subscribe(posts => {
      
      if (posts.status == '1') {

        this.data = posts.data;

        this.sequenceData = posts.sequenceData;
        this.selectedId = posts.sequences;
        
        

        for (var j = 0; j < this.sequenceData.length; j++) {
          var letters = '0123456789ABCDEF';
          var color = '#';
          for (var i = 0; i < 6; i++) {
            color += letters[Math.floor(Math.random() * 16)];
          }

          this.sequenceData[j].color = color;
        }


        this.topic = posts.topic;
        this.sideTopic = posts.data;

        // 
        this.active = posts.data[this.index].sequence;

        this.headingtitle = posts.data[this.index].lines;
        this.beliefId = posts.data[this.index].Id;
        this.Service.getFavBeliefStatement(this.beliefId).subscribe(posts => {
          
          if (posts.status == '1') {
            if(posts.msg == 'unfav'){
              (<HTMLInputElement>document.getElementById('toggleMenu1')).style.display = 'none';
              (<HTMLInputElement>document.getElementById('toggleMenu2')).style.display = 'block';
            }
            else if(posts.msg == 'fav'){
              (<HTMLInputElement>document.getElementById('toggleMenu2')).style.display = 'none';
              (<HTMLInputElement>document.getElementById('toggleMenu1')).style.display = 'block';
            }
            //alert("sdfj")
          }
          //alert("hekk")
          setTimeout(()=>{
            var elementqwa = document.getElementById(this.index);
            elementqwa.classList.add("belifactive");
      
            var elementaqwa = document.getElementById(this.index);
            elementaqwa.classList.add("belifstatactive");
          },100);
          this.onChange("BY SEQUENCE");
        });

        setTimeout(function(){
          //
          (<HTMLInputElement> document.getElementById("preloader")).hidden = true;
        },100);
        
      }
    });

    


    

    
    // this.getRandomColor();


  }
  selectedDevice;
  selectedTopicValue;
  //selectedId;
onChange(value){
  
  setTimeout(function(){
    //
    (<HTMLInputElement> document.getElementById("preloader")).hidden = false;
  },100);
  this.selectedTopicValue = value;
  if(value == 'BY TOPIC'){

   
    // var sequenceNoTrim = sequenceNo.trim();
    
    // this.Service.getTopic(sequenceNoTrim,value).subscribe(posts => {
    //   if (posts.status == '1') {
    //     this.sequenceData = posts.sequenceData;

    //     for (var j = 0; j < this.sequenceData.length; j++) {
    //       var letters = '0123456789ABCDEF';
    //       var color = '#';
    //       for (var i = 0; i < 6; i++) {
    //         color += letters[Math.floor(Math.random() * 16)];
    //       }

    //       this.sequenceData[j].color = color;
    //     }
    //   }
    // });

    this.disble="true";
    (<HTMLInputElement>document.getElementById('serch')).disabled = true;

    (<HTMLInputElement>document.getElementById('topic')).hidden = false;
    (<HTMLInputElement>document.getElementById('sequence')).hidden = true;
  }else if(value == 'BY SEQUENCE'){
    this.disble = "false";
    (<HTMLInputElement>document.getElementById('serch')).disabled = false;
    (<HTMLInputElement>document.getElementById('topic')).hidden = true;
    (<HTMLInputElement>document.getElementById('sequence')).hidden = false;
    this.selectedId = this.selectedId.trim();
    
    
    //alert(1);
    this.Service.getSequenceDetailsBySequence(this.selectedId).subscribe(posts => {
      if (posts.status == '1') {
        this.sequenceData1 = posts.sequenceData;

        
        
        this.arrayLength = this.sequenceData1[0].length
        this.classArray = posts.classArray;
        
      }
    });
 
//  var sequenceNoTrim = sequenceNo.trim();
    
//     this.Service.getSequence(sequenceNoTrim,value).subscribe(posts => {
//       if (posts.status == '1') {
//         this.sequenceData = posts.sequenceData;

//         for (var j = 0; j < this.sequenceData.length; j++) {
//           var letters = '0123456789ABCDEF';
//           var color = '#';
//           for (var i = 0; i < 6; i++) {
//             color += letters[Math.floor(Math.random() * 16)];
//           }

//           this.sequenceData[j].color = color;
//         }
//       }
//     });


 
  }
  setTimeout(function(){
    //
    (<HTMLInputElement> document.getElementById("preloader")).hidden = true;
  },100);
}

@HostListener('window:scroll', ['$event'])
  onWindowScroll(e) {
   //
    if (window.pageYOffset > 80) {
      let element = document.getElementById('orange');
      element.classList.add('sticky');
      let element1 = document.getElementById('orangeHeading');
      element1.classList.add('sticky');

    } else {
     let element = document.getElementById('orange');
       element.classList.remove('sticky'); 
       let element1 = document.getElementById('orangeHeading');
       element1.classList.remove('sticky'); 
    } 

  }


lgModalShow() {
  //
  const activeModal = this.modalService.open(Discover2InfoVW, { size: 'lg',backdrop :'static' });
  (<HTMLInputElement> document.getElementById('beliefStatementFnMode')).value = 'a';     
  (<HTMLInputElement> document.getElementById('beliefStatementId')).value ='';
  (<HTMLInputElement> document.getElementById('locationId')).value = '';
   (<HTMLInputElement> document.getElementById('locationName')).value = '';
  (<HTMLInputElement> document.getElementById('createdDt')).value = '';
  (<HTMLInputElement> document.getElementById('createdBy')).value ='';
 activeModal.componentInstance.modalHeader = 'Large Modal';
}


  goToBelief(sequenceNo, rowval) {
    this.limit = 2;
    this.limitAR = 0;
    var elementqw = document.getElementById(this.value); elementqw.classList.remove("belifactive");
    var elementaqw = document.getElementById("a" + this.value); elementaqw.classList.remove("belifstatactive");

    var element = document.getElementById(rowval); element.classList.add("belifactive");
    var elementa = document.getElementById("a" + rowval); elementa.classList.add("belifstatactive");

    this.headingtitle = this.data[rowval].lines;
    this.beliefId = this.data[rowval].Id;

    this.value = rowval;
    this.index =  rowval;

    var sequenceNoTrim = sequenceNo.trim();

    this.selectedId = sequenceNo;
    this.Service.getBeliefStatementsequence(sequenceNoTrim).subscribe(posts => {
      if (posts.status == '1') {
        this.sequenceData = posts.sequenceData;

        
        

        for (var j = 0; j < this.sequenceData.length; j++) {
          var letters = '0123456789ABCDEF';
          var color = '#';
          for (var i = 0; i < 6; i++) {
            color += letters[Math.floor(Math.random() * 16)];
          }

          this.sequenceData[j].color = color;
        }

        this.Service.getFavBeliefStatement(this.beliefId).subscribe(posts => {
          
          if (posts.status == '1') {
            if(posts.msg == 'unfav'){
              (<HTMLInputElement>document.getElementById('toggleMenu1')).style.display = 'none';
              (<HTMLInputElement>document.getElementById('toggleMenu2')).style.display = 'block';
            }
            else if(posts.msg == 'fav'){
              (<HTMLInputElement>document.getElementById('toggleMenu2')).style.display = 'none';
              (<HTMLInputElement>document.getElementById('toggleMenu1')).style.display = 'block';
            }
          }
        });
      }
    });
    setTimeout(function(){
      //
      (<HTMLInputElement> document.getElementById("preloader")).hidden = false;
    },100);
    this.Service.getSequenceDetailsBySequence(sequenceNoTrim).subscribe(posts => {
      if (posts.status == '1') {
        this.sequenceData1 = posts.sequenceData;

        
        
        this.arrayLength = this.sequenceData1[0].length
        this.classArray = posts.classArray;
        
        setTimeout(function(){
          //
          (<HTMLInputElement> document.getElementById("preloader")).hidden = true;
        },100);
      }
    });

    $('#seq').val('BY SEQUENCE');
    (<HTMLInputElement>document.getElementById('topic')).hidden = true;
    (<HTMLInputElement>document.getElementById('sequence')).hidden = false;
     //alert(sequenceNo);

    


  }

  public toggleMenu() {
    this.basidebar.sidemenutoggle();
    this.resetMethod();
  }



  resetMethod() {
    if (this.padd == "sidemenu") {
      this.padd = "";
      (<HTMLInputElement>document.getElementById('toggleMenu2')).style.display = 'contents';

    } else {
      this.padd = "sidemenu";
      (<HTMLInputElement>document.getElementById('toggleMenu2')).style.display = 'none';

    }

  }

  modelOpen(val, val1) {

  }

  tobooks() {
    this.router.navigate(['pages/masters/books/']);
    // this.router.navigate(['pages/masters/topics/'+id]);


  }


  makeFav() {
    // alert(this.beliefId);
    // alert("makeFav");

    this.Service.saveMakeFavBeliefStatement(this.beliefId).subscribe(posts => {
      
      if (posts.status == '1') {
        (<HTMLInputElement>document.getElementById('toggleMenu2')).style.display = 'none';
        (<HTMLInputElement>document.getElementById('toggleMenu1')).style.display = 'block';
      }
    });
  }

  makeUnfav() {
    // alert("makeUnfav");
    this.Service.saveMakeUnFavBeliefStatement(this.beliefId).subscribe(posts => {
      
      if (posts.status == '1') {
        (<HTMLInputElement>document.getElementById('toggleMenu1')).style.display = 'none';
        (<HTMLInputElement>document.getElementById('toggleMenu2')).style.display = 'block';
      }
    });

  }
  changeArrow(id){
  //    
  // 
  // 
  // 
if(this.classArray[id]['flag']==2){
  // 
  this.classArray[id]['icon-arrow-down']=true;
  this.classArray[id]['icon-arrow-up']=false;
  // 
  this.classArray[id]['flag']=3;
}
else {
  // 
  this.classArray[id]['icon-arrow-down']=false;
  this.classArray[id]['icon-arrow-up']=true;
  // 
  this.classArray[id]['flag']=2;
}
  // 
  }

  limitAR = 0;
  addlimit(){
    (<HTMLInputElement>document.getElementById('sequence')).scrollTop  -= 50;
    
    this.limit +=5;
    //this.panel.nativeElement.scrollIntoView({ behavior: 'smooth', block: 'end', inline: 'start' });
    //this.panel.nativeElement.scrollTop += 20;
    //window.scrollBy(0, 100);
    //this.limit = this.limit+5;
    //document.getElementById('divElem').scrollTop += 10;
  }
  minusLimit(){
    this.limit -=5;
  }

  addlimitAR(){
    //alert("skjh")
    if(this.limitAR == 0){

      this.limitAR =1;
      
    }
    else{
      this.limitAR = 0;
    }
  }
  minusLimitAR(){
    this.limitAR =0;
  }
  search(value){
    this.limit = 2;
    this.limitAR = 0;
    this.Service.getSequenceDetailsBySequenceBySearch(this.selectedId,value).subscribe(posts => {
      if (posts.status == '1') {
        this.sequenceData1 = posts.sequenceData;

        // 
        // 
        this.arrayLength = this.sequenceData1[0].length
        this.classArray = posts.classArray;
        // 
      }
    });
  }

  goBackToBelief(){
    this.router.navigate(['pages/masters/beliefDiscover/'+this.beliefStatementsId]);
  }
  dataAR;
  addPassage(id,value){
    $("#AR_"+id).toggle();
    if(document.getElementById("rest_"+id).className == 'fa fa-chevron-circle-right'){
      document.getElementById("rest_"+id).classList.remove("fa-chevron-circle-right");
      document.getElementById("rest_"+id).classList.add("fa-chevron-circle-down");
    }
    else{

      //document.getElementById("rest_"+id).classList.remove("fa");
      document.getElementById("rest_"+id).classList.remove("fa-chevron-circle-down");
      document.getElementById("rest_"+id).className = "fa fa-chevron-circle-right";
    }

    
    //$('#AR_'+id).append(value);
    $('#AR_'+id).empty();
   //alert(document.getElementById("rest_"+id).className);
    value = value.replace("But see also, ","");
    value = value.replace("But see also,  ","");
    value = value.replace("But see also,","");
    value = value.replace("See also,  ","");
    value = value.replace("See also, ","");
    value = value.replace("See also,","");
    
    this.Service.getPassageFromDatabaseSheet(value).subscribe(posts => {
       
      if (posts.status == '1') {
       
       
        this.dataAR = posts.AdditionalRe;
        for(let g=0;g<posts.AdditionalRe.length;g++){
          // 
          $('#AR_'+id).append(`<div class="col-md-12" >
          <div style="margin: 10px 0px -3px 26px;font-size: 15px;">
       `+this.dataAR[g].passage+`

        </div>
         <div style="margin: 10px 26px;color: dodgerBlue;font-size: 15px;">
         
         <a class="blueColor profile-toggle-link dropdown-toggle" id="user-profile"
                        data-toggle="dropdown" aria-expanded="false" style="cursor:pointer">
                        `
         +this.dataAR[g].book+` `+this.dataAR[g].chapter+`.`+this.dataAR[g].verse+
         `
         </a>
         <div class="dropdown-menu top-dropdown-menu profile-dropdown" aria-labelledby="user-profile" style="width: 60% !important;height: 170% !important;">
                            <div class=""></div>
                            <h3 class="popover-title">`
                            +this.dataAR[g].book+` `+this.dataAR[g].chapter+`.`+this.dataAR[g].verse+
                            `</h3>
                            <div class="popover-content" style="height: 90px!important;">
                              <p style="margin-bottom:10px; height: 55%;overflow: scroll;">`
                              +this.dataAR[g].scripture+
                              `
                              </p>
  
  
                            </div>
                          </div>

         
         </div>
        <hr>
      </div>`);

          
        }
        // this.sequenceData1 = posts.sequenceData;

        // 
        // 
        // this.arrayLength = this.sequenceData1[0].length
        // this.classArray = posts.classArray;
        // 
      }
    });

    // (<HTMLInputElement> document.getElementById('rest_'+id)).classList.toggle("fa fa-chevron-circle-right");
     


    // document.getElementById("rest_"+id).className = "fa fa-chevron-circle-down";



  }

  changeClass(k){
    // (<HTMLInputElement> document.getElementById('rest')).classList.remove("ready");
  //  document.getElementById("rest_"+k).classList.remove("fa-chevron-circle-right");
  // document.getElementById("rest_"+k).classList.remove("fa-chevron-circle-right");
  // document.getElementById("rest_"+k).className = "fa fa-chevron-circle-down";


    // document.getElementById("rest_"+k).className = "fa fa-chevron-circle-left";

  }

  public moveToSpecificView(): void {
    setTimeout(() => {
        this.panel.nativeElement.scrollIntoView({ behavior: 'smooth', block: 'end', inline: 'start' });
    });
}


}


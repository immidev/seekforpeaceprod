import { Component, OnInit, Inject, ElementRef, AfterViewInit, group } from '@angular/core';
import { NgbModal, NgbDateStruct, NgbAccordionConfig } from '@ng-bootstrap/ng-bootstrap';
import { LocalDataSource } from 'ng2-smart-table';
import { HttpModule } from '@angular/http';
import { Typeahead } from 'ng2-typeahead-master';


import { Observable } from 'rxjs/Observable';
import { ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { MastersService } from '../../masters.service';
//declare var google: any;
declare var System: any; 
import './googletranslate.js';
import { BeliefStatementInfoVW } from '../beliefStatements/beliefStatementInfoVW';
import { BaSidebar } from 'app/theme/components';

@Component({
  selector: 'topics',
  styleUrls: ['./topics.scss'],
  //scripts : [],
  templateUrl: './topics.html',
})
export class Topics {
  sequenceNo(arg0: string, sequenceNo: any): any {
    throw new Error("Method not implemented.");
  }
  public isMenuCollapsed: boolean = true;
  padd;
  beliefStatementsId: any;


  @ViewChild(BaSidebar) basidebar: BaSidebar;
  color: string;
  topic: any;
  sideTopic: any;
  active: any;
  value: any;
  headingtitle: any;
  beliefId: any;
  data: any;
  sequenceData: any;
  seq: any;

  constructor(private router: Router, private route: ActivatedRoute, 
    private Service: MastersService,private modalService: NgbModal,
    config: NgbAccordionConfig) {
      config.closeOthers = true;
      config.type = 'info';
    localStorage.setItem('prevpage', this.router.url);


    this.route.params.subscribe(params => this.beliefStatementsId = params.id);
    console.log(this.beliefStatementsId);

    this.Service.getBeliefStatementData(this.beliefStatementsId).subscribe(posts => {
      console.log(posts);
      if (posts.status == '1') {

        this.data = posts.data;

        this.sequenceData = posts.sequenceData;

        console.log(this.sequenceData);
        console.log(this.sequenceData.length);

        for (var j = 0; j < this.sequenceData.length; j++) {
          var letters = '0123456789ABCDEF';
          var color = '#';
          for (var i = 0; i < 6; i++) {
            color += letters[Math.floor(Math.random() * 16)];
          }

          this.sequenceData[j].color = color;
        }


        this.topic = posts.topic;
        this.sideTopic = posts.data;

        // console.log(posts.data[0].sequence);
        this.active = posts.data[0].sequence;

        this.headingtitle = posts.data[0].lines;
        this.beliefId = posts.data[0].Id;
        this.Service.getFavBeliefStatement(this.beliefId).subscribe(posts => {
          console.log(posts);
          if (posts.status == '1') {
            if(posts.msg == 'unfav'){
              (<HTMLInputElement>document.getElementById('toggleMenu1')).style.display = 'none';
              (<HTMLInputElement>document.getElementById('toggleMenu2')).style.display = 'block';
            }
            else if(posts.msg == 'fav'){
              (<HTMLInputElement>document.getElementById('toggleMenu2')).style.display = 'none';
              (<HTMLInputElement>document.getElementById('toggleMenu1')).style.display = 'block';
            }
          }
          this.onChange("BY TOPIC",this.sequenceNo);
        });
      }
    });

    


    // setTimeout(()=>{
    //   var elementqwa = document.getElementById("0");
    //   elementqwa.classList.add("belifactive");

    //   var elementaqwa = document.getElementById("a0");
    //   elementaqwa.classList.add("belifstatactive");
    // },1500);

    this.value = 0;
    // this.getRandomColor();


  }
  selectedDevice;

  
onChange(value,sequenceNo){
  console.log(value);

  if(value == 'BY TOPIC'){

   
    // var sequenceNoTrim = sequenceNo.trim();
    
    // this.Service.getTopic(sequenceNoTrim,value).subscribe(posts => {
    //   if (posts.status == '1') {
    //     this.sequenceData = posts.sequenceData;

    //     for (var j = 0; j < this.sequenceData.length; j++) {
    //       var letters = '0123456789ABCDEF';
    //       var color = '#';
    //       for (var i = 0; i < 6; i++) {
    //         color += letters[Math.floor(Math.random() * 16)];
    //       }

    //       this.sequenceData[j].color = color;
    //     }
    //   }
    // });



    (<HTMLInputElement>document.getElementById('topic')).hidden = false;
    (<HTMLInputElement>document.getElementById('sequence')).hidden = true;
  }else if(value == 'BY SEQUENCE'){

    (<HTMLInputElement>document.getElementById('topic')).hidden = true;
    (<HTMLInputElement>document.getElementById('sequence')).hidden = false;
 
 
//  var sequenceNoTrim = sequenceNo.trim();
    
//     this.Service.getSequence(sequenceNoTrim,value).subscribe(posts => {
//       if (posts.status == '1') {
//         this.sequenceData = posts.sequenceData;

//         for (var j = 0; j < this.sequenceData.length; j++) {
//           var letters = '0123456789ABCDEF';
//           var color = '#';
//           for (var i = 0; i < 6; i++) {
//             color += letters[Math.floor(Math.random() * 16)];
//           }

//           this.sequenceData[j].color = color;
//         }
//       }
//     });


 
  }

}


lgModalShow() {
  //console.log('testingggg');
  const activeModal = this.modalService.open(BeliefStatementInfoVW, { size: 'lg',backdrop :'static' });
  (<HTMLInputElement> document.getElementById('beliefStatementFnMode')).value = 'a';     
  (<HTMLInputElement> document.getElementById('beliefStatementId')).value ='';
  (<HTMLInputElement> document.getElementById('locationId')).value = '';
   (<HTMLInputElement> document.getElementById('locationName')).value = '';
  (<HTMLInputElement> document.getElementById('createdDt')).value = '';
  (<HTMLInputElement> document.getElementById('createdBy')).value ='';
 activeModal.componentInstance.modalHeader = 'Large Modal';
}

goTo(){
  this.router.navigate(['pages/masters/homeScreen']);
}

  goToBelief(sequenceNo, rowval) {

    var elementqw = document.getElementById(this.value); elementqw.classList.remove("belifactive");
    var elementaqw = document.getElementById("a" + this.value); elementaqw.classList.remove("belifstatactive");

    var element = document.getElementById(rowval); element.classList.add("belifactive");
    var elementa = document.getElementById("a" + rowval); elementa.classList.add("belifstatactive");

    this.headingtitle = this.data[rowval].lines;
    this.beliefId = this.data[rowval].Id;

    this.value = rowval;

    var sequenceNoTrim = sequenceNo.trim();


    this.Service.getBeliefStatementsequence(sequenceNoTrim).subscribe(posts => {
      if (posts.status == '1') {
        this.sequenceData = posts.sequenceData;

        console.log(this.sequenceData);
        console.log(this.sequenceData.length);

        for (var j = 0; j < this.sequenceData.length; j++) {
          var letters = '0123456789ABCDEF';
          var color = '#';
          for (var i = 0; i < 6; i++) {
            color += letters[Math.floor(Math.random() * 16)];
          }

          this.sequenceData[j].color = color;
        }

        this.Service.getFavBeliefStatement(this.beliefId).subscribe(posts => {
          console.log(posts);
          if (posts.status == '1') {
            if(posts.msg == 'unfav'){
              (<HTMLInputElement>document.getElementById('toggleMenu1')).style.display = 'none';
              (<HTMLInputElement>document.getElementById('toggleMenu2')).style.display = 'block';
            }
            else if(posts.msg == 'fav'){
              (<HTMLInputElement>document.getElementById('toggleMenu2')).style.display = 'none';
              (<HTMLInputElement>document.getElementById('toggleMenu1')).style.display = 'block';
            }
          }
        });
      }
    });


    // alert(sequenceNo);

    


  }


goToBelief1(){
  
  this.router.navigate(['pages/masters/beliefStatements/'+this.beliefStatementsId]);
}

  public toggleMenu() {
    this.basidebar.sidemenutoggle();
    this.resetMethod();
  }



  resetMethod() {
    if (this.padd == "sidemenu") {
      this.padd = "";
      (<HTMLInputElement>document.getElementById('toggleMenu2')).style.display = 'contents';

    } else {
      this.padd = "sidemenu";
      (<HTMLInputElement>document.getElementById('toggleMenu2')).style.display = 'none';

    }

  }

  modelOpen(val, val1) {

  }

  searchBelief() {
    this.router.navigate(['pages/masters/searchBelief']);
  }


  makeFav() {
    // alert(this.beliefId);
    // alert("makeFav");

    this.Service.saveMakeFavBeliefStatement(this.beliefId).subscribe(posts => {
      console.log(posts);
      if (posts.status == '1') {
        (<HTMLInputElement>document.getElementById('toggleMenu2')).style.display = 'none';
        (<HTMLInputElement>document.getElementById('toggleMenu1')).style.display = 'block';
      }
    });
  }

  makeUnfav() {
    // alert("makeUnfav");
    this.Service.saveMakeUnFavBeliefStatement(this.beliefId).subscribe(posts => {
      console.log(posts);
      if (posts.status == '1') {
        (<HTMLInputElement>document.getElementById('toggleMenu1')).style.display = 'none';
        (<HTMLInputElement>document.getElementById('toggleMenu2')).style.display = 'block';
      }
    });

  }


}

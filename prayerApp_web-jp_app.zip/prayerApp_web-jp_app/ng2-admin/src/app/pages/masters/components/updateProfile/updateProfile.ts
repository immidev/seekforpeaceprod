import { Component, OnInit, Inject, ElementRef, AfterViewInit, group } from '@angular/core';
import { NgbModal, NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { LocalDataSource } from 'ng2-smart-table';
import { HttpModule } from '@angular/http';
import { Typeahead } from 'ng2-typeahead-master';
import { FormGroup, AbstractControl, FormBuilder, Validators } from '@angular/forms';
import { EmailValidator, EqualPasswordsValidator } from '../../../../theme/validators';


import { Observable } from 'rxjs/Observable';
import { ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { MastersService } from '../../masters.service';
//declare var google: any;
declare var System: any; 
declare var googleTranslateElementInit: any;
import './googletranslate.js';
import { UserUpdateProfileService } from './updateProfile.service';
declare var swal: any;  //For Sweet Alert

@Component({
  selector: 'updateProfile',
  styleUrls: ['./updateProfile.scss'],
  //scripts : [],
  templateUrl: './updateProfile.html',
})
export class UpdateProfile {

  topicList;
  radioValue = 'T';
  BList;
  CList;
  public form: FormGroup;
  public email: AbstractControl;
  public password: AbstractControl;
  public submitted: boolean = false;
  datePicker = {
    dob: null
    };
  dob: string;
  // firstName;
  // lastname;
  // mobileNumber;
  // landLine;
  // nativeLanguage;
  // address;
  // state;
  // zip;
  // country;
  @ViewChild('dateOfBirth') dateOfBirth: ElementRef;
  @ViewChild('firstName') firstName: ElementRef;
  @ViewChild('lastname') lastname: ElementRef;
  @ViewChild('mobileNumber') mobileNumber: ElementRef;
  @ViewChild('landLine') landLine: ElementRef;
  @ViewChild('nativeLanguage') nativeLanguage: ElementRef;
  @ViewChild('address') address: ElementRef;
  @ViewChild('country') country: ElementRef;
  @ViewChild('state') state: ElementRef;
  @ViewChild('zip') zip: ElementRef;
  
  constructor(fb: FormBuilder,private Service: UserUpdateProfileService, private router: Router) {
    console.log("inside home construction");

    // this.form = fb.group({
    //   'firstName': ['', Validators.compose([Validators.required])],
    //   'lastName': ['', Validators.compose([Validators.required])],
    //   'mobileNumber': ['', Validators.compose([Validators.required])],
    //   'landLine': ['', Validators.compose([Validators.required])],
    //   'nativeLanguage': ['', Validators.compose([Validators.required])],
    //   'dob': ['', Validators.compose([Validators.required])],
    //   'address': ['', Validators.compose([Validators.required])],
    //   'country': ['', Validators.compose([Validators.required])],
    //   'state': ['', Validators.compose([Validators.required])],
    //   'zip': ['', Validators.compose([Validators.required])],
    // });


    // this.firstName.nativeElement.value = localStorage.getItem('firstname');
    

    this.Service.getProfileDetails().subscribe(posts => {
          if (posts.status == 1) {
            console.log(posts.data)
            this.firstName.nativeElement.value = posts.data[0].name;
            this.lastname.nativeElement.value = posts.data[0].lastname;
            this.mobileNumber.nativeElement.value = posts.data[0].Mobile;
            this.landLine.nativeElement.value = posts.data[0].Landline;
            this.nativeLanguage.nativeElement.value = posts.data[0].NativeLanguage;
            this.dateOfBirth.nativeElement.value = posts.data[0].DOB;
            this.address.nativeElement.value = posts.data[0].Address;
            this.country.nativeElement.value = posts.data[0].Country;
            this.state.nativeElement.value = posts.data[0].State;
            this.zip.nativeElement.value = posts.data[0].Zip;
            //this.onChange("T");
          }
          else {
            (<HTMLInputElement>document.getElementById("errorMsg")).style.display = 'block';
            (<HTMLInputElement>document.getElementById("errorMsg")).innerHTML = posts.status;
          }
        });
    // if(localStorage.getItem('reload')=='Y'){

    //   window.location.reload();
    //   localStorage.setItem('reload','N');
    // }
    // setTimeout(function(){
    //   //console.log("hsjhsdhjfsdjh");
    //   (<HTMLInputElement> document.getElementById("preloader")).hidden = false;
    // },100);

    
  }








    //new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
    // console.log("After function inside home construction")
    //new googleTranslateElementInit();
  //   this.Service.getTopics().subscribe(posts => {
  //     //alert(1);
  //     //(<HTMLInputElement> document.getElementById("preloader")).hidden = true;
  //     if (posts.status == 1) {
        
  //       //console.log(posts.data)
  //       this.topicList = posts.data;
  //       this.onChange("T");
  //       setTimeout(function(){
  //         console.log("hsjhsdhjfsdjh");
  //         (<HTMLInputElement> document.getElementById("preloader")).hidden = true;
  //       },100);
        
  //     }
  //     else {
  //       (<HTMLInputElement>document.getElementById("errorMsg")).style.display = 'block';
  //       (<HTMLInputElement>document.getElementById("errorMsg")).innerHTML = posts.status;
  //     }
  //   });
  //   //this.onChange("T");
  // }

//   ngOnInit (){
//     //this.;
//  }


//   goToBelief(id){
//     //alert("asjh")
//     //this.router.navigate(['pages/masters/beliefStatements/'+id]);
//     console.log("hkhaks");
//     console.log("ashakshdkashdkahsd")
//     this.router.navigate(['pages/masters/beliefUpdateProfile/'+id]);
//   }



//   onChange(value){
//     console.log(value);
//   this.radioValue = value;
//     if(value == 'T'){
      
//      // console.log(value);
//       (<HTMLInputElement>document.getElementById('Topics')).hidden = false;
//       (<HTMLInputElement>document.getElementById('Belief')).hidden = true;
//       (<HTMLInputElement>document.getElementById('Concepts')).hidden = true;
      
//     }else if(value == 'B'){
  
//       (<HTMLInputElement>document.getElementById('Topics')).hidden = true;
//       (<HTMLInputElement>document.getElementById('Belief')).hidden = false;
//       (<HTMLInputElement>document.getElementById('Concepts')).hidden = true;

   
//     }
//     else if(value == 'C'){
  
//       (<HTMLInputElement>document.getElementById('Topics')).hidden = true;
//       (<HTMLInputElement>document.getElementById('Belief')).hidden = true;
//       (<HTMLInputElement>document.getElementById('Concepts')).hidden = false;

   
//     }
    
  
//   }
//   search(event){
//     console.log(event)
//     //console.log("helloe")
// if(this.radioValue == 'T'){
//   this.Service.getTopicsBysearch(event).subscribe(posts => {
//     if (posts.status == 1) {
//       //console.log(posts.data)
//       this.topicList = posts.data;
//       //this.onChange("T");
//     }
//     else {
//       (<HTMLInputElement>document.getElementById("errorMsg")).style.display = 'block';
//       (<HTMLInputElement>document.getElementById("errorMsg")).innerHTML = posts.status;
//     }
//   });
// }
// else if(this.radioValue == 'B'){
//   //console.log("jahs")

//   this.Service.getBSBysearch(event).subscribe(posts => {
//     if (posts.status == 1) {
//       console.log(posts.data)
//       this.BList = posts.data;
//       //this.onChange("T");
//     }
//     else {
//       (<HTMLInputElement>document.getElementById("errorMsg")).style.display = 'block';
//       (<HTMLInputElement>document.getElementById("errorMsg")).innerHTML = posts.status;
//     }
//   });

// }
// else if(this.radioValue == 'C'){
//   //console.log("jahs")

//   this.Service.getConceptsBysearch(event).subscribe(posts => {
//     if (posts.status == 1) {
//       console.log(posts.data)
//       this.CList = posts.data;
//       //this.onChange("T");
//     }
//     else {
//       (<HTMLInputElement>document.getElementById("errorMsg")).style.display = 'block';
//       (<HTMLInputElement>document.getElementById("errorMsg")).innerHTML = posts.status;
//     }
//   });

// }
   
  // }

  
  onSubmit() {
    this.dob=this.dateOfBirth.nativeElement.value;
    console.log(this.dateOfBirth.nativeElement.value);
    console.log(this.dob);
    this.Service.updateProfile(
      this.firstName.nativeElement.value,
      this.lastname.nativeElement.value,
      this.mobileNumber.nativeElement.value,
      this.landLine.nativeElement.value,
      this.nativeLanguage.nativeElement.value,
      this.dateOfBirth.nativeElement.value,
      this.address.nativeElement.value,
      this.country.nativeElement.value,
      this.state.nativeElement.value,
      this.zip.nativeElement.value,
      this.dob).subscribe(posts => {
        console.log(posts);
        console.log(posts.status);
        if (posts.status == '1') {
          localStorage.setItem('currentUser', 'val');
          localStorage.setItem('currentUser', 'login');
          localStorage.setItem('userId', posts.id);
          //  if(posts.userTO.groupName == 'ADMINISTRATOR'){
          //     localStorage.setItem('passwordfield_dynamic', 'ADMINISTRATOR');  
          //  }else{
          //   localStorage.setItem('passwordfield_ dynamic', '');  
          //  }
          //this.router.navigate(['membership']);
          swal({ title: "Success!", text:posts.msg, type: 'success',});
          this.router.navigate(['Discover']);


        }
        else {
          swal({ title: "Failed!", text:posts.msg, type: 'warning',});

          // (<HTMLInputElement>document.getElementById("errorMsg")).style.display = 'block';
          // (<HTMLInputElement>document.getElementById("errorMsg")).innerHTML = posts.msg;
        }
      });
    // this.router.navigate(['membership']);
  }


onSelectFromDate(date: NgbDateStruct){
 // console.log("***************");
 // console.log(date);
 // console.log(this.dob);
if (date != null) {
let stringStartDate: string = ""; 
if(date) {
stringStartDate += this.isNumber(date.day) ? this.padNumber(date.day) + "-" : "";
stringStartDate += this.isNumber(date.month) ? this.padNumber(date.month) + "-" : "";
stringStartDate += date.year;
}
//console.log(stringStartDate)
this.dob = stringStartDate;
// console.log("=========="+this.dob);

this.dateOfBirth.nativeElement.value =stringStartDate; 
}
}

padNumber(value: number) {
if (this.isNumber(value)) {
return `0${value}`.slice(-2);
} else {
return "";
}
}

isNumber(value: any): boolean {
return !isNaN(this.toInteger(value));
}

toInteger(value: any): number {
return parseInt(`${value}`, 10);
}


  
}


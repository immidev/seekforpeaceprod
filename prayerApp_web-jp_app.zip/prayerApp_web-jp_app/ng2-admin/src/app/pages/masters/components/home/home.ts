import { Component, OnInit, Inject, ElementRef, AfterViewInit, group } from '@angular/core';
import { NgbModal, NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { LocalDataSource } from 'ng2-smart-table';
import { HttpModule } from '@angular/http';
import { Typeahead } from 'ng2-typeahead-master';


import { Observable } from 'rxjs/Observable';
import { ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { MastersService } from '../../masters.service';
//declare var google: any;
declare var System: any; 
import './googletranslate.js';


@Component({
  selector: 'home',
  styleUrls: ['./home.scss'],
  //scripts : [],
  templateUrl: './home.html',
})
export class Home {

  topicList;
  radioValue = 'T';
  BList;
  CList;
  constructor(private Service: MastersService, private router: Router,private modalService: NgbModal) {

    // this.Service.getHome().subscribe(posts => {
    //   if (posts.status == 1) {
     
    //     this.topicList = posts.data;
    
    //   }
    //   else {
    //     (<HTMLInputElement>document.getElementById("errorMsg")).style.display = 'block';
    //     (<HTMLInputElement>document.getElementById("errorMsg")).innerHTML = posts.status;
    //   }
    // });

    (<HTMLInputElement>document.getElementById('TopicHeader')).style.display = 'none';
    (<HTMLInputElement>document.getElementById('WholeHeader')).style.display = 'block';
    // (<HTMLInputElement>document.getElementById('search')).style.display = 'block';
    (<HTMLInputElement>document.getElementById('seekPeace')).style.display = 'block';

    (<HTMLInputElement>document.getElementById('beliefStatementHeader')).style.display = 'none';
    (<HTMLInputElement>document.getElementById('beliefStatementHeader1')).style.display = 'none';
    (<HTMLInputElement>document.getElementById('topicDes')).style.display = 'none';
    (<HTMLInputElement>document.getElementById('entry')).style.display = 'none';
    (<HTMLInputElement>document.getElementById('beliefState')).style.display = 'none';
    (<HTMLInputElement>document.getElementById('header_two')).style.display = 'none';


  }

  ngOnInit (){
    //this.;
 }


  goToBelief(id){
    //this.router.navigate(['pages/masters/beliefStatements/'+id]);
    console.log("hkhaks")
    this.router.navigate(['pages/masters/topics/'+id]);
  }

  // lgModalShow(id) {

  //   console.log('testingggg');
  //   console.log(id);
  //   const activeModal = this.modalService.open(GetInfo, { size: 'lg',backdrop :'static' });
  //   // (<HTMLInputElement> document.getElementById('beliefStatementFnMode')).value = 'a';     
  //   (<HTMLInputElement> document.getElementById('beliefStatementId')).value =id;
  //   // (<HTMLInputElement> document.getElementById('locationId')).value = '';
  //   //  (<HTMLInputElement> document.getElementById('locationName')).value = '';
  //   // (<HTMLInputElement> document.getElementById('createdDt')).value = '';
  //   // (<HTMLInputElement> document.getElementById('createdBy')).value ='';
  //  activeModal.componentInstance.modalHeader = 'Large Modal';
  // }

  onChange(value){
    console.log(value);
  this.radioValue = value;
    if(value == 'T'){
      
     // console.log(value);
      (<HTMLInputElement>document.getElementById('Topics')).hidden = false;
      (<HTMLInputElement>document.getElementById('Belief')).hidden = true;
      (<HTMLInputElement>document.getElementById('Concepts')).hidden = true;
      
    }else if(value == 'B'){
  
      (<HTMLInputElement>document.getElementById('Topics')).hidden = true;
      (<HTMLInputElement>document.getElementById('Belief')).hidden = false;
      (<HTMLInputElement>document.getElementById('Concepts')).hidden = true;

   
    }
    else if(value == 'C'){
  
      (<HTMLInputElement>document.getElementById('Topics')).hidden = true;
      (<HTMLInputElement>document.getElementById('Belief')).hidden = true;
      (<HTMLInputElement>document.getElementById('Concepts')).hidden = false;

   
    }
    
  
  }
  search(event){
    console.log(event)
    //console.log("helloe")
if(this.radioValue == 'T'){
  this.Service.getTopicsBysearch(event).subscribe(posts => {
    if (posts.status == 1) {
      //console.log(posts.data)
      this.topicList = posts.data;
      //this.onChange("T");
    }
    else {
      (<HTMLInputElement>document.getElementById("errorMsg")).style.display = 'block';
      (<HTMLInputElement>document.getElementById("errorMsg")).innerHTML = posts.status;
    }
  });
}
else if(this.radioValue == 'B'){
  //console.log("jahs")

  this.Service.getBSBysearch(event).subscribe(posts => {
    if (posts.status == 1) {
      console.log(posts.data)
      this.BList = posts.data;
      //this.onChange("T");
    }
    else {
      (<HTMLInputElement>document.getElementById("errorMsg")).style.display = 'block';
      (<HTMLInputElement>document.getElementById("errorMsg")).innerHTML = posts.status;
    }
  });

}
else if(this.radioValue == 'C'){
  //console.log("jahs")

  this.Service.getConceptsBysearch(event).subscribe(posts => {
    if (posts.status == 1) {
      console.log(posts.data)
      this.CList = posts.data;
      //this.onChange("T");
    }
    else {
      (<HTMLInputElement>document.getElementById("errorMsg")).style.display = 'block';
      (<HTMLInputElement>document.getElementById("errorMsg")).innerHTML = posts.status;
    }
  });

}
   
  }


}


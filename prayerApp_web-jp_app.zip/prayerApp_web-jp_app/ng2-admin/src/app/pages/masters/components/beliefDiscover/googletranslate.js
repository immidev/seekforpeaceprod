
  function googleTranslateElementInit() {
    console.log("inside translate pageds")
    new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
  }

  function arun(){
      alert("hi")
  }
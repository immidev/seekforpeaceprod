import { Component, OnInit, Inject, ElementRef, AfterViewInit, group } from '@angular/core';
import { NgbModal, NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { LocalDataSource } from 'ng2-smart-table';
import { HttpModule } from '@angular/http';
import { Typeahead } from 'ng2-typeahead-master';


import { Observable } from 'rxjs/Observable';
import { ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { MastersService } from '../../masters.service';
//declare var google: any;
declare var System: any; 
import './googletranslate.js';

@Component({
  selector: 'notes',
  styleUrls: ['./notes.scss'],
  //scripts : [],
  templateUrl: './notes.html',
})
export class Notes {

  topicList;
  constructor(private Service: MastersService, private router: Router) {
    console.log("inside home construction")
    //new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
    console.log("After function inside home construction")

    this.Service.getTopics().subscribe(posts => {
      if (posts.status == 1) {
        //console.log(posts.data)
        this.topicList = posts.data;
      }
      else {
        (<HTMLInputElement>document.getElementById("errorMsg")).style.display = 'block';
        (<HTMLInputElement>document.getElementById("errorMsg")).innerHTML = posts.status;
      }
    });
    
  }

  ngOnInit (){
    //this.;
 }


  goToBelief(id){
    this.router.navigate(['pages/masters/beliefStatements/'+id]);
  }


  
  search(event){
    console.log(event);
  this.Service.getTopicsBysearch(event).subscribe(posts => {
    if (posts.status == 1) {
      //console.log(posts.data)
      this.topicList = posts.data;
      //this.onChange("T");
    }
    else {
      (<HTMLInputElement>document.getElementById("errorMsg")).style.display = 'block';
      (<HTMLInputElement>document.getElementById("errorMsg")).innerHTML = posts.status;
    }
  });
}


}


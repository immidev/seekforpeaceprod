import { Component, OnInit, Inject, ElementRef, AfterViewInit, group } from '@angular/core';
import { NgbModal, NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { LocalDataSource } from 'ng2-smart-table';
import { HttpModule } from '@angular/http';
import { Typeahead } from 'ng2-typeahead-master';


import { Observable } from 'rxjs/Observable';
import { ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { MastersService } from '../../masters.service';
//declare var google: any;
declare var System: any; 
import './googletranslate.js';

@Component({
  selector: 'bookmarks',
  styleUrls: ['./bookmarks.scss'],
  //scripts : [],
  templateUrl: './bookmarks.html',
})
export class Bookmarks {

  topicList;
  constructor(private Service: MastersService, private router: Router) {
    (<HTMLInputElement>document.getElementById('TopicHeader')).style.display = 'none';
    (<HTMLInputElement>document.getElementById('WholeHeader')).style.display = 'none';

     (<HTMLInputElement>document.getElementById('beliefStatementHeader')).style.display = 'none';
     (<HTMLInputElement>document.getElementById('beliefStatementHeader1')).style.display = 'none';
     (<HTMLInputElement>document.getElementById('entry')).style.display = 'none';
     (<HTMLInputElement>document.getElementById('beliefState')).style.display = 'none';
     (<HTMLInputElement>document.getElementById('topicDes')).style.display = 'none';
     (<HTMLInputElement>document.getElementById('seekPeace')).style.display = 'none';

    

    this.Service.getTopics().subscribe(posts => {
      if (posts.status == 1) {
        //console.log(posts.data)
        this.topicList = posts.data;
      }
      else {
        (<HTMLInputElement>document.getElementById("errorMsg")).style.display = 'block';
        (<HTMLInputElement>document.getElementById("errorMsg")).innerHTML = posts.status;
      }
    });
    
  }

  ngOnInit (){
    //this.;
 }


  goToBelief(id){
    this.router.navigate(['pages/masters/beliefStatements/'+id]);
  }


  search(event){
    console.log(event);
  this.Service.getTopicsBysearch(event).subscribe(posts => {
    if (posts.status == 1) {
      //console.log(posts.data)
      this.topicList = posts.data;
      //this.onChange("T");
    }
    else {
      (<HTMLInputElement>document.getElementById("errorMsg")).style.display = 'block';
      (<HTMLInputElement>document.getElementById("errorMsg")).innerHTML = posts.status;
    }
  });
}


}


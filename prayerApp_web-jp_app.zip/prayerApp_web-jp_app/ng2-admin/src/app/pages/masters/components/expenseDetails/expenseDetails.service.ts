import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';
import { HttpModule } from '@angular/http';
import { Headers, Response, URLSearchParams } from '@angular/http';
import * as MasterConstants from '../../../masterconstants'; 
import {NgbDateStruct, NgbCalendar, NgbCalendarIslamicCivil, NgbDatepickerI18n} from '@ng-bootstrap/ng-bootstrap';

@Injectable()
export class ExpenseDetailsService {
private today: NgbDateStruct;

  constructor(private http: Http,calendar: NgbCalendar) {
    //console.log('initialized');
     this.today = calendar.getToday();
     //console.log("today date");
     //console.log(this.today);
  }

  userGroupAccess(moduleName){
    var headers = new Headers();
    headers.append('Content-Type', 'application/x-www-form-urlencoded');
    let urlSearchParams = new URLSearchParams();
    urlSearchParams.append('moduleName', moduleName);
    urlSearchParams.append('userTO', localStorage.getItem('currentUser'));
    let body = urlSearchParams.toString(); 
    return this.http.post(MasterConstants.WEB_URL + 'userGroupAccess', body, {headers: headers}).map(res => res.json());
  
   }

   getBranchDetails() {
    
    var headers = new Headers();
    headers.append('Content-Type', 'application/x-www-form-urlencoded');
    let urlSearchParams = new URLSearchParams();
    urlSearchParams.append('userTO', localStorage.getItem('currentUser'));
    urlSearchParams.append('groupName', JSON.parse(localStorage.getItem('currentUser')).groupName);
    urlSearchParams.append('userId', JSON.parse(localStorage.getItem('currentUser')).userId);
    let body = urlSearchParams.toString();
    return this.http.post(MasterConstants.WEB_URL + '/getSalesDealerBranch', body, {
        headers: headers
    }).map(res => res.json());

}

   getPosts_expenseDetails() {
    
     var headers = new Headers();
     headers.append('Content-Type', 'application/x-www-form-urlencoded');
     let urlSearchParams = new URLSearchParams();
     urlSearchParams.append('userTO', localStorage.getItem('currentUser'));
     urlSearchParams.append('groupName', JSON.parse(localStorage.getItem('currentUser')).groupName);
     urlSearchParams.append('userId', JSON.parse(localStorage.getItem('currentUser')).userId);
     let body = urlSearchParams.toString();
     return this.http.post(MasterConstants.WEB_URL + '/listOfExpenseDetails', body, {
         headers: headers
     }).map(res => res.json());

 }
 
//  listOfExpenseDetailsDtl(expenseDetailsId){
//     var headers = new Headers();
//     headers.append('Content-Type', 'application/x-www-form-urlencoded');
//     let urlSearchParams = new URLSearchParams();
//     urlSearchParams.append('userTO', localStorage.getItem('currentUser'));
//     urlSearchParams.append('expenseDetailsId', expenseDetailsId);
//     let body = urlSearchParams.toString();
//     return this.http.post(MasterConstants.WEB_URL + '/listOfExpenseDetailsDtl', body, {
//         headers: headers
//     }).map(res => res.json());
//  }
 searchExpenseDetails(fromDate,toDate,status,username,branch,searchFormValue) {
  
          var headers = new Headers();
          headers.append('Content-Type', 'application/x-www-form-urlencoded');
          let urlSearchParams = new URLSearchParams();

          let searchflag="";
// || (filterLoginType != null &&  filterLoginType != '')|| (fromDate != null && fromDate != '')||  (toDate != null &&  toDate!= '')
    if((username!=null && username !='')||(status != null && status != '')||(searchFormValue != null && searchFormValue != '')){
        searchflag ="Y";
      }
      else{
        
      }
         
          urlSearchParams.append('fromDate', fromDate);
          urlSearchParams.append('toDate', toDate);
          urlSearchParams.append('searchFlag',searchflag);
          urlSearchParams.append('status', status);
          urlSearchParams.append('userBy', username);
          urlSearchParams.append('branch', branch);
          urlSearchParams.append('showValue', searchFormValue);
          urlSearchParams.append('showRelatedValue', JSON.parse(localStorage.getItem('currentUser')).userId);
          urlSearchParams.append('groupName', JSON.parse(localStorage.getItem('currentUser')).groupName);
          urlSearchParams.append('userId', JSON.parse(localStorage.getItem('currentUser')).userId);
          
          urlSearchParams.append('userTO', localStorage.getItem('currentUser'));
          let body = urlSearchParams.toString(); 
          return this.http.post(MasterConstants.WEB_URL + 'listOfExpenseDetails', body, {headers: headers}).map(res => res.json());
  
      }
 submit1(

 expenseCreationDtlId,
 expenseCreationNo,
  date,
  expName,
  empNo,
  employeeName,
  visitPlanNo,
  visitPlanDate,
  dealerDistributor,
  state,
  city,
  transport,
  conSlabAmt,
  conClaimActual,
  conSpecialApproval,
  conveyanceRemark,
  conProofOfDocument,
  conApprovedAmtByBm,
  conApprovedAmtByRsm,
  conApprovedAmtByDgmGm,
  conApprovedAmtByGm,
  conApprovedAmtByDirectors,
  conApprovedAmtByFinance,

  boardingSlabAmt,
  boardingClaimActual,
  boardingSpecialApproval,
  boardingRemark,
  boardingProofOfDocument,
  boardingApprovedAmtByBm,
  boardingApprovedAmtByRsm,
  boardingApprovedAmtByDgmGm,
  boardingApprovedAmtByGm,
  boardingApprovedAmtByDirectors,
  boardingApprovedAmtByFinance,

  allowanceSlabAmt,
  allowanceClaimActual,
  allowanceSpecialApproval,
  allowanceRemark,
  allowanceProofOfDocument,
  allowanceApprovedAmtByBm,
  allowanceApprovedAmtByRsm,
  allowanceApprovedAmtByDgmGm,
  allowanceApprovedAmtByGm,
  allowanceApprovedAmtByDirectors,
  allowanceApprovedAmtByFinance,
//   totalSlabAmt,
//   totalClaimAmt,
//   finalApprovedAmt,
//   status,
//   branch,

 expenseDetailsFnMode,
  createdDt,
  createdBy,
  status,

//   time
//   updatedDt,
//   updatedBy,
  
            
          ) {
                //console.log("inside service page");
                //console.log(this.today.year+":"+this.today.month+":"+this.today.day);
                let params = '?'; 
                var headers = new Headers();
                headers.append('Content-Type', 'application/x-www-form-urlencoded');
                let urlSearchParams = new URLSearchParams();
                urlSearchParams.append('expenseCreationDtlId',expenseCreationDtlId);
                urlSearchParams.append('expenseCreationNo',expenseCreationNo);                
                urlSearchParams.append('date',date);
                 urlSearchParams.append('expName',expName);
                urlSearchParams.append('empNo',empNo);
                urlSearchParams.append('employeeName',employeeName);
                urlSearchParams.append('visitPlanNo',visitPlanNo); 
                 urlSearchParams.append('visitPlanDate',visitPlanDate); 
                urlSearchParams.append('dealerDistributor',dealerDistributor); 
                urlSearchParams.append('state',state); 
                urlSearchParams.append('city',city); 
                urlSearchParams.append('transport',transport); 
                urlSearchParams.append('conSlabAmt',conSlabAmt); 
                urlSearchParams.append('conClaimActual',conClaimActual); 
                urlSearchParams.append('conSpecialApproval',conSpecialApproval); 
                urlSearchParams.append('conveyanceRemark',conveyanceRemark); 
                urlSearchParams.append('conProofOfDocument',conProofOfDocument); 
                urlSearchParams.append('conApprovedAmtByBm',conApprovedAmtByBm); 
                urlSearchParams.append('conApprovedAmtByRsm',conApprovedAmtByRsm); 
                urlSearchParams.append('conApprovedAmtByDgmGm',conApprovedAmtByDgmGm); 
                urlSearchParams.append('conApprovedAmtByGm',conApprovedAmtByGm); 
                urlSearchParams.append('conApprovedAmtByDirectors',conApprovedAmtByDirectors); 
                urlSearchParams.append('conApprovedAmtByFinance',conApprovedAmtByFinance); 

                urlSearchParams.append('boardingSlabAmt',boardingSlabAmt); 
                urlSearchParams.append('boardingClaimActual',boardingClaimActual); 
                urlSearchParams.append('boardingSpecialApproval',boardingSpecialApproval); 
                urlSearchParams.append('boardingRemark',boardingRemark); 
                urlSearchParams.append('boardingProofOfDocument',boardingProofOfDocument); 
                urlSearchParams.append('boardingApprovedAmtByBm',boardingApprovedAmtByBm); 
                urlSearchParams.append('boardingApprovedAmtByRsm',boardingApprovedAmtByRsm); 
                urlSearchParams.append('boardingApprovedAmtByDgmGm',boardingApprovedAmtByDgmGm); 
                urlSearchParams.append('boardingApprovedAmtByGm',boardingApprovedAmtByGm);
                urlSearchParams.append('boardingApprovedAmtByDirectors',boardingApprovedAmtByDirectors); 
                urlSearchParams.append('boardingApprovedAmtByFinance',boardingApprovedAmtByFinance); 

                urlSearchParams.append('allowanceSlabAmt',allowanceSlabAmt); 
                urlSearchParams.append('allowanceClaimActual',allowanceClaimActual); 
                urlSearchParams.append('allowanceSpecialApproval',allowanceSpecialApproval); 
                urlSearchParams.append('allowanceRemark',allowanceRemark); 
                urlSearchParams.append('allowanceProofOfDocument',allowanceProofOfDocument); 
                urlSearchParams.append('allowanceApprovedAmtByBm',allowanceApprovedAmtByBm); 
                urlSearchParams.append('allowanceApprovedAmtByRsm',allowanceApprovedAmtByRsm); 
                urlSearchParams.append('allowanceApprovedAmtByDgmGm',allowanceApprovedAmtByDgmGm); 
                urlSearchParams.append('allowanceApprovedAmtByGm',allowanceApprovedAmtByGm); 
                urlSearchParams.append('allowanceApprovedAmtByDirectors',allowanceApprovedAmtByDirectors); 
                urlSearchParams.append('allowanceApprovedAmtByFinance',allowanceApprovedAmtByFinance); 

                // urlSearchParams.append('totalSlabAmt',totalSlabAmt); 
                // urlSearchParams.append('totalClaimAmt',totalClaimAmt); 
                // urlSearchParams.append('finalApprovedAmt',finalApprovedAmt); 
                urlSearchParams.append('status',status); 
                // urlSearchParams.append('branch',branch); 


                urlSearchParams.append('expenseDetailsFnMode',expenseDetailsFnMode);
                urlSearchParams.append('createdDt',createdDt);
                urlSearchParams.append('createdBy',createdBy);
                // urlSearchParams.append('time',time);
                
                urlSearchParams.append('userTO',localStorage.getItem('currentUser'));
                // urlSearchParams.append('createdDt',this.today.year+"/"+this.today.month+"/"+this.today.day); 
                console.log(localStorage.getItem('currentUser'));
          
                let body = urlSearchParams.toString(); 
                   
            return this.http.post(MasterConstants.WEB_URL +'saveOrUpdateExpenseDetailsInfo',body,{headers: headers}).map(res => res.json());            
 }


exportExpenseDetailsXL(fromDate,toDate,status,username,branch,searchFormValue) {
    var headers = new Headers();
    headers.append('Content-Type', 'application/x-www-form-urlencoded');
    let urlSearchParams = new URLSearchParams();
     
    urlSearchParams.append('fromDate', fromDate);
    urlSearchParams.append('toDate', toDate);
    urlSearchParams.append('status', status);
    urlSearchParams.append('userBy', username);
    urlSearchParams.append('branch', branch);
    urlSearchParams.append('showValue', searchFormValue);
    urlSearchParams.append('showRelatedValue', JSON.parse(localStorage.getItem('currentUser')).userId);
    urlSearchParams.append('generateURL','true');
    urlSearchParams.append('usrId', JSON.parse(localStorage.getItem('currentUser')).usrId);
    urlSearchParams.append('userId', JSON.parse(localStorage.getItem('currentUser')).userId);
    urlSearchParams.append('locationId', JSON.parse(localStorage.getItem('currentUser')).locationId);
    urlSearchParams.append('locName', JSON.parse(localStorage.getItem('currentUser')).locName);
    urlSearchParams.append('orgId', JSON.parse(localStorage.getItem('currentUser')).orgId);
    //urlSearchParams.append('userTO', localStorage.getItem('currentUser'));
    let body = urlSearchParams.toString();
    
    return this.http.post(MasterConstants.WEB_URL + 'exportExpenseDetailsXL', body, {headers: headers}).map(res => res);
  
  }
  exportExpenseDetailsXLUser(fromDate,toDate,status,username,branch,searchFormValue,searchExpenseNo) {
    var headers = new Headers();
    headers.append('Content-Type', 'application/x-www-form-urlencoded');
    let urlSearchParams = new URLSearchParams();
     
    urlSearchParams.append('fromDate', fromDate);
    urlSearchParams.append('toDate', toDate);
    urlSearchParams.append('status', status);
    urlSearchParams.append('userBy', username);
    urlSearchParams.append('branch', branch);
    urlSearchParams.append('showValue', searchFormValue);
    urlSearchParams.append('searchExpenseNo', searchExpenseNo);
    urlSearchParams.append('showRelatedValue', JSON.parse(localStorage.getItem('currentUser')).userId);
    urlSearchParams.append('generateURL','true');
    urlSearchParams.append('usrId', JSON.parse(localStorage.getItem('currentUser')).usrId);
    urlSearchParams.append('userId', JSON.parse(localStorage.getItem('currentUser')).userId);
    urlSearchParams.append('locationId', JSON.parse(localStorage.getItem('currentUser')).locationId);
    urlSearchParams.append('locName', JSON.parse(localStorage.getItem('currentUser')).locName);
    urlSearchParams.append('orgId', JSON.parse(localStorage.getItem('currentUser')).orgId);
    //urlSearchParams.append('userTO', localStorage.getItem('currentUser'));
    let body = urlSearchParams.toString();
    
    return this.http.post(MasterConstants.WEB_URL + 'exportExpenseDetailsXLDaily', body, {headers: headers}).map(res => res);
  
  }

  exportPDF(fromDate,toDate,status,username,branch,searchFormValue,searchExpenseNo) {
    var headers = new Headers();
    headers.append('Content-Type', 'application/x-www-form-urlencoded');
    let urlSearchParams = new URLSearchParams();
     
    urlSearchParams.append('fromDate', fromDate);
    urlSearchParams.append('toDate', toDate);
    urlSearchParams.append('status', status);
    urlSearchParams.append('userBy', username);
    urlSearchParams.append('branch', branch);
    urlSearchParams.append('showValue', searchFormValue);
    urlSearchParams.append('searchExpenseNo', searchExpenseNo);
    urlSearchParams.append('showRelatedValue', JSON.parse(localStorage.getItem('currentUser')).userId);
    urlSearchParams.append('generateURL','true');
    urlSearchParams.append('usrId', JSON.parse(localStorage.getItem('currentUser')).usrId);
    urlSearchParams.append('userId', JSON.parse(localStorage.getItem('currentUser')).userId);
    urlSearchParams.append('locationId', JSON.parse(localStorage.getItem('currentUser')).locationId);
    urlSearchParams.append('locName', JSON.parse(localStorage.getItem('currentUser')).locName);
    urlSearchParams.append('orgId', JSON.parse(localStorage.getItem('currentUser')).orgId);
    //urlSearchParams.append('userTO', localStorage.getItem('currentUser'));
    let body = urlSearchParams.toString();
    
    return this.http.post(MasterConstants.WEB_URL + 'exportExpenseDetailsPDF', body, {headers: headers}).map(res => res);
  
  }

  getExpenseDetailsDealerListCombo(state,district){
    var headers = new Headers();
    headers.append('Content-Type', 'application/x-www-form-urlencoded');
    let urlSearchParams = new URLSearchParams();
    urlSearchParams.append('userTO', localStorage.getItem('currentUser'));
    urlSearchParams.append('state',state);
    urlSearchParams.append('district',district);
    let body = urlSearchParams.toString(); 
    return this.http.post(MasterConstants.WEB_URL + '/getDealerListCombo', body, {headers: headers
                         }).map(res => res.json()); 
  }

  getSalespersonregistrationNameCombo(){ 
    var headers = new Headers();
    headers.append('Content-Type', 'application/x-www-form-urlencoded');
    let urlSearchParams = new URLSearchParams();
    urlSearchParams.append('userTO', localStorage.getItem('currentUser'));
    let body = urlSearchParams.toString(); 
     return this.http.post(MasterConstants.WEB_URL + 'getSalespersonregistrationNameCombo', body, {headers: headers}).map(res => res.json());
    }
    getSalesAdminAccessEmpID(){ 
        var headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let urlSearchParams = new URLSearchParams();
        urlSearchParams.append('userTO', localStorage.getItem('currentUser'));
        let body = urlSearchParams.toString(); 
         return this.http.post(MasterConstants.WEB_URL + 'getSalesAdminAccessEmpID', body, {headers: headers}).map(res => res.json());
        }
        getExpenseDtlLastUpdateCheck(eDtlId,updatedBy,empId) {
    
            var headers = new Headers();
            headers.append('Content-Type', 'application/x-www-form-urlencoded');
            let urlSearchParams = new URLSearchParams();
            urlSearchParams.append('EDtlId',eDtlId);
            urlSearchParams.append('UpdatedBy', updatedBy);
            urlSearchParams.append('empId',empId);
            let body = urlSearchParams.toString();
            return this.http.post(MasterConstants.WEB_URL + '/getExpenseDtlLastUpdateCheck', body, {
                headers: headers
            }).map(res => res.json());
        
        }

}

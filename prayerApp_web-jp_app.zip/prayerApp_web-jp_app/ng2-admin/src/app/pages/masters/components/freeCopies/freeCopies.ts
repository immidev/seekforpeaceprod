import { Component, OnInit, Inject, ElementRef, AfterViewInit, group } from '@angular/core';
import { NgbModal, NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { LocalDataSource } from 'ng2-smart-table';
import { HttpModule } from '@angular/http';
import { Typeahead } from 'ng2-typeahead-master';
import { FormGroup, AbstractControl, FormBuilder, Validators } from '@angular/forms';


import { Observable } from 'rxjs/Observable';
import { ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { MastersService } from '../../masters.service';
//declare var google: any;
declare var System: any;
declare var googleTranslateElementInit: any;
import './googletranslate.js';
import { UserUpdateProfileService } from '../../../../../../src/app/pages/masters/components/updateProfile/updateProfile.service';
import { UserFreeCopiesService } from './freeCopies.service';
declare var swal: any;  //For Sweet Alert

@Component({
  selector: 'freeCopies',
  styleUrls: ['./freeCopies.scss'],
  //scripts : [],
  templateUrl: './freeCopies.html',
})
export class FreeCopies {

  // @ViewChild('firstName1') firstName1: ElementRef;
  // @ViewChild('lastname') lastname: ElementRef;
  // @ViewChild('mobileNumber') mobileNumber: ElementRef;
  // @ViewChild('landLine') landLine: ElementRef; 
  // @ViewChild('zip') zip: ElementRef; 
  // @ViewChild('state') state: ElementRef; 
  // @ViewChild('address') address: ElementRef; 
  // @ViewChild('nativeLanguage') nativeLanguage: ElementRef; 
  // @ViewChild('country') country: ElementRef; 
  // @ViewChild('emailid') emailid: ElementRef; 



  topicList;
  radioValue = 'T';
  BList;
  CList;
  public form: FormGroup;
  public email: AbstractControl;
  public password: AbstractControl;
  public submitted: boolean = false;
  dob: string;
  firstName;
  lastname;
  mobileNumber;
  landLine;
  nativeLanguage;
  address;
  state;
  zip;
  country;

  emailid;

CountryList;




  books_array = ['Torah (Old Testament Part 1)', 'The Prophets- Ancient (Old Testament Part 2)', 'Writings (Old Testament Part 3)',
  'Old Testament (Parts 1- 2- and 3)',
  'New Testament of Jesus Christ',
  'Another Testament of Jesus Christ (Book of Mormon)',
  'The Prophets- Modern']
  constructor(fb: FormBuilder, private Service: MastersService, private Service12: UserUpdateProfileService, private Service1: UserFreeCopiesService, private router: Router) {
   
         (<HTMLInputElement>document.getElementById('TopicHeader')).style.display = 'none';
    (<HTMLInputElement>document.getElementById('WholeHeader')).style.display = 'none';
    
    (<HTMLInputElement>document.getElementById('search')).style.display = 'none';
    (<HTMLInputElement>document.getElementById('seekPeace')).style.display = 'none';

    (<HTMLInputElement> document.getElementById('header_two')).style.display = 'none';

     (<HTMLInputElement>document.getElementById('beliefStatementHeader')).style.display = 'none';
     (<HTMLInputElement>document.getElementById('beliefStatementHeader1')).style.display = 'none';
     (<HTMLInputElement>document.getElementById('entry')).style.display = 'none';
     (<HTMLInputElement>document.getElementById('beliefState')).style.display = 'none';
     (<HTMLInputElement>document.getElementById('topicDes')).style.display = 'none';

    this.form = fb.group({
      'email': ['', Validators.compose([Validators.required, Validators.minLength(1)])],
      'password': ['', Validators.compose([Validators.required, Validators.minLength(1)])],
    });

    // this.email = this.form.controls['email'];
    // this.password = this.form.controls['password'];
    this.Service12.getProfileDetails().subscribe(posts => {
      if (posts.status == 1) {
        console.log(posts.data)
        this.firstName = posts.data[0].name;
        this.lastname = posts.data[0].lastname;
        this.mobileNumber = posts.data[0].Mobile;
        this.landLine = posts.data[0].Landline;
        this.nativeLanguage = posts.data[0].NativeLanguage;
        this.dob = posts.data[0].DOB;
        this.address = posts.data[0].Address;
        this.country = posts.data[0].Country;
        this.state = posts.data[0].State;
        this.zip = posts.data[0].Zip;
        this.emailid = posts.data[0].emailid;
        
        //this.onChange("T");
      }


      else {
        (<HTMLInputElement>document.getElementById("errorMsg")).style.display = 'block';
        (<HTMLInputElement>document.getElementById("errorMsg")).innerHTML = posts.status;
      }
    });



    this.Service12.getCountryList().subscribe(posts => {
      if (posts.status == 1) {
        console.log(posts.data)
        this.CountryList = posts.data;
        //this.onChange("T");
      }

      
      else {
        (<HTMLInputElement>document.getElementById("errorMsg")).style.display = 'block';
        (<HTMLInputElement>document.getElementById("errorMsg")).innerHTML = posts.status;
      }
    });



  }




  box(event, value) {

    if (event.target.checked) {
      this.books_array.push(value)
      console.log(this.books_array)
    }
    else {
      let i = this.books_array.findIndex(x => x == value);
      if (i > -1) {
        this.books_array.splice(i, 1)
        console.log(this.books_array);

      }
    }
  }
  message_text;
  requestCopies(){
    
    this.Service1.requestCopies(

        this.firstName     ,
        this.lastname     ,
        this.mobileNumber  ,
        this.landLine     ,
        this.nativeLanguage,
        this.dob           ,
        this.address      ,
        this.country      ,
        this.state       ,
        this.zip         ,
        this.emailid       ,
        this.message_text,
        this.books_array,
    ).subscribe(posts => {
      if(posts.status == 1){
        //swal("")

        swal({ title: "Success!", text:posts.msg, type: 'success',});
      }
      else{
        swal({ title: "Warning!", text:posts.msg, type: 'warning',});

      }
    });
  }

}


import { Component, OnInit, Inject, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { LocalDataSource } from 'ng2-smart-table';

import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ExpenseDetailsService } from 'app/pages/masters/components/expenseDetails/expenseDetails.service';
import { Observable } from 'rxjs/Observable';
import { ExpenseDetailsListV } from 'app/pages/masters/components/expenseDetails/expenseDetailslistv.componenet';
import { Headers, Response, URLSearchParams } from '@angular/http';
import * as Handsontable from 'handsontable/dist/handsontable.full.js';

@Component({
  selector: 'expenseDetailsInfoVW',
  templateUrl: './expenseDetailsInfoVW.html',
  styleUrls: ['./expenseDetails.scss'],
})


export class ExpenseDetailsInfoVW  implements OnInit {
  @ViewChild(ExpenseDetailsListV) a: ExpenseDetailsListV;
  
  @ViewChild('expenseCreationDtlId') expenseCreationDtlId: ElementRef;
     @ViewChild('expenseCreationNo') expenseCreationNo: ElementRef;
     @ViewChild('date') date: ElementRef;
     @ViewChild('expName') expName: ElementRef;
     @ViewChild('empNo') empNo: ElementRef;
     @ViewChild('employeeName') employeeName: ElementRef;
     @ViewChild('visitPlanNo') visitPlanNo: ElementRef;
      @ViewChild('visitPlanDate') visitPlanDate: ElementRef;
     @ViewChild('dealerDistributor') dealerDistributor: ElementRef;
     @ViewChild('state') state: ElementRef;
     @ViewChild('city') city: ElementRef;
     @ViewChild('transport') transport: ElementRef;
     @ViewChild('conSlabAmt') conSlabAmt: ElementRef;
     @ViewChild('conClaimActual') conClaimActual: ElementRef;
     @ViewChild('conSpecialApproval') conSpecialApproval: ElementRef;
     @ViewChild('conveyanceRemark') conveyanceRemark: ElementRef;
     @ViewChild('conProofOfDocument') conProofOfDocument: ElementRef;
     @ViewChild('conApprovedAmtByBm') conApprovedAmtByBm: ElementRef;
     @ViewChild('conApprovedAmtByRsm') conApprovedAmtByRsm: ElementRef;
     @ViewChild('conApprovedAmtByDgmGm') conApprovedAmtByDgmGm: ElementRef;
     @ViewChild('conApprovedAmtByGm') conApprovedAmtByGm: ElementRef;
     @ViewChild('conApprovedAmtByDirectors') conApprovedAmtByDirectors: ElementRef;
     @ViewChild('conApprovedAmtByFinance') conApprovedAmtByFinance: ElementRef;
     @ViewChild('boardingSlabAmt') boardingSlabAmt: ElementRef;
     @ViewChild('boardingClaimActual') boardingClaimActual: ElementRef;
     @ViewChild('boardingSpecialApproval') boardingSpecialApproval: ElementRef;
     @ViewChild('boardingRemark') boardingRemark: ElementRef;
     @ViewChild('boardingProofOfDocument') boardingProofOfDocument: ElementRef;
     @ViewChild('boardingApprovedAmtByBm') boardingApprovedAmtByBm: ElementRef;
     @ViewChild('boardingApprovedAmtByRsm') boardingApprovedAmtByRsm: ElementRef;
     @ViewChild('boardingApprovedAmtByDgmGm') boardingApprovedAmtByDgmGm: ElementRef;
     @ViewChild('boardingApprovedAmtByGm') boardingApprovedAmtByGm: ElementRef;
     @ViewChild('boardingApprovedAmtByDirectors') boardingApprovedAmtByDirectors: ElementRef;
     @ViewChild('boardingApprovedAmtByFinance') boardingApprovedAmtByFinance: ElementRef;

     @ViewChild('allowanceSlabAmt') allowanceSlabAmt: ElementRef;
     @ViewChild('allowanceClaimActual') allowanceClaimActual: ElementRef;
     @ViewChild('allowanceSpecialApproval') allowanceSpecialApproval: ElementRef;
     @ViewChild('allowanceRemark') allowanceRemark: ElementRef;
     @ViewChild('allowanceProofOfDocument') allowanceProofOfDocument: ElementRef;
     @ViewChild('allowanceApprovedAmtByBm') allowanceApprovedAmtByBm: ElementRef;
     @ViewChild('allowanceApprovedAmtByRsm') allowanceApprovedAmtByRsm: ElementRef;
     @ViewChild('allowanceApprovedAmtByDgmGm') allowanceApprovedAmtByDgmGm: ElementRef;
     @ViewChild('allowanceApprovedAmtByGm') allowanceApprovedAmtByGm: ElementRef;
     @ViewChild('allowanceApprovedAmtByDirectors') allowanceApprovedAmtByDirectors: ElementRef;
     @ViewChild('allowanceApprovedAmtByFinance') allowanceApprovedAmtByFinance: ElementRef;
     @ViewChild('totalSlabAmt') totalSlabAmt: ElementRef;
     @ViewChild('totalClaimAmt') totalClaimAmt: ElementRef;
     @ViewChild('finalApprovedAmt') finalApprovedAmt: ElementRef;
     @ViewChild('status') status: ElementRef;
     @ViewChild('branch') branch: ElementRef;
     @ViewChild('subject') subject: ElementRef;


     @ViewChild('expenseDetailsFnMode') expenseDetailsFnMode: ElementRef;
     @ViewChild('createdDt') createdDt: ElementRef;
     @ViewChild('createdBy') createdBy: ElementRef;
    //  @ViewChild('updatedDt') updatedDt: ElementRef;
    //  @ViewChild('updatedBy') updatedBy: ElementRef;   
      @ViewChild('locationId') locationId: ElementRef;
      @ViewChild('locationName') locationName: ElementRef;
      @ViewChild('active') active: ElementRef;
      @ViewChild('conveyanceFlagId') conveyanceFlagId: ElementRef;
      @ViewChild('boardingFlagId') boardingFlagId: ElementRef;
      @ViewChild('allowanceFlageId') allowanceFlageId: ElementRef;
      @ViewChild('fsModal') fsModal: ElementRef;
      @ViewChild('fsModal1') fsModal1: ElementRef;
      @ViewChild('fsModal2') fsModal2: ElementRef;
      @ViewChild('cPath') cPath: ElementRef;  
      @ViewChild('blPath') blPath: ElementRef; 
      @ViewChild('aPath') aPath: ElementRef; 
      @ViewChild('totalCheckExpenseTypes') totalCheckExpenseTypes: ElementRef; 
      

 public model: any;
 currentJustify = 'start';

   source: LocalDataSource = new LocalDataSource();

   stateCombo;
   conveyanceFlag=true;  
   boardingFlag=true;  
   allowanceFlag=true;

   editReadOnly: boolean =  true;
   data:Array<any>;
   value_c_path;
   value_bl_path
   value_a_path
// myCustomRenderer;
// colHeaders:Array<string>;
// columns:Array<any>;
// options:any;
// colWidths: Array<number> = [200, 120, 120, 120,200, 150,150];

  constructor(private activeModal: NgbActiveModal, protected service: ExpenseDetailsService) {
    this.service.getPosts_expenseDetails().subscribe(posts => { 
        });
        console.log("{{{{{{{{{{{{{{{");
        setTimeout(()=>{
         
          if(this.conveyanceFlagId.nativeElement.value=="true"){
            this.conveyanceFlag = false;
          }
          if(this.boardingFlagId.nativeElement.value=="true"){
            this.boardingFlag =false;
          }
          if(this.allowanceFlageId.nativeElement.value=="true"){
            this.allowanceFlag =false;
          }
          console.log("++++++++++++++++"+this.cPath.nativeElement.value);
          if(this.cPath.nativeElement.value!=null && this.cPath.nativeElement.value!=""){
            let val=this.cPath.nativeElement.value;
            
            val = val.replace("unsafe:","");
            console.log(val);
              this.value_c_path=val.substr(1).split(',');
              console.log(this.value_c_path);
          }
          if(this.blPath.nativeElement.value!=null && this.blPath.nativeElement.value!=""){
            let val=this.blPath.nativeElement.value;
            val = val.replace("unsafe:","");
            this.value_bl_path=val.substr(1).split(',');
            console.log(this.blPath);
        }
        if(this.aPath.nativeElement.value!=null && this.aPath.nativeElement.value!=""){
          let val=this.aPath.nativeElement.value;
          val = val.replace("unsafe:","");
          this.value_a_path=val.substr(1).split(',');
          console.log(this.blPath);
      }          
        },2000);
     
        console.log("}}}}}}}}}}}}}}}");
      }
     

  ngOnInit() {}

  closeModal() {
      this.activeModal.close();    
  
      localStorage.removeItem('mode');
      localStorage.removeItem('GridValue');
      localStorage.removeItem("expenseDetailsDtlInfo");
      (<HTMLInputElement> document.getElementById('resetMethod1')).click();
  }



  submit1() { //S_D_I submit db insert 
      let statusVal="";
      if(JSON.parse(localStorage.getItem('currentUser')).groupName==""){
        statusVal="Completed";
      }
      else{
        statusVal = "Approved by "+JSON.parse(localStorage.getItem('currentUser')).groupName
      }
      

console.log(this.totalCheckExpenseTypes.nativeElement.value);

console.log(this.status.nativeElement.value);

var groupName= JSON.parse(localStorage.getItem('currentUser')).groupName;
let approve_flag=this.approvalCheck(this.status.nativeElement.value,groupName,this.totalCheckExpenseTypes.nativeElement.value);
console.log(approve_flag.length);
if(approve_flag[0]==false){
  alert("Kindly approve all required expenses");
}
else if(approve_flag[1]==false){
  alert("Approved amount must be less than the previous level approved & claim amount");
}
else{
 this.service.submit1(
    this.expenseCreationDtlId.nativeElement.value,
    this.expenseCreationNo.nativeElement.value,
    this.date.nativeElement.value,
    this.expName.nativeElement.value,
    this.empNo.nativeElement.value, 
    this.employeeName.nativeElement.value,   
    this.visitPlanNo.nativeElement.value,   
     this.visitPlanDate.nativeElement.value,   
    this.dealerDistributor.nativeElement.value,   
    this.state.nativeElement.value,   
    this.city.nativeElement.value,   
    this.transport.nativeElement.value,   
    this.conSlabAmt.nativeElement.value,   
    this.conClaimActual.nativeElement.value,   
    this.conSpecialApproval.nativeElement.value,   
    this.conveyanceRemark.nativeElement.value,   
   '',   
    this.conApprovedAmtByBm.nativeElement.value,   
    this.conApprovedAmtByRsm.nativeElement.value,   
    this.conApprovedAmtByDgmGm.nativeElement.value,
    this.conApprovedAmtByGm.nativeElement.value,  
    this.conApprovedAmtByDirectors.nativeElement.value,   
    this.conApprovedAmtByFinance.nativeElement.value,                     
    this.boardingSlabAmt.nativeElement.value,   
    this.boardingClaimActual.nativeElement.value,   
    this.boardingSpecialApproval.nativeElement.value,   
    this.boardingRemark.nativeElement.value,   
   '',   
    this.boardingApprovedAmtByBm.nativeElement.value,   
    this.boardingApprovedAmtByRsm.nativeElement.value,   
    this.boardingApprovedAmtByDgmGm.nativeElement.value,  
    this.boardingApprovedAmtByGm.nativeElement.value,  
    this.boardingApprovedAmtByDirectors.nativeElement.value,   
    this.boardingApprovedAmtByFinance.nativeElement.value,  

    this.allowanceSlabAmt.nativeElement.value,   
    this.allowanceClaimActual.nativeElement.value,   
    this.allowanceSpecialApproval.nativeElement.value,   
    this.allowanceRemark.nativeElement.value,   
    '',   
    this.allowanceApprovedAmtByBm.nativeElement.value,   
    this.allowanceApprovedAmtByRsm.nativeElement.value,   
    this.allowanceApprovedAmtByDgmGm.nativeElement.value,  
    this.allowanceApprovedAmtByGm.nativeElement.value,  
    this.allowanceApprovedAmtByDirectors.nativeElement.value,   
    this.allowanceApprovedAmtByFinance.nativeElement.value,  
    // this.totalSlabAmt.nativeElement.value,  
    // this.totalClaimAmt.nativeElement.value,  
    // this.finalApprovedAmt.nativeElement.value,  
    // this.status.nativeElement.value,  
    // this.branch.nativeElement.value,  


    this.expenseDetailsFnMode.nativeElement.value,  
    this.createdDt.nativeElement.value,
    this.createdBy.nativeElement.value,
    statusVal,
  ).subscribe(posts => {//Post Insert value
    this.closeModal()
  }); 
}

       
   
      }


      approvalCheck(status,group,type){
        let val=[] ;
            let status_array =type.split(",");
            if(status_array.length>0){
              console.log(status_array);
              console.log(status_array.length);
              for(let i=0;i<status_array.length;i++){
                console.log("entering inside the for:"+i);
                  if(status_array[i]=='Conveyance'){
                      if(group=="BRANCH MANAGER" || group=="BM"){
                        if(this.conApprovedAmtByBm.nativeElement.value=='' || this.conApprovedAmtByBm.nativeElement.value==null){
                          val[0]=false;
                          break;
                          
                        }
                        else{
                          if(this.conSpecialApproval.nativeElement.value=='false'){                        
                          if(parseInt(this.conApprovedAmtByBm.nativeElement.value)>parseInt(this.conClaimActual.nativeElement.value)){
                            val[1]=false;
                            break;
                          }
                          }
                        }
                      }
                      if(group=="RSM"){
                        if(this.conApprovedAmtByRsm.nativeElement.value=='' || this.conApprovedAmtByRsm.nativeElement.value==null){
                          val[0]=false;
                          break;
                          
                        }
                        else{
                          console.log("testing");
                          if(this.conApprovedAmtByBm.nativeElement.value==''||this.conApprovedAmtByBm.nativeElement.value==null){
                            if(this.conSpecialApproval.nativeElement.value=='false'){
                              console.log("testing1");
                              if(parseInt(this.conApprovedAmtByRsm.nativeElement.value)>parseInt(this.conApprovedAmtByBm.nativeElement.value)){
                                console.log("testing2");
                                val[1]=false;
                                break;
                              }
                            }
                          }
                          else{
                            console.log("testing3");
                            if(parseInt(this.conApprovedAmtByRsm.nativeElement.value)>parseInt(this.conApprovedAmtByBm.nativeElement.value)){
                              val[1]=false;
                              break;
                            }
                          }
                         
                        }

                      }
                      if(group=="DEPUTY GENERAL MANAGER"){
                        if(this.conApprovedAmtByDgmGm.nativeElement.value=='' || this.conApprovedAmtByRsm.nativeElement.value==null){
                          val[0]=false;
                          break;
                          
                        }
                        else{
                          if(this.conApprovedAmtByBm.nativeElement.value==''||this.conApprovedAmtByBm.nativeElement.value==null){
                            if(this.conSpecialApproval.nativeElement.value=='false'){
                              if(parseInt(this.conApprovedAmtByDgmGm.nativeElement.value)>parseInt(this.conApprovedAmtByBm.nativeElement.value)){
                                val[1]=false;
                                break;
                              }
                            }
                          }
                          else{
                            if(parseInt(this.conApprovedAmtByDgmGm.nativeElement.value)>parseInt(this.conApprovedAmtByBm.nativeElement.value)){
                              val[1]=false;
                              break;
                            }
                          }
                          
                        }
                      }
                      if(group=="GM"){
                        if(this.conApprovedAmtByGm.nativeElement.value=='' || this.conApprovedAmtByGm.nativeElement.value==null){
                          val[0]=false;
                          break;
                          
                        }
                        else{
                          if(this.conApprovedAmtByDgmGm.nativeElement.value!=''){
                            if(parseInt(this.conApprovedAmtByGm.nativeElement.value)>parseInt(this.conApprovedAmtByDgmGm.nativeElement.value)){
                              val[1]=false;
                              break;
                            }
                          }
                          if(this.conApprovedAmtByRsm.nativeElement.value!=''){
                            if(parseInt(this.conApprovedAmtByGm.nativeElement.value)>parseInt(this.conApprovedAmtByRsm.nativeElement.value)){
                              val[1]=false;
                              break;
                            }
                          }
                        }
                      }
                      if(group=="WTD"){
                        if(this.conApprovedAmtByDirectors.nativeElement.value=='' || this.conApprovedAmtByDirectors.nativeElement.value==null){
                          val[0]=false;
                          break;
                          
                        }
                        else{
                          if(this.conApprovedAmtByGm.nativeElement.value!=''){
                            if(parseInt(this.conApprovedAmtByDirectors.nativeElement.value)>parseInt(this.conApprovedAmtByGm.nativeElement.value)){
                              val[1]=false;
                              break;
                            }
                          }
                          /* if(this.conApprovedAmtByRsm.nativeElement.value!=''){
                            if(parseInt(this.conApprovedAmtByDirectors.nativeElement.value)>parseInt(this.conApprovedAmtByRsm.nativeElement.value)){
                              val[1]=false;
                              break;
                            }
                          } */
                        }
                      }
                      if(group=="FINANCE"){
                        if(this.conApprovedAmtByFinance.nativeElement.value=='' || this.conApprovedAmtByFinance.nativeElement.value==null){
                          val[0]=false;
                          break;
                          
                        }
                        else{
                          if(parseInt(this.conApprovedAmtByFinance.nativeElement.value)>parseInt(this.conApprovedAmtByDirectors.nativeElement.value)){
                            val[1]=false;
                            break;
                          }
                        }
                      }
                      
                  }
                  if(status_array[i]=='Boarding'){
                    if(group=="BRANCH MANAGER" || group=="BM"){
                      if(this.boardingApprovedAmtByBm.nativeElement.value=='' || this.boardingApprovedAmtByBm.nativeElement.value==null){
                        val[0]=false;
                        break;
                        
                      }
                      else{
                        if(this.boardingSpecialApproval.nativeElement.value==false){
                        if(parseInt(this.boardingApprovedAmtByBm.nativeElement.value)>parseInt(this.boardingClaimActual.nativeElement.value)){
                          val[1]=false;
                          break;
                        }
                      }
                      }
                    }
                    if(group=="RSM"){
                      
                      if(this.boardingApprovedAmtByRsm.nativeElement.value=='' || this.boardingApprovedAmtByRsm.nativeElement.value==null){
                        val[0]=false;
                        break;
                        
                      } else{
                        if(this.boardingApprovedAmtByBm.nativeElement.value=='' || this.boardingApprovedAmtByBm.nativeElement.value==null){
                          if(this.boardingSpecialApproval.nativeElement.value==false){
                            if(parseInt(this.boardingApprovedAmtByRsm.nativeElement.value)>parseInt(this.boardingApprovedAmtByBm.nativeElement.value)){
                              val[1]=false;
                              break;
                            }
                          }
                        }
                        else{
                          if(parseInt(this.boardingApprovedAmtByRsm.nativeElement.value)>parseInt(this.boardingApprovedAmtByBm.nativeElement.value)){
                            val[1]=false;
                            break;
                          }
                        }
                       
                      }
                      
                    }
                    if(group=="DEPUTY GENERAL MANAGER"){
                      if(this.boardingApprovedAmtByDgmGm.nativeElement.value=='' || this.conApprovedAmtByRsm.nativeElement.value==null){
                        val[0]=false;
                        break;
                        
                      }
                      else{
                        if(this.boardingApprovedAmtByBm.nativeElement.value=='' || this.boardingApprovedAmtByBm.nativeElement.value==null){
                          if(this.boardingSpecialApproval.nativeElement.value==false){
                            if(parseInt(this.boardingApprovedAmtByDgmGm.nativeElement.value)>parseInt(this.boardingApprovedAmtByBm.nativeElement.value)){
                              val[1]=false;
                              break;
                            }
                          }
                        }
                        else{
                          if(parseInt(this.boardingApprovedAmtByDgmGm.nativeElement.value)>parseInt(this.boardingApprovedAmtByBm.nativeElement.value)){
                            val[1]=false;
                            break;
                          }
                        }
                       
                      }
                    }
                    if(group=="GM"){
                      if(this.boardingApprovedAmtByGm.nativeElement.value=='' || this.boardingApprovedAmtByGm.nativeElement.value==null){
                        val[0]=false;
                        break;
                        
                      }
                      else{
                        if(this.boardingApprovedAmtByDgmGm.nativeElement.value!=''){
                          if(parseInt(this.boardingApprovedAmtByGm.nativeElement.value)>parseInt(this.boardingApprovedAmtByDgmGm.nativeElement.value)){
                            val[1]=false;
                            break;
                          }
                        }
                        if(this.boardingApprovedAmtByRsm.nativeElement.value!=''){
                          if(parseInt(this.boardingApprovedAmtByGm.nativeElement.value)>parseInt(this.boardingApprovedAmtByRsm.nativeElement.value)){
                            val[1]=false;
                            break;
                          }
                        }
                      }
                    }
                    if(group=="WTD"){
                      if(this.boardingApprovedAmtByDirectors.nativeElement.value=='' || this.boardingApprovedAmtByDirectors.nativeElement.value==null){
                        val[0]=false;
                        break;
                        
                      }
                      else{
                        if(this.boardingApprovedAmtByGm.nativeElement.value!=''){
                          if(parseInt(this.boardingApprovedAmtByDirectors.nativeElement.value)>parseInt(this.boardingApprovedAmtByGm.nativeElement.value)){
                            val[1]=false;
                            break;
                          }
                        }
                        /* if(this.boardingApprovedAmtByRsm.nativeElement.value!=''){
                          if(parseInt(this.boardingApprovedAmtByDirectors.nativeElement.value)>parseInt(this.boardingApprovedAmtByRsm.nativeElement.value)){
                            val[1]=false;
                            break;
                          }
                        } */
                      }
                    }
                    if(group=="FINANCE"){
                      if(this.boardingApprovedAmtByFinance.nativeElement.value=='' || this.boardingApprovedAmtByFinance.nativeElement.value==null){
                        val[0]=false;
                        break;
                        
                      }
                      else{
                        if(parseInt(this.boardingApprovedAmtByFinance.nativeElement.value)>parseInt(this.boardingApprovedAmtByDirectors.nativeElement.value)){
                          val[1]=false;
                          break;
                        }
                      }
                    }
                  }
                  if(status_array[i]=='Allowance'){
                    if(group=="BRANCH MANAGER" || group=="BM"){
                      if(this.allowanceApprovedAmtByBm.nativeElement.value=='' || this.allowanceApprovedAmtByBm.nativeElement.value==null){
                        val[0]=false;
                        break;
                        
                      } else{
                        if(this.allowanceSpecialApproval.nativeElement.value==false){

                       
                        if(parseInt(this.allowanceApprovedAmtByBm.nativeElement.value)>parseInt(this.allowanceClaimActual.nativeElement.value)){
                          val[1]=false;
                          break;
                        }
                      }
                      }
                    }
                    if(group=="RSM"){
                      console.log("1");
                      if(this.allowanceApprovedAmtByRsm.nativeElement.value=='' || this.allowanceApprovedAmtByRsm.nativeElement.value==null){
                        console.log("2");
                        val[0]=false;
                        break;
                        
                      }
                      else{
                        console.log("3");
                        if(this.allowanceApprovedAmtByBm.nativeElement.value=='' || this.allowanceApprovedAmtByBm.nativeElement.value==null){
                          console.log("4");
                          if(this.allowanceSpecialApproval.nativeElement.value==false){
                            console.log("5");
                            if(parseInt(this.allowanceApprovedAmtByRsm.nativeElement.value)>parseInt(this.allowanceApprovedAmtByBm.nativeElement.value)){
                              console.log("6");
                              val[1]=false;
                              break;
                            }
                          }
                        }
                        else{
                          console.log("7");
                          console.log(parseInt(this.allowanceApprovedAmtByRsm.nativeElement.value));
                          console.log(parseInt(this.allowanceApprovedAmtByBm.nativeElement.value));
                          console.log(parseInt(this.allowanceApprovedAmtByRsm.nativeElement.value)>parseInt(this.allowanceApprovedAmtByBm.nativeElement.value));
                          if(parseInt(this.allowanceApprovedAmtByRsm.nativeElement.value)>parseInt(this.allowanceApprovedAmtByBm.nativeElement.value)){
                            console.log("8");
                            val[1]=false;
                            break;
                          }
                        }
                       
                      }
                    }
                    if(group=="DEPUTY GENERAL MANAGER"){
                      if(this.allowanceApprovedAmtByDgmGm.nativeElement.value=='' || this.conApprovedAmtByRsm.nativeElement.value==null){
                        val[0]=false;
                        break;
                        
                      }
                      else{
                        if(this.allowanceApprovedAmtByBm.nativeElement.value=='' || this.allowanceApprovedAmtByBm.nativeElement.value==null){
                          if(this.allowanceSpecialApproval.nativeElement.value==false){
                            if(this.allowanceApprovedAmtByDgmGm.nativeElement.value>this.allowanceApprovedAmtByBm.nativeElement.value){
                              val[1]=false;
                              break;
                            }
                          }
                        }
                        else{
                          if(parseInt(this.allowanceApprovedAmtByDgmGm.nativeElement.value)>parseInt(this.allowanceApprovedAmtByBm.nativeElement.value)){
                            val[1]=false;
                            break;
                          }
                        }
                        
                      }
                    }
                    if(group=="GM"){
                      if(this.allowanceApprovedAmtByGm.nativeElement.value=='' || this.allowanceApprovedAmtByGm.nativeElement.value==null){
                        val[0]=false;
                        break;
                        
                      }
                      else{
                        if(this.allowanceApprovedAmtByDgmGm.nativeElement.value!=''){
                          if(parseInt(this.allowanceApprovedAmtByGm.nativeElement.value)>parseInt(this.allowanceApprovedAmtByDgmGm.nativeElement.value)){
                            val[1]=false;
                            break;
                          }
                        }
                        if(this.allowanceApprovedAmtByRsm.nativeElement.value!=''){
                          if(parseInt(this.allowanceApprovedAmtByGm.nativeElement.value)>parseInt(this.allowanceApprovedAmtByRsm.nativeElement.value)){
                            val[1]=false;
                            break;
                          }
                        }
                       
                      }
                    }
                    if(group=="WTD"){
                      if(this.allowanceApprovedAmtByDirectors.nativeElement.value=='' || this.allowanceApprovedAmtByDirectors.nativeElement.value==null){
                        val[0]=false;
                        break;
                        
                      }
                      else{
                        if(this.allowanceApprovedAmtByGm.nativeElement.value!=''){
                          if(parseInt(this.allowanceApprovedAmtByDirectors.nativeElement.value)>parseInt(this.allowanceApprovedAmtByGm.nativeElement.value)){
                            val[1]=false;
                            break;
                          }
                        }
                       /*  if(this.allowanceApprovedAmtByRsm.nativeElement.value!=''){
                          if(parseInt(this.allowanceApprovedAmtByDirectors.nativeElement.value)>parseInt(this.allowanceApprovedAmtByRsm.nativeElement.value)){
                            val[1]=false;
                            break;
                          }
                        } */
                       
                      }
                    }
                    if(group=="FINANCE"){
                      if(this.allowanceApprovedAmtByFinance.nativeElement.value=='' || this.allowanceApprovedAmtByFinance.nativeElement.value==null){
                        val[0]=false;
                        break;
                        
                      }
                      else{
                        if(parseInt(this.allowanceApprovedAmtByFinance.nativeElement.value)>parseInt(this.allowanceApprovedAmtByDirectors.nativeElement.value)){
                          val[1]=false;
                          break;
                        }
                      }
                    }
                  }
              }
              console.log("+++++++++++++++");
             // console.log(val);
              return val;
            }
            
      }

      enableValue(value){
        if(value=='view'){
          (<HTMLInputElement> document.getElementById('fsModal')).style.display="block";
        }
        if(value=='close'){
          (<HTMLInputElement> document.getElementById('fsModal')).style.display="none";
        }
      }


      enableValue1(value){
        if(value=='view'){
          (<HTMLInputElement> document.getElementById('fsModal1')).style.display="block";
        }
        if(value=='close'){
          (<HTMLInputElement> document.getElementById('fsModal1')).style.display="none";
        }
      }


      enableValue2(value){
        if(value=='view'){
          (<HTMLInputElement> document.getElementById('fsModal2')).style.display="block";
        }
        if(value=='close'){
          (<HTMLInputElement> document.getElementById('fsModal2')).style.display="none";
        }
      }
  clearModal(){
      this.expenseCreationDtlId.nativeElement.value = '';
      this.expenseCreationNo.nativeElement.value  = '';
      this.date.nativeElement.value  = '';
      this.expName.nativeElement.value = ''; 
      this.empNo.nativeElement.value  = ''; 
      this.employeeName.nativeElement.value='';
      this.visitPlanNo.nativeElement.value='';
       this.visitPlanDate.nativeElement.value='';
      this.dealerDistributor.nativeElement.value='';
      this.state.nativeElement.value='';
      this.city.nativeElement.value='';
      this.transport.nativeElement.value='';
      this.conSlabAmt.nativeElement.value='';
      this.conClaimActual.nativeElement.value='';
      this.conSpecialApproval.nativeElement.value='';
      this.conveyanceRemark.nativeElement.value='';
      this.conProofOfDocument.nativeElement.value='';
      this.conApprovedAmtByBm.nativeElement.value='';
      this.conApprovedAmtByRsm.nativeElement.value='';
      this.conApprovedAmtByDgmGm.nativeElement.value='';
      this.conApprovedAmtByDirectors.nativeElement.value='';
      this.conApprovedAmtByFinance.nativeElement.value='';
      this.boardingSlabAmt.nativeElement.value='';
      this.boardingClaimActual.nativeElement.value='';
      this.boardingSpecialApproval.nativeElement.value='';
      this.boardingRemark.nativeElement.value='';
      this.boardingProofOfDocument.nativeElement.value='';
      this.boardingApprovedAmtByBm.nativeElement.value='';
      this.boardingApprovedAmtByRsm.nativeElement.value='';
      this.boardingApprovedAmtByDgmGm.nativeElement.value='';
      this.boardingApprovedAmtByDirectors.nativeElement.value='';
      this.boardingApprovedAmtByFinance.nativeElement.value='';

      this.allowanceSlabAmt.nativeElement.value='';
      this.allowanceClaimActual.nativeElement.value='';
      this.allowanceSpecialApproval.nativeElement.value='';
      this.allowanceRemark.nativeElement.value='';
      this.allowanceProofOfDocument.nativeElement.value='';
      this.allowanceApprovedAmtByBm.nativeElement.value='';
      this.allowanceApprovedAmtByRsm.nativeElement.value='';
      this.allowanceApprovedAmtByDgmGm.nativeElement.value='';
      this.allowanceApprovedAmtByDirectors.nativeElement.value='';
      this.allowanceApprovedAmtByFinance.nativeElement.value='';
  
   }

  onDeleteConfirm(event): void {
    if (window.confirm('Are you sure you want to delete?')) {
      event.confirm.resolve();
    } else {
      event.confirm.reject();
    }
  }
 onSaveConfirm(event) {
    if (window.confirm('Are you sure you want to save?')) {
      event.newData['name'] += ' + added in code';
      event.confirm.resolve(event.newData);
    } else {
      event.confirm.reject();
    }
  }

}

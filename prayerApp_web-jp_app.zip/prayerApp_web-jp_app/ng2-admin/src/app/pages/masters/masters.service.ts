import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';
import { HttpModule } from '@angular/http';
import * as MasterConstants from '../masterconstants';
import { Headers, Response, URLSearchParams } from '@angular/http';

@Injectable()
export class MastersService {

    constructor(private http: Http) {
        // console.log('entering service');
    }


    getTopics() {
        var headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let urlSearchParams = new URLSearchParams();

        let body = urlSearchParams.toString();
        return this.http.post(MasterConstants.WEB_URL + '/getTopics.php', body, {
            headers: headers
        }).map(res => res.json());

        //  return this.http.get(MasterConstants.WEB_URL+'agriMachApp/loginUser?username=' + username + '&&password=' + password).map(res => res.json());
    }
    
    getBooks() {
        var headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let urlSearchParams = new URLSearchParams();

        let body = urlSearchParams.toString();
        return this.http.post(MasterConstants.WEB_URL + '/getBooks.php', body, {
            headers: headers
        }).map(res => res.json());

        //  return this.http.get(MasterConstants.WEB_URL+'agriMachApp/loginUser?username=' + username + '&&password=' + password).map(res => res.json());
    }

    getTopicsBysearch(text) {
        var headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let urlSearchParams = new URLSearchParams();

        urlSearchParams.append('text', text);
        let body = urlSearchParams.toString();

        return this.http.post(MasterConstants.WEB_URL + '/getTopicsBySearch.php', body, {
            headers: headers
        }).map(res => res.json());

        //  return this.http.get(MasterConstants.WEB_URL+'agriMachApp/loginUser?username=' + username + '&&password=' + password).map(res => res.json());
    }

    getBSBysearch(text) {
        var headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let urlSearchParams = new URLSearchParams();

        urlSearchParams.append('text', text);
        let body = urlSearchParams.toString();

        return this.http.post(MasterConstants.WEB_URL + '/getBeliefStatementBySearch.php', body, {
            headers: headers
        }).map(res => res.json());

        //  return this.http.get(MasterConstants.WEB_URL+'agriMachApp/loginUser?username=' + username + '&&password=' + password).map(res => res.json());
    }
    getConceptsBysearch(text) {
        var headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let urlSearchParams = new URLSearchParams();

        urlSearchParams.append('text', text);
        let body = urlSearchParams.toString();

        return this.http.post(MasterConstants.WEB_URL + '/getConceptsBySearch.php', body, {
            headers: headers
        }).map(res => res.json());

        //  return this.http.get(MasterConstants.WEB_URL+'agriMachApp/loginUser?username=' + username + '&&password=' + password).map(res => res.json());
    }

    


    

    getBeliefStatementData(id,) {
        var headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let urlSearchParams = new URLSearchParams();
        urlSearchParams.append('id', id);
        //urlSearchParams.append('index', index);

        let body = urlSearchParams.toString();
        return this.http.post(MasterConstants.WEB_URL + '/getDetails.php', body, {
            headers: headers
        }).map(res => res.json());

    }

    getBeliefStatementDataDiscover(id,index) {
        var headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let urlSearchParams = new URLSearchParams();
        urlSearchParams.append('id', id);
        urlSearchParams.append('index', index);

        let body = urlSearchParams.toString();
        return this.http.post(MasterConstants.WEB_URL + '/getDetails.php', body, {
            headers: headers
        }).map(res => res.json());

    }

    getBeliefStatementsequence(SequenceId) {
        var headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let urlSearchParams = new URLSearchParams();
        urlSearchParams.append('SequenceId', SequenceId);
        // urlSearchParams.append('topic', topic);

        let body = urlSearchParams.toString();
        return this.http.post(MasterConstants.WEB_URL + '/getSequenceDetails.php', body, {
            headers: headers
        }).map(res => res.json());
    }

    getSequenceDetailsBySequence(SequenceId) {
        var headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let urlSearchParams = new URLSearchParams();
        urlSearchParams.append('sequenceId', SequenceId);
        // urlSearchParams.append('topic', topic);

        let body = urlSearchParams.toString();
        return this.http.post(MasterConstants.WEB_URL + '/getSequenceDetailsBySequence.php', body, {
            headers: headers
        }).map(res => res.json());
    }
    getSequenceDetailsBySequenceBySearch(SequenceId,value) {
        var headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let urlSearchParams = new URLSearchParams();
        urlSearchParams.append('sequenceId', SequenceId);
        urlSearchParams.append('search', value);
        // urlSearchParams.append('topic', topic);

        let body = urlSearchParams.toString();
        return this.http.post(MasterConstants.WEB_URL + '/getSequenceDetailsBySequenceBySearch.php', body, {
            headers: headers
        }).map(res => res.json());
    }
    

    
    getTopic(SequenceId,topic) {
        var headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let urlSearchParams = new URLSearchParams();
        urlSearchParams.append('SequenceId', SequenceId);
        urlSearchParams.append('topic', topic);

        let body = urlSearchParams.toString();
        return this.http.post(MasterConstants.WEB_URL + '/getSequenceDetails.php', body, {
            headers: headers
        }).map(res => res.json());
    }

    getSequence(SequenceId,bySequence) {
        var headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let urlSearchParams = new URLSearchParams();
        urlSearchParams.append('SequenceId', SequenceId);
        urlSearchParams.append('bySequence', bySequence);

        let body = urlSearchParams.toString();
        return this.http.post(MasterConstants.WEB_URL + '/getSequenceDetailsBySequence.php', body, {
            headers: headers
        }).map(res => res.json());
    }


    saveMakeFavBeliefStatement(beliefId) {
        var headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let urlSearchParams = new URLSearchParams();
        urlSearchParams.append('beliefId', beliefId);
        urlSearchParams.append('userId', localStorage.getItem('userId'));
        urlSearchParams.append('fav', 'makeFav');
        
        let body = urlSearchParams.toString();
        return this.http.post(MasterConstants.WEB_URL + '/saveFavBeliefStatement.php', body, {
            headers: headers
        }).map(res => res.json());
    }

    
    Submit(name,mail,beliefStatementId) {
        var headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let urlSearchParams = new URLSearchParams();
        urlSearchParams.append('name', name);
        urlSearchParams.append('mail', mail);

        // urlSearchParams.append('userId', localStorage.getItem('userId'));
        urlSearchParams.append('beliefStatementId', 'beliefStatementId');
        
        let body = urlSearchParams.toString();
        return this.http.post(MasterConstants.WEB_URL + '/saveFavBeliefStatement.php', body, {
            headers: headers
        }).map(res => res.json());
    }

    saveMakeUnFavBeliefStatement(beliefId) {
        var headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let urlSearchParams = new URLSearchParams();
        urlSearchParams.append('beliefId', beliefId);
        urlSearchParams.append('userId', localStorage.getItem('userId'));
        urlSearchParams.append('fav', 'makeUnFav');
        
        let body = urlSearchParams.toString();
        return this.http.post(MasterConstants.WEB_URL + '/saveFavBeliefStatement.php', body, {
            headers: headers
        }).map(res => res.json());
    }


    getFavBeliefStatement(beliefId){
        var headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let urlSearchParams = new URLSearchParams();
        urlSearchParams.append('beliefId', beliefId);
        urlSearchParams.append('userId', localStorage.getItem('userId'));
        
        let body = urlSearchParams.toString();
        return this.http.post(MasterConstants.WEB_URL + '/getFavBeliefStatement.php', body, {
            headers: headers
        }).map(res => res.json());
    }
    

    sendmail(id,name,email) {
        var headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let urlSearchParams = new URLSearchParams();
        urlSearchParams.append('id', id);
        urlSearchParams.append('email', email);
        urlSearchParams.append('name', name);

        let body = urlSearchParams.toString();
        return this.http.post(MasterConstants.WEB_URL + '/sendBookmail.php', body, {
            headers: headers
        }).map(res => res.json());

    }


    getPassageFromDatabaseSheet(value) {
        var headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let urlSearchParams = new URLSearchParams();
        //urlSearchParams.append('id', SequenceId);
        urlSearchParams.append('search', value);
        // urlSearchParams.append('topic', topic);

        let body = urlSearchParams.toString();
        return this.http.post(MasterConstants.WEB_URL + '/getAdditionalReference.php', body, {
            headers: headers
        }).map(res => res.json());
    }

    getSuggestionConceptsBysearch(text) {
        var headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded');
        let urlSearchParams = new URLSearchParams();

        urlSearchParams.append('text', text);
        let body = urlSearchParams.toString();

        return this.http.post(MasterConstants.WEB_URL + '/getSuggestionConceptsBysearch.php', body, {
            headers: headers
        }).map(res => res.json());

        //  return this.http.get(MasterConstants.WEB_URL+'agriMachApp/loginUser?username=' + username + '&&password=' + password).map(res => res.json());
    }



}

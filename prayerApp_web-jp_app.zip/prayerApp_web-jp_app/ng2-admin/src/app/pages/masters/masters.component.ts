import {Component} from '@angular/core';

@Component({
  selector: 'masters',
  template: `<router-outlet></router-outlet>`
})
export class Masters {
  constructor() {
  }
}

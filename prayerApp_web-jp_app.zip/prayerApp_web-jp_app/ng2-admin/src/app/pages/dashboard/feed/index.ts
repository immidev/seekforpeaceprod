export * from './feed.component';

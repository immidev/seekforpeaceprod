import {Injectable} from '@angular/core';
import {BaThemeConfigProvider, colorHelper} from '../../../theme';

import { Http } from '@angular/http';
import 'rxjs/add/operator/map';
import { HttpModule } from '@angular/http';
import * as MasterConstants from '../../masterconstants'; //<==== this one
import { Headers, Response, URLSearchParams } from '@angular/http';


@Injectable()
export class PieChartService {

  constructor(private _baConfig:BaThemeConfigProvider,private http: Http) {
  }

  getData(date) {
    //let pieColor = this._baConfig.get().colors.custom.dashboardPieChart;
    /*return [
      {
      //  color: pieColor,
        description: 'Total Farmers',
        stats: '57,820',
        //icon: 'person',
      }, {
        //color: pieColor,
        description: 'Farmers Registered Today',
        stats: '89,745',
        //icon: 'money',
      }, {
        //color: pieColor,
        description: 'Total Tractor Owners',
        stats: '178,391',
        //icon: 'face',
      }, {
        //color: pieColor,
        description: 'Tractor Owners Registered Today',
        stats: '32,592',
        //icon: 'refresh',
      }
    ];*/
    var headers = new Headers();
    headers.append('Content-Type', 'application/x-www-form-urlencoded');
    let urlSearchParams = new URLSearchParams();
    urlSearchParams.append('date',date);
    urlSearchParams.append('userTO', localStorage.getItem('currentUser'));
    let body = urlSearchParams.toString();

    return this.http.post(MasterConstants.WEB_URL + 'dashboardValue1', body, {headers: headers}).map(res => res.json());
  }
}
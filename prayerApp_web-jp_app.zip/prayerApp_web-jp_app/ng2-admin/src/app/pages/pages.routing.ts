import { Routes, RouterModule }  from '@angular/router';
import { Pages } from './pages.component';
import { ModuleWithProviders } from '@angular/core';
// noinspection TypeScriptValidateTypes

// export function loadChildren(path) { return System.import(path); };

export const routes: Routes = [
  {
    path: 'login',
    loadChildren: 'app/pages/login/login.module#LoginModule'
  },
  {
    path: 'createAccount',
    loadChildren: 'app/pages/createAccount/createAccount.module#CreateAccountModule'
  },
  {
    path: 'register',
    loadChildren: 'app/pages/register/register.module#RegisterModule'
  },
  {
    path: 'membership',
    loadChildren: 'app/pages/membership/membership.module#MembershipModule'
  },
  {
    path: 'pages',
    component: Pages,
    children: [
      { path: '', redirectTo: 'masters', pathMatch: 'full' },
      { path: 'dashboard', loadChildren: './dashboard/dashboard.module#DashboardModule' },
      { path: 'setup', loadChildren: './setup/setup.module#SetupModule'},
      { path: 'transaction', loadChildren: './transaction/transaction.module#TransactionModule'},
      { path: 'masters', loadChildren: './masters/masters.module#MastersModule'}, 
      //{ path: 'updateProfile', loadChildren: './masters/masters.module#MastersModule'}, 

      // { path: 'ui', loadChildren: './ui/ui.module#UiModule' },
      // { path: 'editors', loadChildren: './editors/editors.module#EditorsModule' },
      // { path: 'components', loadChildren: './components/components.module#ComponentsModule' },
      // { path: 'charts', loadChildren: './charts/charts.module#ChartsModule' },
      // { path: 'forms', loadChildren: './forms/forms.module#FormsModule' },
      // { path: 'tables', loadChildren: './tables/tables.module#TablesModule' },
      // { path: 'maps', loadChildren: './maps/maps.module#MapsModule' },
      // { path: 'firstnew', loadChildren: './firstnew/firstnew.module#FirstNewModule'},
      //{ path: 'vehicleModel', loadChildren: './vehicleModel/vehicleModel.module#VehicleModelModule'},
      // { path: 'devicemanagement', loadChildren: './devicemanagement/devicemanagement.module#DeviceManagementModule'},
      // { path: 'viewrequest', loadChildren: './viewrequest/viewrequest.module#ViewRequestModule'},
      // { path: 'reports', loadChildren: './reports/reports.module#ReportModule'},
    ]
  } 
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);

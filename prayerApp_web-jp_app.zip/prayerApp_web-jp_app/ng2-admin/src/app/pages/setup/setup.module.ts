import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CKEditorModule } from 'ng2-ckeditor';
import { NgaModule } from '../../theme/nga.module';
import { Component } from '@angular/core';
import { FormGroup, AbstractControl, FormBuilder, Validators } from '@angular/forms';
import { Ng2SmartTableModule } from 'ng2-smart-table';
//import { Typeahead } from 'ng2-typeahead-master';
import { MastersModule } from 'app/pages/masters/masters.module';

import { DataTableModule } from 'angular2-datatable';
import { HttpModule } from '@angular/http';
import { NgbDropdownModule, NgbModalModule, NgbTabsetModule, NgbDatepickerModule } from '@ng-bootstrap/ng-bootstrap';

import { routing } from './setup.routing';
import { Setup } from 'app/pages/setup';

import { Ckeditor } from './components/ckeditor/ckeditor.component';

import { Location } from './components/location/location.component';
import { LocationService } from './components/location/location.service';
import { LocationListV } from 'app/pages/setup/components/location/location.listv.component';
import { LocationInfoVW } from 'app/pages/setup/components/location/locationInfoVW';

import { ChangePassword } from './components/changePassword/changePassword.component';
import { ChangePasswordService } from './components/changePassword/changePassword.service';

import { UserManagement } from './components/userManagement/userManagement.component';
import { UserManagementService } from './components/userManagement/userManagement.service';
import { UserListV } from './components/userManagement/userListV.component';
import { UserInfoVW } from './components/userManagement/userInfoVW';
import { GroupListV } from './components/userManagement/groupListV.component';
import { GroupInfoVW } from './components/userManagement/groupInfoVW';

import { LoggedInUserListV } from './components/userManagement/loggedInUserListV.component';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    NgaModule,
    CKEditorModule,
    Ng2SmartTableModule,
    DataTableModule,
    NgbDropdownModule,
    NgbModalModule,
    NgbTabsetModule,
    NgbDatepickerModule,
    HttpModule,
    routing,
    MastersModule,
  ],
  declarations: [
    Setup,
    Ckeditor,
   // Typeahead,
    Location,
    LocationListV,
    LocationInfoVW,
    ChangePassword,
    UserManagement,
    UserListV,
    UserInfoVW,
    GroupListV,
    GroupInfoVW,
    LoggedInUserListV,
  ],
  entryComponents: [
    LocationInfoVW,
    UserInfoVW,
    GroupInfoVW,
  ],
  providers: [
    LocationService,
    ChangePasswordService,
    UserManagementService,
  ],
})
export class SetupModule {
}

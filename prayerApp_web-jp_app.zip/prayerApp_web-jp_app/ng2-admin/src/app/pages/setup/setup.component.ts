import {Component} from '@angular/core';

@Component({
  selector: 'setup',
  template: `<router-outlet></router-outlet>`
})
export class Setup {
  constructor() {
  }
}

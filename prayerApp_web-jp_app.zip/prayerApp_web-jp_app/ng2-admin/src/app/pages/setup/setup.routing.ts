import { Routes, RouterModule }  from '@angular/router';


import { Ckeditor } from './components/ckeditor/ckeditor.component';
import { Location } from './components/location/location.component';
import { ChangePassword } from './components/changePassword/changePassword.component';
import { UserManagement } from './components/userManagement/userManagement.component';

import { Setup } from 'app/pages/setup';

// noinspection TypeScriptValidateTypes
const routes: Routes = [
  {
    path: '',
    component: Setup,
    children: [
      { path: 'ckeditor', component: Ckeditor },
      { path: 'location', component: Location},
      { path: 'changePassword', component: ChangePassword},
      { path: 'userManagement', component: UserManagement},
    ]
  }
];

export const routing = RouterModule.forChild(routes);

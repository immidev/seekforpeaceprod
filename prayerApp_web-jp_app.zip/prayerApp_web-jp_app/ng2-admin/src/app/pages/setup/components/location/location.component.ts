import { Component } from '@angular/core';
import { HttpModule } from '@angular/http';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { LocationService } from 'app/pages/setup/components/location/location.service';
import { LocationInfoVW } from 'app/pages/setup/components/location/locationInfoVW';
import {ViewChild, ContentChild, Host, Inject, forwardRef} from '@angular/core'
import { LocationListV } from 'app/pages/setup/components/location/location.listv.component';

@Component({
  selector: 'location',
  //template: `<strong>Location Content need to shown</strong>`,
  templateUrl: './locationMain.html'
  
})
export class Location {
  @ViewChild(LocationListV) a: LocationListV;
  @ViewChild(LocationInfoVW) b: LocationInfoVW;
  //constructor() {}
  

  constructor(private modalService: NgbModal, private service: LocationService) {
    this.service.userGroupAccess("Location").subscribe(posts =>{
      (<HTMLInputElement> document.getElementById("locationEditBtn")).disabled = posts.list[0].edit;
      (<HTMLInputElement> document.getElementById("locationViewBtn")).disabled = posts.list[0].view;
      //console.log("add"+posts.list[0].add);
      //console.log("edit"+posts.list[0].edit);
      //console.log("view"+posts.list[0].view);
      //console.log("deleteF"+posts.list[0].deleteF);
    });
    // this.fruits = this.service.getData3();
     }
   
     lgModalShow(mode) {
      
        if(mode=='e'){

          if(this.a.locationIdVal != null && this.a.locationIdVal!=''){
            const activeModal = this.modalService.open(LocationInfoVW, { size: 'lg',backdrop:'static' });
            //console.log(this.a.rowItem);
            (<HTMLInputElement> document.getElementById("locFnMode")).value = 'e';
            (<HTMLInputElement> document.getElementById("btnLocationClear")).disabled = true;
            //console.log(this.a.rowItem["locName"]);
            //console.log(JSON.stringify(this.a.rowItem["locName"]));
            
            (<HTMLInputElement> document.getElementById("locationName")).value = this.a.rowItem["locName"];
            (<HTMLInputElement>document.getElementById('locationName')).readOnly = true;
            //(<HTMLInputElement>document.getElementById('locationName')).style.backgroundColor='#ffff75';
            (<HTMLInputElement> document.getElementById("orgName")).value = this.a.rowItem["orgName"];
            (<HTMLInputElement> document.getElementById("description")).value = this.a.rowItem["locDesc"];
            (<HTMLInputElement> document.getElementById("locationType")).value = this.a.rowItem["locType"];
            
            //hidden
            (<HTMLInputElement> document.getElementById("locationId")).value = this.a.rowItem["locId"];
            (<HTMLInputElement> document.getElementById("locCreatedBy")).value = this.a.rowItem["createdBy"];
            (<HTMLInputElement> document.getElementById("locCreatedDate")).value = this.a.rowItem["createdDtDisplay"];
            (<HTMLInputElement> document.getElementById("locOracleOrgId")).value = this.a.rowItem["orgId"];
            //HTMLButtonElement
            //this.b.locAddress.nativeElement.value = this.a.rowItem["address1"];
           // this.b.setTabVaues();
           setTimeout(() => {
              (<HTMLInputElement> document.getElementById("locAddress")).value = this.a.rowItem["address1"];
              (<HTMLInputElement> document.getElementById("locCountry")).value = this.a.rowItem["country"];
              (<HTMLInputElement> document.getElementById("locCity")).value = this.a.rowItem["city"];
              (<HTMLInputElement> document.getElementById("locZipcode")).value = this.a.rowItem["zip"];
              (<HTMLInputElement> document.getElementById("locState")).value = this.a.rowItem["state"];
              (<HTMLInputElement> document.getElementById("locTelNo")).value = this.a.rowItem["telno"];
              (<HTMLInputElement> document.getElementById("locFaxNo")).value = this.a.rowItem["faxno"];
        
              (<HTMLInputElement> document.getElementById("locSmtpServerName")).value = this.a.rowItem["smtpServerName"];
              (<HTMLInputElement> document.getElementById("locConfirmPassword")).value = this.a.rowItem["popAccountPwd"];
              (<HTMLInputElement> document.getElementById("locPopServerName")).value = this.a.rowItem["popServerName"];
              (<HTMLInputElement> document.getElementById("locAdminEmail")).value = this.a.rowItem["adminEmailId"];
              (<HTMLInputElement> document.getElementById("locPopAccountId")).value = this.a.rowItem["popAccountId"];
              (<HTMLInputElement> document.getElementById("locSmtpPort")).value = this.a.rowItem["smtpPortNo"];
              (<HTMLInputElement> document.getElementById("locPopAccountPassword")).value = this.a.rowItem["popAccountPwd"];
            }, 10);
          
            //(<HTMLInputElement> document.getElementById("locAddress") as any).value = this.a.rowItem["address1"];
            //this.b.locAddress.nativeElement.value = this.a.rowItem["address1"];
            /*            */
            
            activeModal.componentInstance.modalHeader = 'Location';
          }else{
            alert('Please select a record to Edit');
          }
        

        }else if(mode == 'v'){
          if(this.a.locationIdVal != null && this.a.locationIdVal!=''){
            
            const activeModal = this.modalService.open(LocationInfoVW, { size: 'lg',backdrop:'static' });

            (<HTMLInputElement> document.getElementById("locFnMode")).value = 'v';
            (<HTMLInputElement> document.getElementById("btnLocationSumbit")).disabled = true;
            (<HTMLInputElement> document.getElementById("btnLocationClear")).disabled = true;
            
            (<HTMLInputElement> document.getElementById("locationName")).value = this.a.rowItem["locName"];
            (<HTMLInputElement>document.getElementById('locationName')).readOnly = true;
            (<HTMLInputElement> document.getElementById("orgName")).value = this.a.rowItem["orgName"];
            (<HTMLInputElement> document.getElementById("description")).value = this.a.rowItem["locDesc"];
            (<HTMLInputElement> document.getElementById("locationType")).value = this.a.rowItem["locType"];
            
            //hidden
            (<HTMLInputElement> document.getElementById("locationId")).value = this.a.rowItem["locId"];
            (<HTMLInputElement> document.getElementById("locCreatedBy")).value = this.a.rowItem["createdBy"];
            (<HTMLInputElement> document.getElementById("locCreatedDate")).value = this.a.rowItem["createdDtDisplay"];
            (<HTMLInputElement> document.getElementById("locOracleOrgId")).value = this.a.rowItem["orgId"];
            
            setTimeout(() => {
              (<HTMLInputElement> document.getElementById("locAddress") as any).value = this.a.rowItem["address1"];
              (<HTMLInputElement> document.getElementById("locCountry")).value = this.a.rowItem["country"];
              (<HTMLInputElement> document.getElementById("locCity")).value = this.a.rowItem["city"];
              (<HTMLInputElement> document.getElementById("locZipcode")).value = this.a.rowItem["zip"];
              (<HTMLInputElement> document.getElementById("locState")).value = this.a.rowItem["state"];
              (<HTMLInputElement> document.getElementById("locTelNo")).value = this.a.rowItem["telno"];
              (<HTMLInputElement> document.getElementById("locFaxNo")).value = this.a.rowItem["faxno"];
        
              (<HTMLInputElement> document.getElementById("locSmtpServerName")).value = this.a.rowItem["smtpServerName"];
              (<HTMLInputElement> document.getElementById("locConfirmPassword")).value = this.a.rowItem["popAccountPwd"];
              (<HTMLInputElement> document.getElementById("locPopServerName")).value = this.a.rowItem["popServerName"];
              (<HTMLInputElement> document.getElementById("locAdminEmail")).value = this.a.rowItem["adminEmailId"];
              (<HTMLInputElement> document.getElementById("locPopAccountId")).value = this.a.rowItem["popAccountId"];
              (<HTMLInputElement> document.getElementById("locSmtpPort")).value = this.a.rowItem["smtpPortNo"];
              (<HTMLInputElement> document.getElementById("locPopAccountPassword")).value = this.a.rowItem["popAccountPwd"];
            }, 10);
            activeModal.componentInstance.modalHeader = 'Location';
        }else{
          alert('Please select a record to View');
        }
        }
     }
  

}

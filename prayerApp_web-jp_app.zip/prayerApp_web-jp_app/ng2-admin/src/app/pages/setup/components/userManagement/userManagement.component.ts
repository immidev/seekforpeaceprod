import { Component,ElementRef } from '@angular/core';
import { HttpModule } from '@angular/http';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import {ViewChild, ContentChild, Host, Inject, forwardRef} from '@angular/core';
import { FormGroup, AbstractControl, FormBuilder, Validators } from '@angular/forms';

import { UserManagementService } from '../../components/userManagement/userManagement.service';
import { LoggedInUserListV } from '../../components/userManagement/loggedInUserListV.component';

import { UserListV } from '../../components/userManagement/userListV.component';
import { GroupListV } from 'app/pages/setup/components/userManagement/groupListV.component';
import { GroupInfoVW } from 'app/pages/setup/components/userManagement/groupInfoVW';
import { UserInfoVW } from 'app/pages/setup/components/userManagement/userInfoVW';

@Component({
  selector: 'userManagement',
  //template: `<strong>Location Content need to shown</strong>`,
  templateUrl: './userManagementMain.html'
  
})
export class UserManagement {
  @ViewChild(GroupListV) a: GroupListV;
  @ViewChild(UserListV) b: UserListV;
  
  @ViewChild('searchUserInfoUserName') searchUserInfoUserName: ElementRef;
  @ViewChild('searchUserInfoUserId') searchUserInfoUserId: ElementRef;
  @ViewChild('searchUserInfoUserEmail') searchUserInfoUserEmail: ElementRef; 
  @ViewChild('searchGroupAccessGroupName') searchGroupAccessGroupName: ElementRef; 

  

  public tabAccessEnabled: boolean = true;
  
  public groupAccessGroupNameSelectedVal={groupName: ''};
  
  searchUserGroupNameSelected: string;
  searchUserGroupIdSelected: string;
  groupNameSelected: string;
  groupAccessGroupNameSelected: string;
  groupAccessGroupIdSelected: string;
  groupIdSelected: string;
  groupNameCombo: any[] = [ ];
  groupAccessGroupNameCombo: any[] = [ ];

  groupAccessData:Array<any>;

  
  public itemSearchUserGroupSelected(list) {
    this.searchUserGroupNameSelected = list ? list.groupName : '';
    this.searchUserGroupIdSelected = list ? list.groupId : '';
  }

  public itemGroupNameSelected(list) {
    this.groupNameSelected = list ? list.groupName : '';
    this.groupIdSelected = list ? list.groupId : '';
  }

  public itemGroupAccessGroupNameSelected(){  
     let list = this.groupAccessGroupNameCombo[this.searchGroupAccessGroupName.nativeElement.selectedIndex - 1]
    this.groupAccessGroupNameSelected = list ? list.groupName : '';
    this.groupAccessGroupIdSelected = list ? list.groupId : '';
    this.service.getGroupModules(this.groupAccessGroupIdSelected).subscribe(posts =>{ 
      this.groupAccessData =posts.listGroupModules; 
  });
  }

  constructor(private modalService: NgbModal, private service: UserManagementService) {
    this.service.userGroupAccess("User Management").subscribe(posts =>{
        if(JSON.parse(localStorage.getItem('currentUser')).groupId==1 || JSON.parse(localStorage.getItem('currentUser')).groupId==3){
            this.tabAccessEnabled = false;
          }

          
          (<HTMLInputElement> document.getElementById("userInfoAddBtn")).disabled = posts.list[0].add;
          (<HTMLInputElement> document.getElementById("userInfoEditBtn")).disabled = posts.list[0].edit;
          (<HTMLInputElement> document.getElementById("userInfoViewBtn")).disabled = posts.list[0].view;

          (<HTMLInputElement> document.getElementById("groupAddBtn")).disabled = posts.list[0].add;
          (<HTMLInputElement> document.getElementById("groupEditBtn")).disabled = posts.list[0].edit;
          (<HTMLInputElement> document.getElementById("groupViewBtn")).disabled = posts.list[0].view;
      //console.log("add"+posts.list[0].add);
      //console.log("edit"+posts.list[0].edit);
      //console.log("view"+posts.list[0].view);
      //console.log("deleteF"+posts.list[0].deleteF);
    });
    this.service.getGroupNameCombo().subscribe(posts => {
      this.groupNameCombo = posts.userGroupsList;
      this.groupAccessGroupNameCombo = posts.userGroupsList;
  });
    // this.fruits = this.service.getData3();
     }
   
     

     addGroupModalShow(){
      const activeModal = this.modalService.open(GroupInfoVW, { backdrop:'static' });
      localStorage.removeItem('groupModuleGroupId');
      localStorage.setItem('groupModuleGroupId','');
      (<HTMLInputElement> document.getElementById("groupLocationName")).value = JSON.parse(localStorage.getItem('currentUser')).locName;
      (<HTMLInputElement> document.getElementById('groupLocationName')).readOnly = true;
      (<HTMLInputElement> document.getElementById('groupLocationName')).style.backgroundColor='#ffff75';
      (<HTMLInputElement> document.getElementById('groupLocationName')).style.color='#000000';
     
      (<HTMLInputElement> document.getElementById("groupLocationId")).value = JSON.parse(localStorage.getItem('currentUser')).locationId;

      (<HTMLInputElement> document.getElementById("groupCreatedBy")).value = '';
      (<HTMLInputElement> document.getElementById("groupCreatedDate")).value = '';
      (<HTMLInputElement> document.getElementById("groupFnMode")).value = 'a';
      (<HTMLInputElement> document.getElementById("groupId")).value = '';
      
      activeModal.componentInstance.modalHeader = 'Group';
     }
//this.selectedRowGroupId

editAndViewGroup(mode){
          if(mode=='e'){
            //console.log(this.a.selectedRowGroupId);
              if(this.a.selectedRowGroupId != null && this.a.selectedRowGroupId!=''){
                localStorage.removeItem('groupModuleGroupId');
                localStorage.setItem('groupModuleGroupId',this.a.selectedRowGroupId);
                
                const activeModal = this.modalService.open(GroupInfoVW, { backdrop:'static' });
                (<HTMLInputElement> document.getElementById("btnGroupClear")).disabled = true;
                this.service.loadGroupDetailedInfo(localStorage.getItem('groupModuleGroupId')).subscribe(posts =>{
                  //console.log("loadGroupDetailedInfo");
                  //console.log(posts);
                  
                  (<HTMLInputElement> document.getElementById("groupLocationName")).value = JSON.parse(localStorage.getItem('currentUser')).locName;
                  (<HTMLInputElement> document.getElementById('groupLocationName')).readOnly = true;
                  (<HTMLInputElement> document.getElementById('groupLocationName')).style.backgroundColor='#ffff75';
                  (<HTMLInputElement> document.getElementById('groupLocationName')).style.color='#000000';
                 
                  (<HTMLInputElement> document.getElementById("groupName")).value = posts.locFetchedTO.groupName;
                  (<HTMLInputElement> document.getElementById("groupLocationId")).value = posts.locFetchedTO.locationId;
                  (<HTMLInputElement> document.getElementById("groupId")).value = posts.locFetchedTO.groupId;
                  (<HTMLInputElement> document.getElementById("groupCreatedBy")).value = posts.locFetchedTO.createdByUId;
                  (<HTMLInputElement> document.getElementById("groupCreatedDate")).value = posts.locFetchedTO.createdDtDisplay;
              });
                (<HTMLInputElement> document.getElementById("groupFnMode")).value = 'e';

                activeModal.componentInstance.modalHeader = 'Group';
              }else{
                alert('Please select a record to Edit');
              }
            
    
            }else if(mode == 'v'){
              if(this.a.selectedRowGroupId != null && this.a.selectedRowGroupId!=''){
                localStorage.removeItem('groupModuleGroupId');
                localStorage.setItem('groupModuleGroupId',this.a.selectedRowGroupId);
                const activeModal = this.modalService.open(GroupInfoVW, { backdrop:'static' });
                (<HTMLInputElement> document.getElementById("btnGroupSumbit")).disabled = true;
                (<HTMLInputElement> document.getElementById("btnGroupClear")).disabled = true;

                this.service.loadGroupDetailedInfo(localStorage.getItem('groupModuleGroupId')).subscribe(posts =>{
                  //console.log("loadGroupDetailedInfo");
                  //console.log(posts);
                  
                  (<HTMLInputElement> document.getElementById("groupLocationName")).value = JSON.parse(localStorage.getItem('currentUser')).locName;
                  (<HTMLInputElement> document.getElementById("groupName")).value = posts.locFetchedTO.groupName;
                  (<HTMLInputElement> document.getElementById("groupLocationId")).value = posts.locFetchedTO.locationId;
                  (<HTMLInputElement> document.getElementById("groupId")).value = posts.locFetchedTO.groupId;
                  (<HTMLInputElement> document.getElementById("groupCreatedBy")).value = posts.locFetchedTO.createdByUId;
                  (<HTMLInputElement> document.getElementById("groupCreatedDate")).value = posts.locFetchedTO.createdDtDisplay;
              });
                (<HTMLInputElement> document.getElementById("groupFnMode")).value = 'v';
                activeModal.componentInstance.modalHeader = 'Group';
            }else{
              alert('Please select a record to View');
            }
            }
}

    searchGroup() {
      this.a.search(this.groupIdSelected);
    }
     
    resetGroup() {
      this.a.reset();
      this.groupNameSelected = '';
      this.groupIdSelected ='';
    }

    resetGroupAccessValue() {
      this.groupAccessGroupNameSelected ='';
      this.groupAccessGroupIdSelected = '';
      this.groupAccessGroupNameSelectedVal={groupName: ''}
      this.groupAccessData = null;
    }


    addUserInfoModalShow(){
      const activeModal = this.modalService.open(UserInfoVW, { size: 'lg',backdrop:'static' });
      (<HTMLInputElement> document.getElementById("userLocationName")).value = JSON.parse(localStorage.getItem('currentUser')).locName;
      (<HTMLInputElement> document.getElementById('userLocationName')).readOnly = true;
      (<HTMLInputElement> document.getElementById('userLocationName')).style.backgroundColor='#ffff75';
      (<HTMLInputElement> document.getElementById('userLocationName')).style.color='#000000';
     
      (<HTMLInputElement> document.getElementById("userLocNameId")).value = JSON.parse(localStorage.getItem('currentUser')).locationId;
     
      (<HTMLInputElement> document.getElementById("userCreatedBy")).value = '';
      (<HTMLInputElement> document.getElementById("userCreatedDtDisp")).value = '';
      (<HTMLInputElement> document.getElementById("userFnMode")).value = 'a';
       
      activeModal.componentInstance.modalHeader = 'User Details';
    }


    editAndViewUser(mode){

      if(mode=='e'){
        //console.log(this.b.selectedRowUserId);
          if(this.b.selectedRowUserId != null && this.b.selectedRowUserId!=''){  
            const activeModal = this.modalService.open(UserInfoVW, { size: 'lg',backdrop:'static' });
            (<HTMLInputElement> document.getElementById("btnUserInfoClear")).disabled = true;
            (<HTMLInputElement> document.getElementById("userFnMode")).value = 'e';
            this.service.loadUserDetailedInfo(this.b.selectedRowUserId).subscribe(posts =>{
             // console.log(posts);
             (<HTMLInputElement> document.getElementById("userLocationName")).value = posts.locFetchedTO.locName;
             (<HTMLInputElement> document.getElementById('userLocationName')).readOnly = true;
             (<HTMLInputElement> document.getElementById('userLocationName')).style.backgroundColor='#ffff75';
             (<HTMLInputElement> document.getElementById('userLocationName')).style.color='#000000';
            
              (<HTMLInputElement> document.getElementById("userLocNameId")).value = posts.locFetchedTO.locationId;
              //(<HTMLInputElement> document.getElementById("userGroupName")).value = posts.locFetchedTO.groupName;
              (<HTMLInputElement> document.getElementById("userName")).value = posts.locFetchedTO.userName;
              (<HTMLInputElement> document.getElementById("userUserName")).value = posts.locFetchedTO.userId;
              (<HTMLInputElement> document.getElementById('userUserName')).readOnly = true;
              (<HTMLInputElement> document.getElementById('userUserName')).style.backgroundColor='#ffff75';
              (<HTMLInputElement> document.getElementById('userUserName')).style.color='#000000';
             
              (<HTMLInputElement> document.getElementById("userPassword")).value = posts.locFetchedTO.passWord;
              (<HTMLInputElement> document.getElementById("userAddress")).value = posts.locFetchedTO.address;
              (<HTMLInputElement> document.getElementById("userContactMobileNo")).value = posts.locFetchedTO.mobileNo;
              (<HTMLInputElement> document.getElementById("userContactEmail")).value = posts.locFetchedTO.emailId;
              (<HTMLInputElement> document.getElementById("userContactCcEmail")).value = posts.locFetchedTO.ccEmailId;
              //(<HTMLInputElement> document.getElementById("userLanguage")).value = posts.locFetchedTO.language;
              
              (<HTMLInputElement> document.getElementById("userEmpID")).value = posts.locFetchedTO.employeeId;
              (<HTMLInputElement> document.getElementById("userDoj")).value = posts.locFetchedTO.doj;
              (<HTMLInputElement> document.getElementById("userDesignation")).value = posts.locFetchedTO.designation;
              (<HTMLInputElement> document.getElementById("userAge")).value = posts.locFetchedTO.age;

              (<HTMLInputElement> document.getElementById("startTime")).value = posts.locFetchedTO.startTime;
              (<HTMLInputElement> document.getElementById("endTime")).value = posts.locFetchedTO.endTime;

               setTimeout(() => {
                 (<HTMLInputElement> document.getElementById("reportingTo")).value = posts.locFetchedTO.reporting_to;
                }, 1000);
      



              activeModal.componentInstance.userCountryNameComboVal = {countryName : posts.locFetchedTO.country,languageCode:posts.locFetchedTO.languageCode,countryCode:posts.locFetchedTO.countryCode}; 
              activeModal.componentInstance.userGroupNameComboVal = {groupName : posts.locFetchedTO.groupName}; 
              activeModal.componentInstance.userLanguageComboVal = {language : posts.locFetchedTO.language}; 
               
              (<HTMLInputElement> document.getElementById("userZone")).value = posts.locFetchedTO.zone;
              //(<HTMLInputElement> document.getElementById("userCountry")).value = posts.locFetchedTO.country;
              setTimeout(() => {
                  (<HTMLInputElement> document.getElementById("userGroupNameId")).value = posts.locFetchedTO.groupId;
                  (<HTMLInputElement> document.getElementById("userCountryCode")).value = posts.locFetchedTO.countryCode;
                  (<HTMLInputElement> document.getElementById("userGmtTimeDiff")).value = posts.locFetchedTO.gmtTimeDiff;
                  (<HTMLInputElement> document.getElementById("userLanguageCode")).value = posts.locFetchedTO.languageCode;
                  if(posts.locFetchedTO.groupId =='5'){
                    (<HTMLInputElement> document.getElementById("userZone")).disabled = false;
                  }else{
                    (<HTMLInputElement> document.getElementById('userZone')).disabled = true;
                    (<HTMLInputElement> document.getElementById('userZone')).style.borderColor='#C0C0C0';
                  }
              },500);
              (<HTMLInputElement> document.getElementById("userAccountLocked")).checked = this.checked(posts.locFetchedTO.accountLock=='1'?'Y':'N');
              (<HTMLInputElement> document.getElementById("userLoginStatus")).checked = this.checked(posts.locFetchedTO.loginStatus);
              (<HTMLInputElement> document.getElementById("userActive")).checked = this.checked(posts.locFetchedTO.userActive=='on'?'Y':'N');
              (<HTMLInputElement> document.getElementById("userId")).value = posts.locFetchedTO.usrId;
              (<HTMLInputElement> document.getElementById("userCreatedBy")).value = posts.locFetchedTO.createdByUId;
              (<HTMLInputElement> document.getElementById("userCreatedDtDisp")).value = posts.locFetchedTO.createdDtDisplZay;
              
          });
            
            
            activeModal.componentInstance.modalHeader = 'User Details';
          }else{
            alert('Please select a record to Edit');
          }
        

        }else if(mode == 'v'){
          if(this.b.selectedRowUserId != null && this.b.selectedRowUserId!=''){ 
            const activeModal = this.modalService.open(UserInfoVW, { size: 'lg',backdrop:'static' });
            (<HTMLInputElement> document.getElementById("btnUserInfoSumbit")).disabled = true;
            (<HTMLInputElement> document.getElementById("btnUserInfoClear")).disabled = true;
            (<HTMLInputElement> document.getElementById("userFnMode")).value = 'v';
            
            this.service.loadUserDetailedInfo(this.b.selectedRowUserId).subscribe(posts =>{
              (<HTMLInputElement> document.getElementById("userLocationName")).value = posts.locFetchedTO.locName;
              (<HTMLInputElement> document.getElementById('userLocationName')).readOnly = true;
              (<HTMLInputElement> document.getElementById('userLocationName')).style.backgroundColor='#ffff75';
              (<HTMLInputElement> document.getElementById('userLocationName')).style.color='#000000';
             
               (<HTMLInputElement> document.getElementById("userLocNameId")).value = posts.locFetchedTO.locationId;
               //(<HTMLInputElement> document.getElementById("userGroupName")).value = posts.locFetchedTO.groupName;
               (<HTMLInputElement> document.getElementById("userName")).value = posts.locFetchedTO.userName;
               (<HTMLInputElement> document.getElementById("userUserName")).value = posts.locFetchedTO.userId;
               (<HTMLInputElement> document.getElementById('userUserName')).readOnly = true;
               (<HTMLInputElement> document.getElementById('userUserName')).style.backgroundColor='#ffff75';
               (<HTMLInputElement> document.getElementById('userUserName')).style.color='#000000';
              
               (<HTMLInputElement> document.getElementById("userPassword")).value = posts.locFetchedTO.passWord;
               (<HTMLInputElement> document.getElementById("userAddress")).value = posts.locFetchedTO.address;
               (<HTMLInputElement> document.getElementById("userContactMobileNo")).value = posts.locFetchedTO.mobileNo;
               (<HTMLInputElement> document.getElementById("userContactEmail")).value = posts.locFetchedTO.emailId;
               (<HTMLInputElement> document.getElementById("userContactCcEmail")).value = posts.locFetchedTO.ccEmailId;
               //(<HTMLInputElement> document.getElementById("userLanguage")).value = posts.locFetchedTO.language;
               
               (<HTMLInputElement> document.getElementById("userEmpID")).value = posts.locFetchedTO.employeeId;
               (<HTMLInputElement> document.getElementById("userDoj")).value = posts.locFetchedTO.doj;
               (<HTMLInputElement> document.getElementById("userDesignation")).value = posts.locFetchedTO.designation;
               (<HTMLInputElement> document.getElementById("userAge")).value = posts.locFetchedTO.age;

               
               activeModal.componentInstance.userCountryNameComboVal = {countryName : posts.locFetchedTO.country}; 
               activeModal.componentInstance.userGroupNameComboVal = {groupName : posts.locFetchedTO.groupName}; 
               activeModal.componentInstance.userLanguageComboVal = {language : posts.locFetchedTO.language}; 
                        
               //(<HTMLInputElement> document.getElementById("userCountry")).value = posts.locFetchedTO.country;
               (<HTMLInputElement> document.getElementById("userZone")).value = posts.locFetchedTO.zone;
               setTimeout(() => {
                (<HTMLInputElement> document.getElementById("userGroupNameId")).value = posts.locFetchedTO.groupId;
                (<HTMLInputElement> document.getElementById("userCountryCode")).value = posts.locFetchedTO.countryCode;
                (<HTMLInputElement> document.getElementById("userGmtTimeDiff")).value = posts.locFetchedTO.gmtTimeDiff;
                (<HTMLInputElement> document.getElementById("userLanguageCode")).value = posts.locFetchedTO.languageCode;
                if(posts.locFetchedTO.groupId =='5'){
                  (<HTMLInputElement> document.getElementById("userZone")).disabled = false;
                }else{
                  (<HTMLInputElement> document.getElementById('userZone')).disabled = true;
                  (<HTMLInputElement> document.getElementById('userZone')).style.borderColor='#C0C0C0';
                }

            },500);
               (<HTMLInputElement> document.getElementById("userAccountLocked")).checked = this.checked(posts.locFetchedTO.accountLock=='1'?'Y':'N');
               (<HTMLInputElement> document.getElementById("userLoginStatus")).checked = this.checked(posts.locFetchedTO.loginStatus);
               (<HTMLInputElement> document.getElementById("userActive")).checked = this.checked(posts.locFetchedTO.userActive=='on'?'Y':'N');
               (<HTMLInputElement> document.getElementById("userId")).value = posts.locFetchedTO.usrId;
               (<HTMLInputElement> document.getElementById("userCreatedBy")).value = posts.locFetchedTO.createdByUId;
               (<HTMLInputElement> document.getElementById("userCreatedDtDisp")).value = posts.locFetchedTO.createdDtDisplZay;
             
           });
            activeModal.componentInstance.modalHeader = 'User Details';
        }else{
          alert('Please select a record to View');
        }
        }

    }
    searchUserInfo() {
      this.b.search(this.searchUserInfoUserName.nativeElement.value,
        this.searchUserInfoUserId.nativeElement.value,
        this.searchUserGroupIdSelected,
        this.searchUserInfoUserEmail.nativeElement.value,
        
      );
    }
     
    resetUserInfo() {
      this.b.reset();
      this.searchUserGroupNameSelected = '';
      this.searchUserGroupIdSelected ='';
    }

    checked(mode) {
      if (mode == 'Y'){
        return true;
      }else{ 
        return false;
      } 
   }

   
exportExcel(){
   

  this.service.exportUserManagementReportXL(this.searchUserInfoUserName.nativeElement.value,
    this.searchUserInfoUserId.nativeElement.value,
    this.searchUserGroupIdSelected,
    this.searchUserInfoUserEmail.nativeElement.value,).subscribe(posts =>{        
   

  window.open(posts.url+"?searchUserEmployeeName="+this.searchUserInfoUserName.nativeElement.value+ 
   "&searchUserName="+  this.searchUserInfoUserId.nativeElement.value+
   "&searchUserGroupId="+ this.searchUserGroupIdSelected+
   "&searchUserEmailId="+ this.searchUserInfoUserEmail.nativeElement.value+
   "&usrId="+JSON.parse(localStorage.getItem('currentUser')).usrId+"&userId="+JSON.parse(localStorage.getItem('currentUser')).userId+"&locationId="+JSON.parse(localStorage.getItem('currentUser')).locationId+"&locName="+JSON.parse(localStorage.getItem('currentUser')).locName
  +"&orgId="+JSON.parse(localStorage.getItem('currentUser')).orgId, '_blank', '');  
  });
}



    setCreateClickedRow = function(index,item){
    
   //console.log(item.menuName);
   if(item.createFlagDisplay == true){
     item.createFlagDisplay=false;
   }else{
     item.createFlagDisplay=true;
   }
  }
  setEditClickedRow = function(index,item){
    
   //console.log(item.menuName);
   if(item.updateFlagDisplay == true){
     item.updateFlagDisplay=false;
   }else{
     item.updateFlagDisplay=true;
   }
  }
  setViewClickedRow = function(index,item){
    
   //console.log(item.menuName);
   if(item.readFlagDisplay == true){
     item.readFlagDisplay=false;
   }else{
     item.readFlagDisplay=true;
   }
  }
  setDeleteClickedRow = function(index,item){
    
   //console.log(item.menuName);
   if(item.deleteFlagDisplay == true){
     item.deleteFlagDisplay=false;
   }else{
     item.deleteFlagDisplay=true;
   }
  }

  formGroupAccessSubmit(): void {
   //console.log(this.groupAccessData);
    this.service.saveGroupAccess(this.groupAccessGroupIdSelected,
     JSON.stringify(this.groupAccessData)
    ).subscribe(posts =>{
      //console.log(posts);
      if (posts.success == true) {
        this.resetGroupAccessValue();            
      } else if (posts.failure == true){
            alert(posts.message);
      }
  });
  }
}


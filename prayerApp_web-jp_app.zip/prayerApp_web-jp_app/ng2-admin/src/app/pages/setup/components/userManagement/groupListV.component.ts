import { Component } from '@angular/core';
import { LocalDataSource } from 'ng2-smart-table';
import { HttpModule } from '@angular/http';
import { UserManagementService } from '../../components/userManagement/userManagement.service';


@Component({
  selector: 'groupListV',
  templateUrl: './groupListV.html',
  styleUrls: ['./userManagementList.scss'],
})

export class GroupListV {
  public rowItem: JSON;
  public selectedRowGroupId: string ='';
  groupTableData:Array<any>;

  constructor(private service: UserManagementService) {
    
    this.service.getGroupNameList().subscribe(posts =>{
       //console.log(posts.listGroups);
          this.groupTableData = null;
        this.groupTableData =posts.listGroups;
    
    });
    
  }
setClickedRow = function(index,item){
    this.selectedRow = index;
    this.selectedRowGroupId = item.groupId;
    this.rowItem = item;
 }

 search(groupId) {
  this.service.searchGroupNameList(groupId).subscribe(posts => {
      this.groupTableData = null;
      this.groupTableData = posts.listGroups;
  });
}

reset() {
  this.service.getGroupNameList().subscribe(posts => {
      this.groupTableData = null;
      this.groupTableData = posts.listGroups;
  });
}
}
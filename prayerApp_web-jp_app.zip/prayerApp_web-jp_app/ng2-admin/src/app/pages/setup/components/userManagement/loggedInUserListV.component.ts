import { Component } from '@angular/core';
import { LocalDataSource } from 'ng2-smart-table';
import { HttpModule } from '@angular/http';
import { UserManagementService } from '../../components/userManagement/userManagement.service';


@Component({
  selector: 'loggedInUserListV',
  templateUrl: './loggedInUserListV.html',
  styleUrls: ['./userManagementList.scss'],
})

export class LoggedInUserListV {
  public rowItem: JSON;
  
  query: string = '';
  smartTableData:Array<any>;

  constructor(private service: UserManagementService) {
    
    this.service.getLoggedInUserList().subscribe(posts =>{
       //console.log(posts.loggedInUserList);
      this.smartTableData = null;
      //setTimeout(() => {
        this.smartTableData =posts.loggedInUserList;
      //}, 3000);
    
    });
    
  }
setClickedRow = function(index,item){
    this.selectedRow = index;
    this.rowItem = item;
    
    //alert(item.locName);
    //console.log(index,item.locName);
 }
}
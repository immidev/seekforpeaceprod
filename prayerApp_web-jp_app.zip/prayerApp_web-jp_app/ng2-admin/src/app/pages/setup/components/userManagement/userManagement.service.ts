import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';
import { HttpModule } from '@angular/http';
import * as MasterConstants from '../../../masterconstants'; //<==== this one
import { Headers, Response, URLSearchParams } from '@angular/http';

@Injectable()
export class UserManagementService {
  constructor(private http: Http) {
    //console.log('initialized');
}
  
  userGroupAccess(moduleName){
    var headers = new Headers();
    headers.append('Content-Type', 'application/x-www-form-urlencoded');
    let urlSearchParams = new URLSearchParams();
    urlSearchParams.append('moduleName', moduleName);
    urlSearchParams.append('userTO', localStorage.getItem('currentUser'));
    let body = urlSearchParams.toString();
  
    return this.http.post(MasterConstants.WEB_URL + 'userGroupAccess', body, {headers: headers}).map(res => res.json());
  
   }
 
   getLoggedInUserList(){
    var headers = new Headers();
    headers.append('Content-Type', 'application/x-www-form-urlencoded');
    let urlSearchParams = new URLSearchParams();
    urlSearchParams.append('userTO', localStorage.getItem('currentUser'));
    let body = urlSearchParams.toString();
  
    return this.http.post(MasterConstants.WEB_URL + 'getLoggedInUserList', body, {headers: headers}).map(res => res.json());
  
   }

   getGroupNameCombo(){
    var headers = new Headers();
    headers.append('Content-Type', 'application/x-www-form-urlencoded');
    let urlSearchParams = new URLSearchParams();
    urlSearchParams.append('groupId', JSON.parse(localStorage.getItem('currentUser')).groupId);
    urlSearchParams.append('locId', JSON.parse(localStorage.getItem('currentUser')).locationId);
    urlSearchParams.append('userTO', localStorage.getItem('currentUser'));
    let body = urlSearchParams.toString();

    return this.http.post(MasterConstants.WEB_URL + 'getUserGroups', body, {headers: headers}).map(res => res.json());
  }
  getClaimDesignation(){
    var headers = new Headers();
    headers.append('Content-Type', 'application/x-www-form-urlencoded');
    let urlSearchParams = new URLSearchParams();
    urlSearchParams.append('groupId', JSON.parse(localStorage.getItem('currentUser')).groupId);
    urlSearchParams.append('locId', JSON.parse(localStorage.getItem('currentUser')).locationId);
    urlSearchParams.append('userTO', localStorage.getItem('currentUser'));
    let body = urlSearchParams.toString();

    return this.http.post(MasterConstants.WEB_URL + 'getClaimDesignation', body, {headers: headers}).map(res => res.json());
  }
  
  getGroupNameList(){
    var headers = new Headers();
    headers.append('Content-Type', 'application/x-www-form-urlencoded');
    let urlSearchParams = new URLSearchParams();
    urlSearchParams.append('userTO', localStorage.getItem('currentUser'));
    let body = urlSearchParams.toString();

    return this.http.post(MasterConstants.WEB_URL + 'getGroups', body, {headers: headers}).map(res => res.json());
  }

  searchGroupNameList(groupId){
    var headers = new Headers();
    headers.append('Content-Type', 'application/x-www-form-urlencoded');
    let urlSearchParams = new URLSearchParams();
    urlSearchParams.append('searchGroupGroupId', groupId);
    urlSearchParams.append('userTO', localStorage.getItem('currentUser'));
    let body = urlSearchParams.toString();

    return this.http.post(MasterConstants.WEB_URL + 'getGroups', body, {headers: headers}).map(res => res.json());
  }

  addGroup(groupId,groupName,groupFnMode,createdByUId,createdDtDisplay,groupLocationId,menuListData){
    var headers = new Headers();
    headers.append('Content-Type', 'application/x-www-form-urlencoded');
    let urlSearchParams = new URLSearchParams();
    urlSearchParams.append('groupId', groupId);
    urlSearchParams.append('groupName', groupName);
    urlSearchParams.append('groupFnMode', groupFnMode);
    urlSearchParams.append('createdByUId', createdByUId);
    urlSearchParams.append('createdDtDisplay', createdDtDisplay);
    urlSearchParams.append('groupLocationId', groupLocationId);
    urlSearchParams.append('data', menuListData);
    urlSearchParams.append('userTO', localStorage.getItem('currentUser'));
    let body = urlSearchParams.toString();

    return this.http.post(MasterConstants.WEB_URL + 'addGroup', body, {headers: headers}).map(res => res.json());
  }

  loadGroupDetailedInfo(groupId){
    var headers = new Headers();
    headers.append('Content-Type', 'application/x-www-form-urlencoded');
    let urlSearchParams = new URLSearchParams();
    urlSearchParams.append('groupId', groupId);
    urlSearchParams.append('userTO', localStorage.getItem('currentUser'));
    let body = urlSearchParams.toString();
    return this.http.post(MasterConstants.WEB_URL + 'loadGroupDetailedInfo', body, {headers: headers}).map(res => res.json());
  }

  //user details
  getUsersList(){
    var headers = new Headers();
    headers.append('Content-Type', 'application/x-www-form-urlencoded');
    let urlSearchParams = new URLSearchParams();
    urlSearchParams.append('userTO', localStorage.getItem('currentUser'));
    let body = urlSearchParams.toString();

    return this.http.post(MasterConstants.WEB_URL + 'getUsers', body, {headers: headers}).map(res => res.json());
  }

  getMenusList(groupId,groupLocationId){
    var headers = new Headers();
    headers.append('Content-Type', 'application/x-www-form-urlencoded');
    let urlSearchParams = new URLSearchParams();
    urlSearchParams.append('groupId', groupId);
    urlSearchParams.append('groupLocationId',groupLocationId);
    urlSearchParams.append('userTO', localStorage.getItem('currentUser'));
    let body = urlSearchParams.toString();

    return this.http.post(MasterConstants.WEB_URL + 'getGroupMenu', body, {headers: headers}).map(res => res.json());
  }

  searchUsersList(username,userId,groupId,emailId){
    var headers = new Headers();
    headers.append('Content-Type', 'application/x-www-form-urlencoded');
    let urlSearchParams = new URLSearchParams();
    urlSearchParams.append('searchUserEmployeeName', username);
    urlSearchParams.append('searchUserName', userId);
    urlSearchParams.append('searchUserGroupId', groupId);
    urlSearchParams.append('searchUserEmailId', emailId);
    urlSearchParams.append('userTO', localStorage.getItem('currentUser'));
    let body = urlSearchParams.toString();

    return this.http.post(MasterConstants.WEB_URL + 'getUsers', body, {headers: headers}).map(res => res.json());
  }

  listOfAllLanguageCombo(){
    var headers = new Headers();
    headers.append('Content-Type', 'application/x-www-form-urlencoded');
    let urlSearchParams = new URLSearchParams();
    urlSearchParams.append('userTO', localStorage.getItem('currentUser'));
    let body = urlSearchParams.toString();

    return this.http.post(MasterConstants.WEB_URL + 'listOfAllLanguageCombo', body, {headers: headers}).map(res => res.json());

  }

  getCountryLists(){
    var headers = new Headers();
    headers.append('Content-Type', 'application/x-www-form-urlencoded');
    let urlSearchParams = new URLSearchParams();
    urlSearchParams.append('groupId', JSON.parse(localStorage.getItem('currentUser')).groupId);
    urlSearchParams.append('userTO', localStorage.getItem('currentUser'));
    let body = urlSearchParams.toString();
    return this.http.post(MasterConstants.WEB_URL + 'getCountryLists', body, {headers: headers}).map(res => res.json());
  
  }

  getRepotingToCombo(){ 
    var headers = new Headers();
    headers.append('Content-Type', 'application/x-www-form-urlencoded');
    let urlSearchParams = new URLSearchParams();
    urlSearchParams.append('userTO', localStorage.getItem('currentUser'));
    let body = urlSearchParams.toString(); 
     return this.http.post(MasterConstants.WEB_URL + 'getRepotingToCombo', body, {headers: headers}).map(res => res.json());
    }


  addUser(userId,userEmployeeName,userLocNameId,userActive,userAddress,userContactEmail,userContactCcEmail,userUserId,userPassword,userGroupNameId,userAccountLocked,
    userLoginStatus,userFnMode,userCreatedBy,userCreatedDtDisp,userLanguage,userLanguageCode,userCountryCode,
    userZone,userContactMobileNo,userCountry,userGmtTimeDiff,userEmployeeId,userDoj,userDesignation,userAge,
    startTime,endTime,reportingTo

  ){

    console.log(userAddress);
    console.log(userEmployeeId);
    console.log(userDoj);
    console.log(userDesignation);
    console.log(userAge);
    var headers = new Headers();
    headers.append('Content-Type', 'application/x-www-form-urlencoded');
    let urlSearchParams = new URLSearchParams();
    urlSearchParams.append('userId', userId);
    urlSearchParams.append('userEmployeeName', userEmployeeName);
    urlSearchParams.append('userLocNameId', userLocNameId);
    urlSearchParams.append('userActive', userActive);
    urlSearchParams.append('userAddress', userAddress);
    urlSearchParams.append('userContactEmail', userContactEmail);
    urlSearchParams.append('userContactCcEmail', userContactCcEmail);
    urlSearchParams.append('userUserId', userUserId);
    urlSearchParams.append('userPassword', userPassword);
    urlSearchParams.append('userGroupNameId', userGroupNameId);
    urlSearchParams.append('userAccountLocked', userAccountLocked);
    urlSearchParams.append('userLoginStatus', userLoginStatus);
    urlSearchParams.append('userFnMode', userFnMode);
    urlSearchParams.append('userCreatedBy', userCreatedBy);
    urlSearchParams.append('userCreatedDtDisp', userCreatedDtDisp);
    urlSearchParams.append('userLanguage', userLanguage);
    urlSearchParams.append('userLanguageCode', userLanguageCode);
    urlSearchParams.append('userCountryCode', userCountryCode);
    urlSearchParams.append('userZone', userZone);
    urlSearchParams.append('userContactMobileNo', userContactMobileNo);
    urlSearchParams.append('userCountry', userCountry);
    urlSearchParams.append('userGmtTimeDiff', userGmtTimeDiff);
    
    urlSearchParams.append('userDoj', userDoj);
    urlSearchParams.append('userAge', userAge);

    urlSearchParams.append('startTime', startTime);
    urlSearchParams.append('endTime', endTime);
    urlSearchParams.append('reportingTo', reportingTo);


    urlSearchParams.append('userDesignation', userDesignation);
    urlSearchParams.append('userEmployeeId', userEmployeeId);
    urlSearchParams.append('userTO', localStorage.getItem('currentUser'));
    let body = urlSearchParams.toString();

    return this.http.post(MasterConstants.WEB_URL + 'addUser', body, {headers: headers}).map(res => res.json());
  }
 
  loadUserDetailedInfo(usrId){
    var headers = new Headers();
    headers.append('Content-Type', 'application/x-www-form-urlencoded');
    let urlSearchParams = new URLSearchParams();
    urlSearchParams.append('usrId', usrId);
    urlSearchParams.append('userTO', localStorage.getItem('currentUser'));
    let body = urlSearchParams.toString();
    return this.http.post(MasterConstants.WEB_URL + 'loadUserDetailedInfo', body, {headers: headers}).map(res => res.json());
  
  }

  getGroupModules(groupId){
    if(groupId =="" || typeof groupId =="undefined"){
      groupId='0';
    }
    var headers = new Headers();
    headers.append('Content-Type', 'application/x-www-form-urlencoded');
    let urlSearchParams = new URLSearchParams();
    urlSearchParams.append('groupId', groupId);
    urlSearchParams.append('userTO', localStorage.getItem('currentUser'));
    let body = urlSearchParams.toString();
    return this.http.post(MasterConstants.WEB_URL + 'getGroupModules', body, {headers: headers}).map(res => res.json());

  }

  saveGroupAccess(groupAccessGroupId,data){
    var headers = new Headers();
    headers.append('Content-Type', 'application/x-www-form-urlencoded');
    let urlSearchParams = new URLSearchParams();
    urlSearchParams.append('groupAccessGroupId', groupAccessGroupId);
    urlSearchParams.append('data', data);
    urlSearchParams.append('userTO', localStorage.getItem('currentUser'));
    let body = urlSearchParams.toString();
    return this.http.post(MasterConstants.WEB_URL + 'saveGroupAccess', body, {headers: headers}).map(res => res.json());

  }

  
 exportUserManagementReportXL(username,userId,groupId,emailId) {
  var headers = new Headers();
  headers.append('Content-Type', 'application/x-www-form-urlencoded');
  let urlSearchParams = new URLSearchParams();
 
  urlSearchParams.append('generateURL','true');
  urlSearchParams.append('searchUserEmployeeName', username);
  urlSearchParams.append('searchUserName', userId);
  urlSearchParams.append('searchUserGroupId', groupId);
  urlSearchParams.append('searchUserEmailId', emailId);
  urlSearchParams.append('usrId', JSON.parse(localStorage.getItem('currentUser')).usrId);
  urlSearchParams.append('userId', JSON.parse(localStorage.getItem('currentUser')).userId);
  urlSearchParams.append('locationId', JSON.parse(localStorage.getItem('currentUser')).locationId);
  urlSearchParams.append('locName', JSON.parse(localStorage.getItem('currentUser')).locName);
  urlSearchParams.append('orgId', JSON.parse(localStorage.getItem('currentUser')).orgId);
  //urlSearchParams.append('userTO', localStorage.getItem('currentUser'));
  let body = urlSearchParams.toString();
  
  return this.http.post(MasterConstants.WEB_URL + 'exportUserReportXL', body, {headers: headers}).map(res => res);

}
}
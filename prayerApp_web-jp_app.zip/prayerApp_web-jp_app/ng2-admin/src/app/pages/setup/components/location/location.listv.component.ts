import { Component } from '@angular/core';
import { LocalDataSource } from 'ng2-smart-table';
import { HttpModule } from '@angular/http';
import { LocationService } from 'app/pages/setup/components/location/location.service';


@Component({
  selector: 'locationlistv',
  templateUrl: './location.listv.html',
  styleUrls: ['./location.scss'],
})

export class LocationListV {
  public locationIdVal: string ='';
  public rowItem: JSON;
  
  query: string = '';
  smartTableData:Array<any>;

  constructor(private _basicTablesService: LocationService) {
    this._basicTablesService.getLocationsList().subscribe(posts =>{
        this.smartTableData =posts.listLocation;
        
    });
    
  }

  
  setClickedRow = function(index,item){
    this.selectedRow = index;
    this.locationIdVal = item.locId;
    this.rowItem = item;
    
    //alert(item.locName);
    //console.log(index,item.locName);
 }
}

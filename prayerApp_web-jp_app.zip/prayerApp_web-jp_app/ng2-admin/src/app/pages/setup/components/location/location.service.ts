import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';
import { HttpModule } from '@angular/http';
import * as MasterConstants from '../../../masterconstants'; //<==== this one
import { Headers, Response, URLSearchParams } from '@angular/http';

@Injectable()
export class LocationService {
  constructor(private http: Http) {
    //console.log('initialized');
  }
  
  userGroupAccess(moduleName){
    var headers = new Headers();
    headers.append('Content-Type', 'application/x-www-form-urlencoded');
    let urlSearchParams = new URLSearchParams();
    urlSearchParams.append('moduleName', moduleName);
    urlSearchParams.append('userTO', localStorage.getItem('currentUser'));
    let body = urlSearchParams.toString();
  
    return this.http.post(MasterConstants.WEB_URL + 'userGroupAccess', body, {headers: headers}).map(res => res.json());
  
   }
   
  getLocationsList() {
    var headers = new Headers();
    headers.append('Content-Type', 'application/x-www-form-urlencoded');
    let urlSearchParams = new URLSearchParams();
    urlSearchParams.append('userTO', localStorage.getItem('currentUser'));
    let body = urlSearchParams.toString();
  
    return this.http.post(MasterConstants.WEB_URL + 'getLocationsList', body, {headers: headers}).map(res => res.json());
 }

 
 saveOrUpdateLocationInfo(locationName,locationId,createdBy,createdDate,mode,address,
  zipcode,city,telno,state,faxno,country,smtpservername,password,popservername,popaccountid,
  adminemail,smtpport,orgId,orgName,locType,description){

    let params = '?'; 
    var headers = new Headers();
    headers.append('Content-Type', 'application/x-www-form-urlencoded');
    let urlSearchParams = new URLSearchParams();
    urlSearchParams.append('locName', locationName);
    urlSearchParams.append('locId',locationId);
    urlSearchParams.append('locOrgNameId',orgId);
    urlSearchParams.append('locOrgName',orgName);
    urlSearchParams.append('locType',locType);
    urlSearchParams.append('locDesc',description);
    urlSearchParams.append('locCreatedBy',createdBy);
    urlSearchParams.append('locCreatedDtDisplay',createdDate);
    urlSearchParams.append('locationFnMode',mode);
    urlSearchParams.append('locAddress1',address);
    urlSearchParams.append('locCity',city);
    urlSearchParams.append('locState',state);
    urlSearchParams.append('locZip',zipcode);
    urlSearchParams.append('locTelno',telno);
    urlSearchParams.append('locFaxno',faxno);
    urlSearchParams.append('locCountry',country);
    
    urlSearchParams.append('smtpServerName',smtpservername);
    urlSearchParams.append('popServerName',popservername);
    urlSearchParams.append('popAccountId',popaccountid);
    urlSearchParams.append('popAccountPwd',password);
    urlSearchParams.append('adminEmailId',adminemail);
    urlSearchParams.append('locSmtpPort',smtpport);

    urlSearchParams.append('userTO',localStorage.getItem('currentUser')); 
    let body = urlSearchParams.toString(); 
    return this.http.post(MasterConstants.WEB_URL + 'saveLocation', body, {headers: headers})
    .map(res => res.json());    
          


  }

}
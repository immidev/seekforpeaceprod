
export class RegionCombo {
    constructor(public id: number, public regionName: string) { }
  }
  
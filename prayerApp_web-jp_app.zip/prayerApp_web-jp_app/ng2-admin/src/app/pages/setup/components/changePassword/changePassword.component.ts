import { Component } from '@angular/core';
import { HttpModule } from '@angular/http';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ChangePasswordService } from 'app/pages/setup/components/changePassword/changePassword.service';
import {ViewChild, ContentChild, Host, Inject, forwardRef,ElementRef} from '@angular/core'

@Component({
  selector: 'changePassword',
  templateUrl: './changePasswordMain.html'
  
})
export class ChangePassword {
 
  constructor( private service: ChangePasswordService) {
  }

  ngOnInit() {}
  
  @ViewChild('cpOldPassword') cpOldPassword: ElementRef;
  @ViewChild('cpNewPassword') cpNewPassword: ElementRef;
  @ViewChild('cpConfirmNewPassword') cpConfirmNewPassword: ElementRef;

  formSubmit(): void {
   
    if(this.cpNewPassword.nativeElement.value == this.cpConfirmNewPassword.nativeElement.value){
      this.service.updatePassword(this.cpOldPassword.nativeElement.value,
        this.cpNewPassword.nativeElement.value,
        this.cpConfirmNewPassword.nativeElement.value
      ).subscribe(posts => {
        //console.log(posts);
        this.resetValue();
      });
    }
    else{
      alert("New Password and Confirm New Password are mismatched!");
    }
 
 }

 resetValue(){
  this.cpOldPassword.nativeElement.value='';
  this.cpNewPassword.nativeElement.value='';
  this.cpConfirmNewPassword.nativeElement.value='';
 }


}
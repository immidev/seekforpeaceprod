import { Component, Input,OnInit, Inject, ViewChild, ElementRef, AfterViewInit } from '@angular/core';

import { LocalDataSource } from 'ng2-smart-table';
import { NgbActiveModal ,NgbDateStruct} from '@ng-bootstrap/ng-bootstrap';
import { UserManagementService } from '../../components/userManagement/userManagement.service';
import {RegionCombo } from 'app/pages/setup/components/userManagement/regionCombo';
import { Router } from '@angular/router';

@Component({
  selector: 'userInfoVW',
  templateUrl: './userInfoVW.html',
  styleUrls: ['./userManagement.scss'],
})
export class UserInfoVW  implements OnInit {

  @Input('locAddress') locAdd: string;
  
query: string = '';
    
  modalHeader: string;
  modalContent: string = `Lorem ipsum dolor sit amet,
   consectetuer adipiscing elit, sed diam nonummy
   nibh euismod tincidunt ut laoreet dolore magna aliquam
   erat volutpat. Ut wisi enim ad minim veniam, quis
   nostrud exerci tation ullamcorper suscipit lobortis
   nisl ut aliquip ex ea commodo consequat.`;

   userLanguageSelected: string;
   userLanguageCodeSelected: string;
   userCountryCodeSelected: string;
   languageCombo: any[] = [ ];

   userGroupNameSelected: string;
   userGroupIdSelected: string;
   userGroupNameCombo: any[] = [ ];
   
   userCountrySelected: string;
   userGmtTimeDiffSelected: string;
   userCountryCombo: any[] = [ ];
   
     public userGroupNameComboVal={groupName: ''};
     public userLanguageComboVal= {language: ''};
     public userCountryNameComboVal={countryName: ''};

   regionList = [  
    new RegionCombo(1, 'NORTH REGION' ),
    new RegionCombo(2, 'SOUTH REGION' ), 
    new RegionCombo(3, 'WEST REGION' ), 
    new RegionCombo(4, 'EAST REGION' ), 
    new RegionCombo(5, 'NORTH EAST REGION' ), 
    new RegionCombo(6, 'NORTH WEST REGION' ), 
    new RegionCombo(7, 'SOUTH WEST REGION' ), 
    new RegionCombo(8, 'SOUTH EAST REGION' ), 
  ]; 
  password_dynamic="";
  employeeCodeList;


  constructor(private activeModal: NgbActiveModal, protected service: UserManagementService) {
    //constructor(private activeModal: NgbActiveModal, protected service: UserManagementService, private router: Router) {
     console.log('---------------'); 
    console.log(localStorage.getItem('passwordfield_dynamic'));
    console.log('---------------');
    if(localStorage.getItem('passwordfield_dynamic').toString() == 'ADMINISTRATOR'){
         this.password_dynamic ="text";
     }else{
         this.password_dynamic ="password"; 
     }
    this.service.listOfAllLanguageCombo().subscribe(posts => {
        this.languageCombo = posts.languageList;
    });

    this.service.getGroupNameCombo().subscribe(posts => {
        this.userGroupNameCombo = posts.userGroupsList;
    });

    this.service.getCountryLists().subscribe(posts => {
        this.userCountryCombo = posts.countryListCombo;
    });

    this.service.getRepotingToCombo().subscribe(posts => {
      this.employeeCodeList =     posts.repotingToComboList;
    }); 

  }

  ngOnInit() {}
  
  @ViewChild('userLocationName') userLocationName: ElementRef;
  @ViewChild('userLocNameId') userLocNameId: ElementRef;
  @ViewChild('userGroupName') userGroupName: ElementRef;
  @ViewChild('userName') userName: ElementRef;
  @ViewChild('userGroupNameId') userGroupNameId: ElementRef;
  @ViewChild('userUserName') userUserName: ElementRef;
  @ViewChild('userPassword') userPassword: ElementRef;
  @ViewChild('userAddress') userAddress: ElementRef;
  @ViewChild('userContactMobileNo') userContactMobileNo: ElementRef;
  @ViewChild('userContactEmail') userContactEmail: ElementRef;
  @ViewChild('userContactCcEmail') userContactCcEmail: ElementRef;
  @ViewChild('userLanguage') userLanguage: ElementRef;
  @ViewChild('userCountry') userCountry: ElementRef;
  @ViewChild('userZone') userZone: ElementRef;
  @ViewChild('userCountryCode') userCountryCode: ElementRef;
  @ViewChild('userGmtTimeDiff') userGmtTimeDiff: ElementRef;
  @ViewChild('userLanguageCode') userLanguageCode: ElementRef;
  @ViewChild('userAccountLocked') userAccountLocked: ElementRef;
  @ViewChild('userLoginStatus') userLoginStatus: ElementRef;
  @ViewChild('userActive') userActive: ElementRef;
  
  @ViewChild('userId') userId: ElementRef;
  @ViewChild('userCreatedBy') userCreatedBy: ElementRef;
  @ViewChild('userCreatedDtDisp') userCreatedDtDisp: ElementRef;
  @ViewChild('userFnMode') userFnMode: ElementRef;
  
  //sales person
  @ViewChild('userDoj') userDoj: ElementRef;
  @ViewChild('userDesignation') userDesignation: ElementRef;
  @ViewChild('userEmpID') userEmpID: ElementRef;
  @ViewChild('userAge') userAge: ElementRef;


  @ViewChild('startTime') startTime: ElementRef;
  @ViewChild('endTime') endTime: ElementRef;
  @ViewChild('reportingTo') reportingTo: ElementRef;


  public itemLanguageSelected(list) {
    this.userLanguageSelected = list ? list.language : '';
    this.userLanguageCodeSelected = list ? list.languageCode : '';
    this.userCountryCodeSelected = list ? list.countryCode : '';
       (<HTMLInputElement> document.getElementById("userLanguageCode")).value = this.userLanguageCodeSelected;
       (<HTMLInputElement> document.getElementById("userCountryCode")).value = this.userCountryCodeSelected;
  }

  public itemGroupSelected(list){
    this.userGroupNameSelected = list ? list.groupName : '';
    this.userGroupIdSelected = list ? list.groupId : '';
        (<HTMLInputElement> document.getElementById("userGroupNameId")).value = this.userGroupIdSelected;
        if(this.userGroupIdSelected =='5'){
          (<HTMLInputElement> document.getElementById("userZone")).disabled = false;
        }else{
          (<HTMLInputElement> document.getElementById('userZone')).disabled = true;
          (<HTMLInputElement> document.getElementById('userZone')).style.borderColor='#C0C0C0';
        }
  }
  public itemCountrySelected(list){
    this.userCountrySelected = list ? list.countryName : '';
    this.userGmtTimeDiffSelected = list ? list.gmtTimeDiff : '';
    (<HTMLInputElement> document.getElementById("userGmtTimeDiff")).value = list ? list.gmtTimeDiff : '';
  }
  
  closeModal() {
    this.activeModal.close();
    //this.router.navigate(['userManagement']);  
  }

  clearUserModal(){
    this.userLocationName.nativeElement.value= JSON.parse(localStorage.getItem('currentUser')).locName;
    this.userLocNameId.nativeElement.value=JSON.parse(localStorage.getItem('currentUser')).locationId;
    
    this.userId.nativeElement.value=0;
    this.userName.nativeElement.value='';
    this.userLocNameId.nativeElement.value='';
    this.userActive.nativeElement.value='';
    this.userAddress.nativeElement.value='';
    this.userContactEmail.nativeElement.value='';
    this.userContactCcEmail.nativeElement.value='';
    this.userUserName.nativeElement.value='';
    this.userPassword.nativeElement.value='';
    this.userGroupNameId.nativeElement.value='0';
    this.userAccountLocked.nativeElement.value='';
    this.userLoginStatus.nativeElement.value='';
    this.userFnMode.nativeElement.value='a';
    this.userCreatedBy.nativeElement.value='';
    this.userCreatedDtDisp.nativeElement.value='';
    this.userLanguageCode.nativeElement.value='';
    this.userCountryCode.nativeElement.value='';
    this.userZone.nativeElement.value='';
    this.userContactMobileNo.nativeElement.value='';

    this.userGroupNameComboVal={groupName: ''};
    this.userLanguageComboVal={language: ''};
    this.userCountryNameComboVal={countryName: ''};
    this.userCountrySelected='';
    this.userGroupNameSelected='';
    this.userLanguageSelected='';
    this.userGmtTimeDiff.nativeElement.value='';
    
    this.userAge.nativeElement.value='';
    this.userDesignation.nativeElement.value='';
    this.userEmpID.nativeElement.value='';
    this.userDoj.nativeElement.value='';

    this.startTime.nativeElement.value='';
    this.endTime.nativeElement.value='';
    this.reportingTo.nativeElement.value='';
  }
  


  saveUserInfo(){
    var activeElement = <HTMLInputElement> document.getElementById("userActive");
    var isActiveChecked = activeElement.checked; 
    if(isActiveChecked){
        this.userActive.nativeElement.value = 'on';
    }else{
        this.userActive.nativeElement.value = 'off';
    }

    var accountLockElement = <HTMLInputElement> document.getElementById("userAccountLocked");
    var isAccountLockChecked = accountLockElement.checked; 
    if(isAccountLockChecked){
        this.userAccountLocked.nativeElement.value = 'on';
    }else{
        this.userAccountLocked.nativeElement.value = 'off';
    }

    var loginStatusElement = <HTMLInputElement> document.getElementById("userLoginStatus");
    var isLoginStatusChecked = loginStatusElement.checked; 
    if(isLoginStatusChecked){
        this.userLoginStatus.nativeElement.value = 'on';
    }else{
        this.userLoginStatus.nativeElement.value = 'off';
    }
  
    // console.log(this.userGroupNameId.nativeElement.value);
    // console.log(this.userLanguageCode.nativeElement.value);
    // console.log(this.userCountryCode.nativeElement.value);
    // console.log(this.userGmtTimeDiff.nativeElement.value);
    

   
    this.service.addUser(this.userId.nativeElement.value,
        this.userName.nativeElement.value,
        this.userLocNameId.nativeElement.value,
        this.userActive.nativeElement.value,
        this.userAddress.nativeElement.value,
        this.userContactEmail.nativeElement.value,
        this.userContactCcEmail.nativeElement.value,
        this.userUserName.nativeElement.value,
        this.userPassword.nativeElement.value,
        this.userGroupNameId.nativeElement.value,
        this.userAccountLocked.nativeElement.value,
        this.userLoginStatus.nativeElement.value,
        this.userFnMode.nativeElement.value,
        this.userCreatedBy.nativeElement.value,
        this.userCreatedDtDisp.nativeElement.value,
        this.userLanguageSelected,
        this.userLanguageCode.nativeElement.value,
        this.userCountryCode.nativeElement.value,
        this.userZone.nativeElement.value,
        this.userContactMobileNo.nativeElement.value,
        this.userCountrySelected,
        this.userGmtTimeDiff.nativeElement.value,
        this.userEmpID.nativeElement.value,
        this.userDoj.nativeElement.value,
        this.userDesignation.nativeElement.value,
        this.userAge.nativeElement.value,

        this.startTime.nativeElement.value,
        this.endTime.nativeElement.value,
        this.reportingTo.nativeElement.value,

        
      ).subscribe(posts =>{
        //console.log(posts);
        if (posts.success == true) {
    
          if(this.userFnMode.nativeElement.value=='e'){
            this.closeModal();            
          }else{
            (<HTMLInputElement> document.getElementById("success_msg")).style.display = 'block';
            (<HTMLInputElement> document.getElementById("success_msg")).innerHTML = 'User Added Successfully';
            this.clearUserModal();
          }
        } else if (posts.failure == true){
              alert(posts.message);
        }
    });
      
  }
   

}

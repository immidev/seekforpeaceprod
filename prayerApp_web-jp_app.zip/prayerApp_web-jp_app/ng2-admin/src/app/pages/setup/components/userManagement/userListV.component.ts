import { Component } from '@angular/core';
import { LocalDataSource } from 'ng2-smart-table';
import { HttpModule } from '@angular/http';
import { UserManagementService } from '../../components/userManagement/userManagement.service';


@Component({
  selector: 'userListV',
  templateUrl: './userListV.html',
  styleUrls: ['./userManagementList.scss'],
})

export class UserListV {
  public rowItem: JSON;
  public selectedRowUserId: string ='';
  userTableData:Array<any>;
  public selectedRowGroupName :String='';

  constructor(private service: UserManagementService) {
    
    this.service.getUsersList().subscribe(posts =>{
       //console.log(posts.usersList);
          this.userTableData = null;
        this.userTableData =posts.usersList;
    
    });
    
  }
setClickedRow = function(index,item){
    this.selectedRow = index;
    this.selectedRowUserId = item.usrId;
    this.selectedRowGroupName = item.groupName;
    
    this.rowItem = item;
 }

 search(username,userId,groupId,emailId) {
  this.service.searchUsersList(username,userId,groupId,emailId).subscribe(posts => {
      this.userTableData = null;
      this.userTableData = posts.usersList;
  });
}

reset() {
  this.service.getUsersList().subscribe(posts => {
      this.userTableData = null;
      this.userTableData = posts.usersList;
  });
}

calculateStyle(test){
  let style='';
  if (test.Status == 'Y') {
    style='color:#000000';
  }
  return style;
}
}
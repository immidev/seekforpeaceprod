import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';
import { HttpModule } from '@angular/http';
import * as MasterConstants from '../../../masterconstants'; //<==== this one
import { Headers, Response, URLSearchParams } from '@angular/http';

@Injectable()
export class ChangePasswordService {

  constructor(private http: Http) {
    //console.log('initialized');
  }

  updatePassword(oldPassword,newPassword,confirmNewPassword){

        let params = '?'; 
      var headers = new Headers();
      headers.append('Content-Type', 'application/x-www-form-urlencoded');
      let urlSearchParams = new URLSearchParams();
      urlSearchParams.append('oldPassword', oldPassword);
      urlSearchParams.append('newPassword',newPassword);
      urlSearchParams.append('confirmNewPassword',confirmNewPassword);
      urlSearchParams.append('userTO',localStorage.getItem('currentUser')); 
      let body = urlSearchParams.toString(); 
      return this.http.post(MasterConstants.WEB_URL + 'updatePassword', body, {headers: headers})
          .map((response: Response) => {
              let user = response.json();
              //console.log(user);
              if (user.success == true) {
                  alert("Password Changed Successfully");
              }else if (user.failure == true){
                    alert(user.message);
              }
          }); 

    }
}
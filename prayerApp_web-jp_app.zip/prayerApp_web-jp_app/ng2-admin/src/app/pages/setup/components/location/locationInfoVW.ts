import { Component, Input,OnInit, Inject, ViewChild, ElementRef, AfterViewInit } from '@angular/core';

import { LocalDataSource } from 'ng2-smart-table';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { LocationService } from 'app/pages/setup/components/location/location.service';
import { LocationListV } from 'app/pages/setup/components/location/location.listv.component';

@Component({
  selector: 'locationInfoVW',
  templateUrl: './locationInfoVW.html',
  styleUrls: ['./location.scss'],
})
export class LocationInfoVW  implements OnInit {

  @Input('locAddress') locAdd: string;
  
query: string = '';
  modalHeader: string;
  modalContent: string = `Lorem ipsum dolor sit amet,
   consectetuer adipiscing elit, sed diam nonummy
   nibh euismod tincidunt ut laoreet dolore magna aliquam
   erat volutpat. Ut wisi enim ad minim veniam, quis
   nostrud exerci tation ullamcorper suscipit lobortis
   nisl ut aliquip ex ea commodo consequat.`;

  constructor(private activeModal: NgbActiveModal, protected service: LocationService) {
  }

  ngOnInit() {}
  
  @ViewChild('locationName') locationName: ElementRef;
  @ViewChild('locationId') locationId: ElementRef;
  @ViewChild('locCreatedBy') locCreatedBy: ElementRef;
  @ViewChild('locCreatedDate') locCreatedDate: ElementRef;
  @ViewChild('locFnMode') locFnMode: ElementRef;
  @ViewChild('locAddress') locAddress: ElementRef;
  @ViewChild('locZipcode') locZipcode: ElementRef;
  @ViewChild('locCity') locCity: ElementRef;
  @ViewChild('locTelNo') locTelNo: ElementRef;
  @ViewChild('locState') locState: ElementRef;
  @ViewChild('locFaxNo') locFaxNo: ElementRef;
  @ViewChild('locCountry') locCountry: ElementRef;
  @ViewChild('locSmtpServerName') locSmtpServerName: ElementRef;
  @ViewChild('locConfirmPassword') locConfirmPassword: ElementRef;
  @ViewChild('locPopServerName') locPopServerName: ElementRef;
  @ViewChild('locAdminEmail') locAdminEmail: ElementRef;
  @ViewChild('locPopAccountId') locPopAccountId: ElementRef;
  @ViewChild('locSmtpPort') locSmtpPort: ElementRef;
  @ViewChild('locPopAccountPassword') locPopAccountPassword: ElementRef;

  @ViewChild('locOracleOrgId') locOracleOrgId: ElementRef;
  @ViewChild('locationType') locationType: ElementRef;
  @ViewChild('orgName') orgName: ElementRef;
  @ViewChild('description') description: ElementRef;
  
  
  closeModal() {
    this.activeModal.close();
  }

  clearModal(){
    this.locationName.nativeElement.value='';
    this.locationId.nativeElement.value=0;
    this.locCreatedBy.nativeElement.value='';
    this.locCreatedDate.nativeElement.value='';
    this.locFnMode.nativeElement.value='';
    this.locAddress.nativeElement.value='';
    this.locZipcode.nativeElement.value='';
    this.locCity.nativeElement.value='';
    this.locTelNo.nativeElement.value='';
    this.locState.nativeElement.value='';
    this.locFaxNo.nativeElement.value='';
    this.locCountry.nativeElement.value='';
    this.locSmtpServerName.nativeElement.value='';
    this.locPopAccountPassword.nativeElement.value='';
    this.locPopServerName.nativeElement.value='';
    this.locPopAccountId.nativeElement.value='';
    this.locAdminEmail.nativeElement.value='';
    this.locSmtpPort.nativeElement.value=0;
    this.locOracleOrgId.nativeElement.value=0;
    this.orgName.nativeElement.value='';
    this.locationType.nativeElement.value='';
    this.description.nativeElement.value=''
    
  }

  setTabVal(){
    }

  FormSubmit(): void {
    //Check box value get from html page need to be casting
    /*var element = <HTMLInputElement> document.getElementById("vehicleModelActive");
    var isChecked = element.checked; 
    if(isChecked){
        this.vehicleModelActive.nativeElement.value = 'Y';
    }else{
        this.vehicleModelActive.nativeElement.value = 'N';
    }
    var vehicleModelFnMode = 'a'; 
    */
    if(this.locPopAccountPassword.nativeElement.value == this.locConfirmPassword.nativeElement.value){
      this.service.saveOrUpdateLocationInfo(this.locationName.nativeElement.value,
        this.locationId.nativeElement.value,
        this.locCreatedBy.nativeElement.value,
        this.locCreatedDate.nativeElement.value,
        this.locFnMode.nativeElement.value,
        this.locAddress.nativeElement.value,
        this.locZipcode.nativeElement.value,
        this.locCity.nativeElement.value,
        this.locTelNo.nativeElement.value,
        this.locState.nativeElement.value,
        this.locFaxNo.nativeElement.value,
        this.locCountry.nativeElement.value,
        this.locSmtpServerName.nativeElement.value,
        this.locPopAccountPassword.nativeElement.value,
        this.locPopServerName.nativeElement.value,
        this.locPopAccountId.nativeElement.value,
        this.locAdminEmail.nativeElement.value,
        this.locSmtpPort.nativeElement.value,
        this.locOracleOrgId.nativeElement.value,
        this.orgName.nativeElement.value,
        this.locationType.nativeElement.value,
        this.description.nativeElement.value
      ).subscribe(posts => {
        //console.log(posts);
        if (posts.success == true) {
          //alert("Location Edited Successfully");
          this.closeModal();            
          //window.location.reload(); 
          //$route.reload();
          //new LocationListV(this.service);
      } else if (posts.failure == true){
            alert(posts.message);
      }
      });
    }
    else{
      alert("Password and Confirm Password are mismatched!");
    }
 
 }
  

}

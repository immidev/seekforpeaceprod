import { Component, Input,OnInit, Inject, ViewChild, ElementRef, AfterViewInit } from '@angular/core';

import { LocalDataSource } from 'ng2-smart-table';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { UserManagementService } from '../../components/userManagement/userManagement.service';

@Component({
  selector: 'groupInfoVW',
  templateUrl: './groupInfoVW.html',
  styleUrls: ['./userManagement.scss'],
})
export class GroupInfoVW  implements OnInit {

  @Input('locAddress') locAdd: string;
  
query: string = '';
  modalHeader: string;
  menuData:Array<any>;
  
  constructor(private activeModal: NgbActiveModal, protected service: UserManagementService) {
    this.service.getMenusList(localStorage.getItem('groupModuleGroupId'),JSON.parse(localStorage.getItem('currentUser')).locationId).subscribe(posts =>{
      this.menuData =posts.menuList;
      
  });
  }

  ngOnInit() {}
  
  @ViewChild('groupLocationName') groupLocationName: ElementRef;
  @ViewChild('groupLocationId') groupLocationId: ElementRef;
  @ViewChild('groupCreatedBy') groupCreatedBy: ElementRef;
  @ViewChild('groupCreatedDate') groupCreatedDate: ElementRef;
  @ViewChild('groupFnMode') groupFnMode: ElementRef;
  @ViewChild('groupName') groupName: ElementRef;
  @ViewChild('groupId') groupId: ElementRef;
  
  closeModal() {
    this.activeModal.close();
  }

  clearGroupModal(){
    this.groupLocationName.nativeElement.value= JSON.parse(localStorage.getItem('currentUser')).locName;
    this.groupLocationId.nativeElement.value=JSON.parse(localStorage.getItem('currentUser')).locationId;
    this.groupCreatedBy.nativeElement.value='';
    this.groupCreatedDate.nativeElement.value='';
    this.groupFnMode.nativeElement.value='';
    this.groupName.nativeElement.value='';
    this.groupId.nativeElement.value='0';
    this.service.getMenusList("",JSON.parse(localStorage.getItem('currentUser')).locationId).subscribe(posts =>{
      this.menuData =posts.menuList;
      
  });
    
  }

 saveGroupSubmit(): void {
  //console.log(this.menuData);
  this.service.addGroup(this.groupId.nativeElement.value,
    this.groupName.nativeElement.value,
    this.groupFnMode.nativeElement.value,
    this.groupCreatedBy.nativeElement.value,
    this.groupCreatedDate.nativeElement.value,
    this.groupLocationId.nativeElement.value,
    JSON.stringify(this.menuData)
  ).subscribe(posts =>{
    //console.log(posts);
    if (posts.success == true) {

      if(this.groupFnMode.nativeElement.value=='e'){
        this.closeModal();            
      }else{
        (<HTMLInputElement> document.getElementById("success_msg")).style.display = 'block';
        (<HTMLInputElement> document.getElementById("success_msg")).innerHTML = 'Group Added Successfully';
        this.clearGroupModal();
      }
    } else if (posts.failure == true){
          alert(posts.message);
    }
});
}

 setClickedRow = function(index,item){
  
 //console.log(item.menuName);
 if(item.allocateFlag == true){
   item.allocateFlag=false;
 }else{
   item.allocateFlag=true;
 }
}
  

}

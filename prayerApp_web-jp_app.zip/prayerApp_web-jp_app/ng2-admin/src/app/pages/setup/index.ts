export * from './setup.component';

//export const WEB_URL='http://106.51.48.56:8002/salesApp/';
// export const WEB_URL='http://magzentine.com/dev.magzentine.com/MagzentineServices/';
//export const WEB_URL='http://34.213.176.168/MagzentineServices/';
// export const WEB_URL='http://seekforpeace.com/MagzentineServices/';
 
 export const WEB_URL='http://localhost/MagzentineServices/';
export const version: string="22.2.2"; 
// export const IMAGE_WEB_URL='http://localhost:8080/';
//export const IMAGE_WEB_URL='http://localhost:8080/';
export const IMAGE_WEB_URL='http://magzentine.com/dev.magzentine.com/';
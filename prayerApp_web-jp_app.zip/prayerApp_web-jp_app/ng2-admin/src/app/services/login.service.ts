import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';
import { Headers, Response, URLSearchParams } from '@angular/http';

@Injectable()
export class LoginService {

    constructor(private http: Http) {
         // console.log('entering service');
    }

}
/*

    getPosts() {
        console.log('entering ');
        return this.http.get('http://localhost:7070/bullTelematicsApp/listOfVehicleModel.action').map(res => res.json);
    }

    getValidateSession() {
        console.log('entering ');
       return this.http.get('http://localhost:7070/bullTelematicsApp/validateSession').map(res => res.json());
    }

     getUserSessionDetails() {
        console.log('entering ');
        return this.http.get('http://localhost:7070/bullTelematicsApp/loadLoginUserInfo.action').map(res => res.json);
    }
    */